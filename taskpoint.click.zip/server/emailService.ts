import nodemailer from 'nodemailer';

export interface EmailActionPayload {
  toEmail: string;
  username: string;
  action: 'BANNED' | 'RESTRICTED' | 'DELETED' | 'RESTORED';
  reason?: string;
  adminName?: string;
  timestamp?: string;
  supportEmail?: string;
  appUrl?: string;
}

export interface EmailLogEntry {
  id: string;
  toEmail: string;
  username: string;
  action: 'BANNED' | 'RESTRICTED' | 'DELETED' | 'RESTORED';
  subject: string;
  reason?: string;
  status: 'SENT' | 'FAILED' | 'SIMULATED';
  error?: string;
  timestamp: string;
}

/**
 * Creates and returns the nodemailer transporter.
 * Uses environment variables SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, SMTP_FROM if configured.
 * If not configured, uses a safe transport that logs email content for debugging & audit.
 */
function getTransporter() {
  const host = process.env.SMTP_HOST;
  const port = parseInt(process.env.SMTP_PORT || '587', 10);
  const user = process.env.SMTP_USER;
  const pass = process.env.SMTP_PASS;

  if (host && user && pass) {
    return nodemailer.createTransport({
      host,
      port,
      secure: port === 465,
      auth: {
        user,
        pass,
      },
    });
  }

  // Fallback transporter: Logs output safely
  return nodemailer.createTransport({
    streamTransport: true,
    newline: 'unix',
    buffer: true,
  });
}

const DEFAULT_SUPPORT_EMAIL = 'support@taskpoint.app';
const DEFAULT_APP_NAME = 'TaskPoint';

/**
 * Generates branded, responsive HTML template for account status notifications.
 */
function generateEmailHtml(payload: EmailActionPayload): { subject: string; html: string; text: string } {
  const { toEmail, username, action, reason, timestamp } = payload;
  const formattedDate = timestamp
    ? new Date(timestamp).toUTCString()
    : new Date().toUTCString();
  const supportEmail = payload.supportEmail || DEFAULT_SUPPORT_EMAIL;
  const displayReason = (reason && reason.trim()) || 'Violation of platform terms of service / suspicious activity detection.';

  let subject = '';
  let badgeColor = '#e11d48'; // red-600
  let badgeBg = '#ffe4e6';
  let badgeText = 'ACCOUNT BANNED';
  let headline = 'Your TaskPoint Account Has Been Banned';
  let description = '';
  let actionAdvice = '';

  switch (action) {
    case 'BANNED':
      subject = `[TaskPoint Alert] Account @${username} has been Banned`;
      badgeColor = '#e11d48';
      badgeBg = '#ffe4e6';
      badgeText = '⛔ ACCOUNT BANNED';
      headline = 'Your TaskPoint Account Has Been Banned';
      description = `This is an official notice to inform you that your TaskPoint account (<b>@${username}</b>) has been permanently banned by an administrator. You will no longer be able to log in, complete tasks, or claim rewards.`;
      actionAdvice = `If you believe this action was taken in error or would like to submit an appeal, please contact our support team at <a href="mailto:${supportEmail}" style="color: #4f46e5; font-weight: bold; text-decoration: underline;">${supportEmail}</a> with your registered email and username.`;
      break;

    case 'RESTRICTED':
      subject = `[TaskPoint Notice] Account @${username} Privileges Restricted`;
      badgeColor = '#d97706'; // amber-600
      badgeBg = '#fef3c7';
      badgeText = '⚠️ PRIVILEGES RESTRICTED';
      headline = 'Your Account Privileges Have Been Restricted';
      description = `We are writing to notify you that certain privileges on your TaskPoint account (<b>@${username}</b>) have been restricted by an administrator. During this restriction period, you will be unable to submit microtask proofs, request wallet payouts, or open disputes.`;
      actionAdvice = `To resolve this restriction or clarify any pending task submissions, please review your recent activity or reach out to our support desk at <a href="mailto:${supportEmail}" style="color: #4f46e5; font-weight: bold; text-decoration: underline;">${supportEmail}</a>.`;
      break;

    case 'DELETED':
      subject = `[TaskPoint Notice] Account @${username} Has Been Deleted`;
      badgeColor = '#475569'; // slate-600
      badgeBg = '#f1f5f9';
      badgeText = '🗑️ ACCOUNT DELETED';
      headline = 'Your TaskPoint Account Has Been Deleted';
      description = `This notice confirms that your TaskPoint account (<b>@${username}</b>) associated with <b>${toEmail}</b> has been deleted by an administrator. All associated profile records, pending submissions, and active sessions have been permanently removed from the system.`;
      actionAdvice = `If you did not request this deletion or require further clarification, please contact our team at <a href="mailto:${supportEmail}" style="color: #4f46e5; font-weight: bold; text-decoration: underline;">${supportEmail}</a>.`;
      break;

    case 'RESTORED':
      subject = `[TaskPoint Update] Account @${username} Restored to Active`;
      badgeColor = '#16a34a'; // green-600
      badgeBg = '#dcfce7';
      badgeText = '✅ ACCOUNT RESTORED';
      headline = 'Your Account Access Has Been Restored!';
      description = `Good news! Your TaskPoint account (<b>@${username}</b>) has been reviewed and restored to <b>ACTIVE</b> status by our administration team. All previous restrictions and bans have been lifted.`;
      actionAdvice = `You may now log in to your account, submit microtasks, and access your wallet balances normally.`;
      break;
  }

  const html = `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${subject}</title>
</head>
<body style="margin: 0; padding: 0; background-color: #f8fafc; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color: #1e293b;">
  <table width="100%" border="0" cellspacing="0" cellpadding="0" style="background-color: #f8fafc; padding: 40px 15px;">
    <tr>
      <td align="center">
        <table width="100%" max-width="600" border="0" cellspacing="0" cellpadding="0" style="max-width: 600px; background-color: #ffffff; border-radius: 20px; overflow: hidden; box-shadow: 0 4px 20px rgba(0, 0, 0, 0.06); border: 1px solid #e2e8f0;">
          
          <!-- Header Bar -->
          <tr>
            <td style="background-color: #0f172a; padding: 28px 36px; text-align: left;">
              <table width="100%" border="0" cellspacing="0" cellpadding="0">
                <tr>
                  <td>
                    <div style="font-size: 22px; font-weight: 900; color: #ffffff; letter-spacing: -0.5px;">
                      TASK<span style="color: #6366f1;">POINT</span>
                    </div>
                    <div style="font-size: 11px; color: #94a3b8; margin-top: 2px; font-weight: 500;">
                      Microtask & Rewards Network
                    </div>
                  </td>
                  <td align="right">
                    <span style="display: inline-block; padding: 6px 14px; background-color: ${badgeBg}; color: ${badgeColor}; border-radius: 999px; font-size: 11px; font-weight: 800; text-transform: uppercase; letter-spacing: 0.5px;">
                      ${badgeText}
                    </span>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Main Body -->
          <tr>
            <td style="padding: 36px 36px 24px 36px;">
              <h1 style="margin: 0 0 16px 0; font-size: 20px; font-weight: 800; color: #0f172a; line-height: 1.3;">
                ${headline}
              </h1>

              <p style="margin: 0 0 20px 0; font-size: 14px; line-height: 1.6; color: #475569;">
                Hello <strong>@${username}</strong>,
              </p>

              <p style="margin: 0 0 24px 0; font-size: 14px; line-height: 1.6; color: #475569;">
                ${description}
              </p>

              <!-- Details Box -->
              <table width="100%" border="0" cellspacing="0" cellpadding="0" style="background-color: #f8fafc; border-radius: 14px; border: 1px solid #e2e8f0; margin-bottom: 24px; overflow: hidden;">
                <tr>
                  <td style="padding: 14px 18px; border-bottom: 1px solid #e2e8f0; font-size: 12px; color: #64748b; font-weight: 600; width: 35%;">
                    Target Username:
                  </td>
                  <td style="padding: 14px 18px; border-bottom: 1px solid #e2e8f0; font-size: 13px; color: #0f172a; font-weight: 700;">
                    @${username}
                  </td>
                </tr>
                <tr>
                  <td style="padding: 14px 18px; border-bottom: 1px solid #e2e8f0; font-size: 12px; color: #64748b; font-weight: 600;">
                    Registered Email:
                  </td>
                  <td style="padding: 14px 18px; border-bottom: 1px solid #e2e8f0; font-size: 13px; color: #0f172a; font-weight: 600;">
                    ${toEmail}
                  </td>
                </tr>
                <tr>
                  <td style="padding: 14px 18px; border-bottom: 1px solid #e2e8f0; font-size: 12px; color: #64748b; font-weight: 600;">
                    Date & Time:
                  </td>
                  <td style="padding: 14px 18px; border-bottom: 1px solid #e2e8f0; font-size: 12px; color: #0f172a; font-family: monospace;">
                    ${formattedDate}
                  </td>
                </tr>
                <tr>
                  <td style="padding: 14px 18px; font-size: 12px; color: #64748b; font-weight: 600; vertical-align: top;">
                    Stated Reason:
                  </td>
                  <td style="padding: 14px 18px; font-size: 13px; color: #b91c1c; font-weight: 600; line-height: 1.5;">
                    ${displayReason}
                  </td>
                </tr>
              </table>

              <!-- Next Steps / Support Callout -->
              <div style="background-color: #eff6ff; border-left: 4px solid #6366f1; border-radius: 8px; padding: 16px; margin-bottom: 24px;">
                <div style="font-size: 12px; font-weight: 700; color: #1e1b4b; text-transform: uppercase; margin-bottom: 6px;">
                  What Should You Do?
                </div>
                <div style="font-size: 13px; line-height: 1.6; color: #334155;">
                  ${actionAdvice}
                </div>
              </div>

              <p style="margin: 0; font-size: 13px; line-height: 1.5; color: #64748b;">
                Thank you for your understanding,<br>
                <strong>The TaskPoint Administration Team</strong>
              </p>
            </td>
          </tr>

          <!-- Footer -->
          <tr>
            <td style="background-color: #f1f5f9; padding: 20px 36px; text-align: center; border-top: 1px solid #e2e8f0; font-size: 11px; color: #64748b;">
              <p style="margin: 0 0 6px 0;">
                This is an automated system security notification sent to <strong>${toEmail}</strong>.
              </p>
              <p style="margin: 0;">
                © ${new Date().getFullYear()} ${DEFAULT_APP_NAME} Platform. All rights reserved.
              </p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
</body>
</html>
  `.trim();

  const text = `
TaskPoint Account Notice: ${headline}
--------------------------------------------------
Hello @${username},

${description.replace(/<[^>]*>?/gm, '')}

Account Details:
- Username: @${username}
- Email: ${toEmail}
- Date: ${formattedDate}
- Reason: ${displayReason}

What Should You Do:
${actionAdvice.replace(/<[^>]*>?/gm, '')}

If you have any questions, please contact our support team at ${supportEmail}.

Regards,
TaskPoint Administration Team
  `.trim();

  return { subject, html, text };
}

/**
 * Sends email to a user when their account is banned, restricted, deleted, or restored.
 */
export async function sendUserStatusEmail(payload: EmailActionPayload): Promise<EmailLogEntry> {
  const { subject, html, text } = generateEmailHtml(payload);
  const fromAddress = process.env.SMTP_FROM || `TaskPoint Security <${payload.supportEmail || DEFAULT_SUPPORT_EMAIL}>`;

  const logEntry: EmailLogEntry = {
    id: 'eml-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
    toEmail: payload.toEmail,
    username: payload.username,
    action: payload.action,
    subject,
    reason: payload.reason,
    status: 'SENT',
    timestamp: new Date().toISOString(),
  };

  try {
    const transporter = getTransporter();
    
    console.log(`[EmailService] Dispatching ${payload.action} notification to ${payload.toEmail} (@${payload.username})...`);

    const info = await transporter.sendMail({
      from: fromAddress,
      to: payload.toEmail,
      subject,
      text,
      html,
    });

    console.log(`[EmailService] Email successfully delivered to ${payload.toEmail}. MessageId: ${info.messageId || 'simulated-stream'}`);
    logEntry.status = 'SENT';
  } catch (err: any) {
    console.error(`[EmailService] Failed to send email to ${payload.toEmail}:`, err.message || err);
    logEntry.status = 'FAILED';
    logEntry.error = err.message || 'Unknown transport error';
  }

  return logEntry;
}
