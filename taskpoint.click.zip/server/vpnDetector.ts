import { Request } from 'express';

export interface VpnCheckResult {
  isBlocked: boolean;
  isVpnOrProxy: boolean;
  isDatacenter: boolean;
  isTor: boolean;
  threatScore: number; // 0 to 100
  reason: string;
  country: string;
  countryCode: string;
  region: string;
  city: string;
  isp: string;
  org: string;
  as: string;
  asname: string;
  timezone: string;
  ip: string;
  detectedHeaders: string[];
}

interface CacheEntry {
  data: VpnCheckResult;
  expiresAt: number;
}

const vpnCache = new Map<string, CacheEntry>();
const CACHE_TTL_MS = 2 * 60 * 60 * 1000; // 2 hours

// Suspicious proxy/VPN header keys (excluding standard CDN / cloud reverse-proxy headers like via, forwarded)
const PROXY_HEADER_KEYS = [
  'x-tor-exit-node',
  'x-onion-location',
  'x-bluecoat-via',
  'x-squid-error',
  'x-proxyuser-ip',
];

// Keywords indicating VPN, Proxy, Cloud Datacenter or Anonymizer
const VPN_DATACENTER_KEYWORDS = [
  'vpn',
  'proxy',
  'tor',
  'exit node',
  'relay',
  'anonymizer',
  'm247',
  'digitalocean',
  'linode',
  'ovh',
  'hetzner',
  'vultr',
  'choopa',
  'leaseweb',
  'clouvider',
  'datapacket',
  'scaleway',
  'amazon',
  'aws',
  'google cloud',
  'azure',
  'fastly',
  'cloudflare warp',
  'nordvpn',
  'surfshark',
  'expressvpn',
  'protonvpn',
  'mullvad',
  'windscribe',
  'cyberghost',
  'ipvanish',
  'hidemyass',
  'private internet access',
  'pia',
  'torguard',
  'purevpn',
  'zenmate',
  'tunnelbear',
  'hotspot shield',
  'vyprvpn',
  'ivacy',
  'privatevpn',
  'astrill',
  'shadowsocks',
  'wireguard',
  'openvpn',
  'flyservers',
  'serverius',
  'cogent',
  'packethub',
  'packetexchange',
  'vpnunlimited',
  'controld',
  'nextdns',
  'datacenter',
  'data center',
  'hosting',
  'colocation',
  'dedicated server',
  'cloud host',
  'rackspace',
  'hostwinds',
  'contabo',
  'kamatera',
  'ionos',
  'alibaba cloud',
  'tencent cloud',
  'oracle cloud',
];

/**
 * Extracts the real client IP address from express request headers
 */
export function extractClientIp(req: Request): string {
  // Check headers in order of reliability
  const cfConnectingIp = req.headers['cf-connecting-ip'] as string;
  if (cfConnectingIp && isValidIp(cfConnectingIp)) return cfConnectingIp.trim();

  const fastlyClientIp = req.headers['fastly-client-ip'] as string;
  if (fastlyClientIp && isValidIp(fastlyClientIp)) return fastlyClientIp.trim();

  const trueClientIp = req.headers['true-client-ip'] as string;
  if (trueClientIp && isValidIp(trueClientIp)) return trueClientIp.trim();

  const xRealIp = req.headers['x-real-ip'] as string;
  if (xRealIp && isValidIp(xRealIp)) return xRealIp.trim();

  const xForwardedFor = req.headers['x-forwarded-for'] as string;
  if (xForwardedFor) {
    const parts = xForwardedFor.split(',').map((p) => p.trim());
    // Find first non-private public IP if available
    for (const ip of parts) {
      if (isValidIp(ip) && !isPrivateIp(ip)) {
        return ip;
      }
    }
    if (parts[0] && isValidIp(parts[0])) {
      return parts[0];
    }
  }

  const clientIp = req.headers['x-client-ip'] as string;
  if (clientIp && isValidIp(clientIp)) return clientIp.trim();

  return req.ip || req.socket.remoteAddress || '127.0.0.1';
}

/**
 * Validates whether a string is a valid IPv4 or IPv6 address
 */
export function isValidIp(ip: string): boolean {
  if (!ip) return false;
  // Basic IPv4 regex
  const ipv4 = /^(\d{1,3}\.){3}\d{1,3}$/;
  if (ipv4.test(ip)) {
    const parts = ip.split('.').map(Number);
    return parts.every((p) => p >= 0 && p <= 255);
  }
  // Basic IPv6 check
  return ip.includes(':') && ip.length <= 45;
}

/**
 * Checks if an IP is within private / local / loopback ranges
 */
export function isPrivateIp(ip: string): boolean {
  if (!ip) return true;
  const cleanIp = ip.replace(/^::ffff:/, '').trim();

  if (
    cleanIp === '127.0.0.1' ||
    cleanIp === '::1' ||
    cleanIp === 'localhost' ||
    cleanIp === '0.0.0.0'
  ) {
    return true;
  }

  // 10.0.0.0 - 10.255.255.255
  if (cleanIp.startsWith('10.')) return true;

  // 192.168.0.0 - 192.168.255.255
  if (cleanIp.startsWith('192.168.')) return true;

  // 172.16.0.0 - 172.31.255.255
  if (/^172\.(1[6-9]|2\d|3[01])\./.test(cleanIp)) return true;

  // Carrier-grade NAT 100.64.0.0 - 100.127.255.255
  if (/^100\.(6[4-9]|[7-9]\d|1[01]\d|12[0-7])\./.test(cleanIp)) return true;

  // IPv6 local
  if (cleanIp.startsWith('fc00:') || cleanIp.startsWith('fe80:')) return true;

  return false;
}

/**
 * Scans request headers for proxy indicators
 */
export function detectProxyHeaders(req: Request): string[] {
  const detected: string[] = [];
  for (const headerKey of PROXY_HEADER_KEYS) {
    if (req.headers[headerKey]) {
      detected.push(`${headerKey}: ${String(req.headers[headerKey]).slice(0, 60)}`);
    }
  }
  return detected;
}

/**
 * Performs threat intelligence lookup for an IP address
 */
export async function lookupIpThreatInfo(ip: string): Promise<Partial<VpnCheckResult>> {
  const cleanIp = ip.replace(/^::ffff:/, '').trim();

  // Try ip-api.com (reliable, provides proxy & hosting flags)
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 2500);

    const url = `http://ip-api.com/json/${cleanIp}?fields=status,message,country,countryCode,region,regionName,city,zip,lat,lon,timezone,isp,org,as,asname,reverse,mobile,proxy,hosting,query`;
    const res = await fetch(url, { signal: controller.signal });
    clearTimeout(timeout);

    if (res.ok) {
      const data = await res.json();
      if (data && data.status === 'success') {
        const ispLower = (data.isp || '').toLowerCase();
        const orgLower = (data.org || '').toLowerCase();
        const asLower = (data.as || '').toLowerCase();
        const asnameLower = (data.asname || '').toLowerCase();
        const revLower = (data.reverse || '').toLowerCase();
        const combinedText = `${ispLower} ${orgLower} ${asLower} ${asnameLower} ${revLower}`;

        let isDatacenter = !!data.hosting;
        let isProxy = !!data.proxy;
        let isTor = combinedText.includes('tor') || combinedText.includes('exit node');
        let matchedKeywords: string[] = [];

        for (const kw of VPN_DATACENTER_KEYWORDS) {
          if (combinedText.includes(kw)) {
            matchedKeywords.push(kw);
            if (['vpn', 'proxy', 'tor', 'nordvpn', 'surfshark', 'expressvpn', 'protonvpn', 'mullvad'].includes(kw)) {
              isProxy = true;
            } else {
              isDatacenter = true;
            }
          }
        }

        let threatScore = 0;
        if (isProxy) threatScore += 65;
        if (isDatacenter) threatScore += 35;
        if (isTor) threatScore += 50;
        if (matchedKeywords.length > 0) threatScore += Math.min(30, matchedKeywords.length * 10);
        threatScore = Math.min(100, threatScore);

        const reasons: string[] = [];
        if (data.proxy) reasons.push('Identified as Public/Private Proxy or VPN exit');
        if (data.hosting) reasons.push('Datacenter / Cloud Server Hosting network');
        if (matchedKeywords.length > 0) reasons.push(`Known VPN/Datacenter signature (${matchedKeywords.slice(0, 3).join(', ')})`);

        return {
          ip: cleanIp,
          isVpnOrProxy: isProxy || matchedKeywords.some((k) => ['vpn', 'proxy', 'tor', 'nordvpn', 'surfshark', 'expressvpn', 'protonvpn', 'mullvad'].includes(k)),
          isDatacenter,
          isTor,
          threatScore,
          reason: reasons.join(' • ') || 'Clean residential/mobile network',
          country: data.country || 'Unknown',
          countryCode: data.countryCode || 'XX',
          region: data.regionName || '',
          city: data.city || '',
          isp: data.isp || '',
          org: data.org || '',
          as: data.as || '',
          asname: data.asname || '',
          timezone: data.timezone || '',
        };
      }
    }
  } catch (err) {
    // Timeout or network error, proceed to fallback
  }

  // Fallback to ipwho.is
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 2500);

    const res = await fetch(`https://ipwho.is/${cleanIp}`, { signal: controller.signal });
    clearTimeout(timeout);

    if (res.ok) {
      const data = await res.json();
      if (data && data.success) {
        const security = data.security || {};
        const isVpn = !!security.vpn;
        const isProxy = !!security.proxy;
        const isTor = !!security.tor;
        const isHosting = !!security.hosting;

        const isp = data.connection?.isp || '';
        const org = data.connection?.org || '';
        const combined = `${isp} ${org}`.toLowerCase();

        let hasKw = false;
        for (const kw of VPN_DATACENTER_KEYWORDS) {
          if (combined.includes(kw)) {
            hasKw = true;
            break;
          }
        }

        const isVpnOrProxy = isVpn || isProxy || isTor || hasKw;
        return {
          ip: cleanIp,
          isVpnOrProxy,
          isDatacenter: isHosting,
          isTor,
          threatScore: (isVpnOrProxy ? 70 : 0) + (isHosting ? 30 : 0),
          reason: isVpnOrProxy ? 'VPN / Proxy / Anonymous Node detected' : (isHosting ? 'Datacenter Network' : 'Clean IP'),
          country: data.country || 'Unknown',
          countryCode: data.country_code || 'XX',
          region: data.region || '',
          city: data.city || '',
          isp: data.connection?.isp || '',
          org: data.connection?.org || '',
          as: data.connection?.asn ? `AS${data.connection.asn}` : '',
          asname: data.connection?.asn_name || '',
          timezone: data.timezone?.id || '',
        };
      }
    }
  } catch (err) {
    // Fallback failed
  }

  return {
    ip: cleanIp,
    isVpnOrProxy: false,
    isDatacenter: false,
    isTor: false,
    threatScore: 0,
    reason: 'Private or unindexed network',
    country: 'Global',
    countryCode: 'GL',
    region: '',
    city: '',
    isp: 'Local / Unresolved',
    org: '',
    as: '',
    asname: '',
    timezone: 'UTC',
  };
}

/**
 * Main verification function to check if a request/IP is coming from a VPN or Proxy
 */
export async function checkVpnAndProxy(
  req: Request,
  settings: { strictVpnBlocking?: boolean; blockDataCenters?: boolean; vpnWhitelistedIps?: string[] } = {}
): Promise<VpnCheckResult> {
  const strictBlocking = settings.strictVpnBlocking !== false; // enabled by default
  const blockDatacenters = settings.blockDataCenters !== false; // enabled by default
  const whitelistedIps = settings.vpnWhitelistedIps || [];

  const ip = extractClientIp(req);
  const detectedHeaders = detectProxyHeaders(req);

  // Check if IP is explicitly whitelisted by Admin
  if (whitelistedIps.includes(ip)) {
    return {
      isBlocked: false,
      isVpnOrProxy: false,
      isDatacenter: false,
      isTor: false,
      threatScore: 0,
      reason: 'IP explicitly whitelisted by administrator',
      country: 'Whitelisted',
      countryCode: 'WL',
      region: '',
      city: '',
      isp: 'Admin Whitelist',
      org: '',
      as: '',
      asname: '',
      timezone: 'UTC',
      ip,
      detectedHeaders,
    };
  }

  // If local / private IP and no suspicious proxy headers in development
  if (isPrivateIp(ip) && detectedHeaders.length === 0) {
    return {
      isBlocked: false,
      isVpnOrProxy: false,
      isDatacenter: false,
      isTor: false,
      threatScore: 0,
      reason: 'Local development / Private subnet connection',
      country: 'Local',
      countryCode: 'LC',
      region: 'Local',
      city: 'Localhost',
      isp: 'Local Subnet',
      org: 'Localhost',
      as: '',
      asname: '',
      timezone: 'UTC',
      ip,
      detectedHeaders,
    };
  }

  // Check cache
  const cached = vpnCache.get(ip);
  if (cached && cached.expiresAt > Date.now()) {
    const cachedData = { ...cached.data, detectedHeaders };
    const shouldBlock = strictBlocking && (cachedData.isVpnOrProxy || (blockDatacenters && cachedData.isDatacenter) || detectedHeaders.length > 0);
    return {
      ...cachedData,
      isBlocked: shouldBlock,
    };
  }

  // Perform lookup
  const threat = await lookupIpThreatInfo(ip);

  const isVpnOrProxy = !!threat.isVpnOrProxy || detectedHeaders.length > 0;
  const isDatacenter = !!threat.isDatacenter;
  const isTor = !!threat.isTor;

  let threatScore = threat.threatScore || 0;
  if (detectedHeaders.length > 0) threatScore = Math.max(threatScore, 60);

  let reasons: string[] = [];
  if (threat.reason && threat.reason !== 'Clean residential/mobile network' && threat.reason !== 'Private or unindexed network') {
    reasons.push(threat.reason);
  }
  if (detectedHeaders.length > 0) {
    reasons.push(`Suspicious forwarding headers: ${detectedHeaders.join(', ')}`);
  }

  const finalReason = reasons.length > 0 ? reasons.join(' | ') : 'Clean verified connection';

  const shouldBlock = strictBlocking && (isVpnOrProxy || (blockDatacenters && isDatacenter) || detectedHeaders.length > 0);

  const result: VpnCheckResult = {
    isBlocked: shouldBlock,
    isVpnOrProxy,
    isDatacenter,
    isTor,
    threatScore,
    reason: finalReason,
    country: threat.country || 'Unknown',
    countryCode: threat.countryCode || 'XX',
    region: threat.region || '',
    city: threat.city || '',
    isp: threat.isp || 'Unknown',
    org: threat.org || '',
    as: threat.as || '',
    asname: threat.asname || '',
    timezone: threat.timezone || 'UTC',
    ip,
    detectedHeaders,
  };

  // Cache result
  vpnCache.set(ip, {
    data: result,
    expiresAt: Date.now() + CACHE_TTL_MS,
  });

  return result;
}

/**
 * Direct IP inspector function for Admin panel testing
 */
export async function inspectIp(ip: string) {
  const threat = await lookupIpThreatInfo(ip);
  return threat;
}
