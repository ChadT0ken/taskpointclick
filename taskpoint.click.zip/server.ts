import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import nodemailer from 'nodemailer';
import { createServer as createViteServer } from 'vite';

const app = express();
const PORT = 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'taskpoint-super-secret-key-2026';

app.use(express.json({ limit: '20mb' }));

// File-based persistence storage path
const DATA_DIR = path.join(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'db.json');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Initial Database Schema Structure
interface DatabaseSchema {
  users: any[];
  tasks: any[];
  submissions: any[];
  withdrawals: any[];
  notifications: any[];
  tickets: any[];
  disputes: any[];
  referralLogs: any[];
  pointTransactions: any[];
  bookmarks: any[];
  announcements: any[];
  settings: any;
}

// Helper to Load DB
function loadDB(): DatabaseSchema {
  let dbData: DatabaseSchema;
  if (!fs.existsSync(DB_FILE)) {
    dbData = generateSeedData();
    fs.writeFileSync(DB_FILE, JSON.stringify(dbData, null, 2));
  } else {
    try {
      const content = fs.readFileSync(DB_FILE, 'utf-8');
      dbData = JSON.parse(content);
    } catch (err) {
      console.error('Error reading db.json, re-initializing...', err);
      dbData = generateSeedData();
      fs.writeFileSync(DB_FILE, JSON.stringify(dbData, null, 2));
    }
  }
  ensureDemoAccountsExist(dbData);
  return dbData;
}

function ensureDemoAccountsExist(db: DatabaseSchema) {
  let changed = false;

  // 1. Primary ADMIN Account (Always ensure admin can log in)
  let admin = db.users.find(u => u.role === 'ADMIN' || u.email?.toLowerCase() === 'emma1854986@gmail.com');
  if (!admin) {
    admin = {
      id: 'usr-admin-01',
      email: 'emma1854986@gmail.com',
      username: 'TaskPointAdmin',
      passwordHash: bcrypt.hashSync('Admin123!', 10),
      role: 'ADMIN',
      avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=TaskPointAdmin',
      country: 'Nigeria',
      isEmailVerified: true,
      isBanned: false,
      availableBalance: 0.0,
      pendingBalance: 0.0,
      totalWithdrawn: 0.0,
      airdropPoints: 0,
      referralPoints: 0,
      dailyStreak: 1,
      referralCode: 'ADMINREF',
      createdAt: new Date().toISOString(),
      lastLoginAt: new Date().toISOString(),
    };
    db.users.push(admin);
    changed = true;
  }

  if (changed) {
    try {
      fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
    } catch (err) {
      console.error('Error saving db.json in ensureDemoAccountsExist:', err);
    }
  }
}

// Helper to Save DB
function saveDB(data: DatabaseSchema) {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
  } catch (err) {
    console.error('Error saving db.json:', err);
  }
}

// Seed Generator with clean default structure (no dummy tasks, submissions, withdrawals, or fake users)
function generateSeedData(): DatabaseSchema {
  const adminPassword = bcrypt.hashSync('Admin123!', 10);

  const users = [
    {
      id: 'usr-admin-01',
      email: 'emma1854986@gmail.com',
      username: 'TaskPointAdmin',
      passwordHash: adminPassword,
      role: 'ADMIN',
      avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=TaskPointAdmin',
      country: 'Nigeria',
      isEmailVerified: true,
      isBanned: false,
      availableBalance: 0.0,
      pendingBalance: 0.0,
      totalWithdrawn: 0.0,
      airdropPoints: 0,
      referralPoints: 0,
      dailyStreak: 0,
      referralCode: 'ADMINREF',
      createdAt: new Date().toISOString(),
      lastLoginAt: new Date().toISOString(),
    }
  ];

  const tasks: any[] = [];
  const submissions: any[] = [];
  const withdrawals: any[] = [];
  const notifications: any[] = [];
  const tickets: any[] = [];
  const disputes: any[] = [];
  const referralLogs: any[] = [];
  const pointTransactions: any[] = [];
  const announcements: any[] = [];

  const settings = {
    websiteName: 'TaskPoint',
    minWithdrawalUSD: 5.0,
    referralPointsBonus: 10,
    maintenanceMode: false,
    supportEmail: 'support@taskpoint.app',
  };

  return {
    users,
    tasks,
    submissions,
    withdrawals,
    notifications,
    tickets,
    disputes,
    referralLogs,
    pointTransactions,
    bookmarks: [],
    announcements,
    settings,
  };
}

// Authentication Middleware
function authenticateToken(req: Request & { user?: any }, res: Response, next: any) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  jwt.verify(token, JWT_SECRET, (err: any, decoded: any) => {
    if (err) {
      return res.status(403).json({ error: 'Invalid or expired session token' });
    }
    const db = loadDB();
    const user = db.users.find((u) => u.id === decoded.id);
    if (!user) {
      return res.status(401).json({ error: 'Account no longer exists' });
    }
    if (user.isBanned) {
      return res.status(403).json({ error: 'Your account has been suspended/banned by an administrator.' });
    }
    req.user = user;
    next();
  });
}

// Optional Auth Helper
function getAuthenticatedUser(req: Request): any | null {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  if (!token) return null;
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch (e) {
    return null;
  }
}

// In-memory ONE-TIME OTP store (No permanent DB storage needed)
interface OtpRecord {
  code: string;
  expiresAt: number;
  purpose: 'REGISTER' | 'LOGIN' | 'FORGOT';
  payload?: {
    username?: string;
    email?: string;
    passwordHash?: string;
    referralCode?: string;
    userId?: string;
  };
}

const otpStore = new Map<string, OtpRecord>();

// Helper to generate a 6-digit OTP code
function generateOtpCode(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

// Mailer transport setup
let cachedMailTransporter: nodemailer.Transporter | null = null;
let primarySmtpDisabled = false; // Prevents spamming broken SMTP credentials after 535 auth failure

async function getMailTransporter(): Promise<nodemailer.Transporter> {
  if (cachedMailTransporter) return cachedMailTransporter;

  if (!primarySmtpDisabled && process.env.SMTP_USER && process.env.SMTP_PASS) {
    try {
      const isGmail = (process.env.SMTP_HOST || '').includes('gmail') || (process.env.SMTP_USER || '').includes('@gmail.com');
      const cleanPass = process.env.SMTP_PASS.replace(/\s+/g, '');
      
      if (isGmail) {
        cachedMailTransporter = nodemailer.createTransport({
          service: 'gmail',
          auth: {
            user: process.env.SMTP_USER.trim(),
            pass: cleanPass,
          },
        });
      } else {
        cachedMailTransporter = nodemailer.createTransport({
          host: process.env.SMTP_HOST || 'smtp.gmail.com',
          port: Number(process.env.SMTP_PORT) || 587,
          secure: Number(process.env.SMTP_PORT) === 465,
          auth: {
            user: process.env.SMTP_USER.trim(),
            pass: cleanPass,
          },
        });
      }
      return cachedMailTransporter;
    } catch (e) {
      // Fall through to Ethereal
    }
  }

  // Fallback to test Ethereal SMTP account if no valid SMTP config provided
  try {
    const testAccount = await nodemailer.createTestAccount();
    cachedMailTransporter = nodemailer.createTransport({
      host: 'smtp.ethereal.email',
      port: 587,
      secure: false,
      auth: {
        user: testAccount.user,
        pass: testAccount.pass,
      },
    });
    console.log('[Email Service] Using Ethereal test mailer account:', testAccount.user);
    return cachedMailTransporter;
  } catch (err: any) {
    cachedMailTransporter = nodemailer.createTransport({
      jsonTransport: true,
    });
    return cachedMailTransporter;
  }
}

// Dispatch One-Time OTP Magic Link to User's Email Address
async function sendOtpEmail(email: string, code: string, purpose: string) {
  const fromAddress = process.env.SMTP_FROM || '"TaskPoint Security" <noreply@taskpoint.click>';
  const rawBaseUrl = process.env.APP_URL || 'https://ais-dev-q45soofhwptyn75putphle-135176585446.europe-west2.run.app';
  const baseUrl = rawBaseUrl.replace(/\/$/, '');
  const verifyLink = `${baseUrl}/?verifyEmail=${encodeURIComponent(email)}&otpCode=${encodeURIComponent(code)}&purpose=${encodeURIComponent(purpose)}`;

  const subject = `TaskPoint 1-Click Verification & Sign-In Link`;
  const htmlContent = `
    <div style="font-family: system-ui, -apple-system, sans-serif; max-width: 560px; margin: 0 auto; padding: 32px 24px; background-color: #f8fafc; border-radius: 24px; border: 1px solid #e2e8f0; color: #0f172a;">
      <div style="text-align: center; margin-bottom: 24px;">
        <div style="display: inline-block; width: 48px; height: 48px; line-height: 48px; background: linear-gradient(135deg, #4f46e5 0%, #3b82f6 100%); color: #ffffff; border-radius: 14px; font-weight: 900; font-size: 22px; text-align: center; margin-bottom: 12px; box-shadow: 0 4px 12px rgba(79, 70, 229, 0.3);">T</div>
        <h2 style="color: #0f172a; margin: 0; font-size: 22px; font-weight: 800; letter-spacing: -0.5px;">TaskPoint Verification</h2>
        <p style="color: #64748b; font-size: 13px; margin-top: 4px;">One-Time Authentication for <strong>${purpose}</strong></p>
      </div>

      <div style="background-color: #ffffff; padding: 32px 24px; border-radius: 20px; text-align: center; border: 1px solid #e2e8f0; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);">
        <p style="color: #334155; font-size: 15px; margin-bottom: 20px; font-weight: 600; line-height: 1.5;">
          Click the button below to verify your email and sign in securely to your TaskPoint account:
        </p>

        <a href="${verifyLink}" style="display: inline-block; width: 88%; max-width: 380px; margin: 8px auto 16px; background: linear-gradient(135deg, #4f46e5 0%, #2563eb 100%); color: #ffffff; padding: 16px 24px; font-size: 15px; font-weight: 700; text-decoration: none; border-radius: 14px; box-shadow: 0 4px 14px rgba(79, 70, 229, 0.4); text-align: center;">
          Verify & Sign In Instantly →
        </a>

        <div style="margin-top: 24px; padding-top: 16px; border-top: 1px dashed #e2e8f0;">
          <p style="color: #94a3b8; font-size: 12px; line-height: 1.5; margin: 0;">
            This one-time verification link expires in <strong>10 minutes</strong>.<br/>
            If you did not request this, you can safely ignore this email.
          </p>
        </div>
      </div>

      <p style="text-align: center; color: #94a3b8; font-size: 11px; margin-top: 24px;">
        © TaskPoint Inc. Global Microtask Platform. All rights reserved.
      </p>
    </div>
  `;

  console.log(`[Email Service] 1-Click Verification Link for ${email}: ${verifyLink}`);

  // 1. Dispatch via Nodemailer (Primary SMTP with graceful auto-fallback)
  try {
    const transporter = await getMailTransporter();
    const mailOptions = {
      from: fromAddress,
      to: email,
      subject,
      html: htmlContent,
    };
    const info = await transporter.sendMail(mailOptions);
    console.log(`[Email Service] Verification link dispatched to ${email} (Message ID: ${info.messageId})`);
    const previewUrl = nodemailer.getTestMessageUrl(info);
    if (previewUrl) {
      console.log(`[Email Service] Ethereal preview URL: ${previewUrl}`);
    }
  } catch (err: any) {
    if (err.message && (err.message.includes('535') || err.message.includes('Username and Password not accepted') || err.message.includes('BadCredentials'))) {
      primarySmtpDisabled = true;
      cachedMailTransporter = null;
      console.log(`[Email Service] Note: Custom SMTP auth invalid (requires Google App Password for Gmail). Switching to seamless test transporter.`);
    }

    // Try sending via fallback Ethereal test transporter
    try {
      const fallbackTransporter = await getMailTransporter();
      const info = await fallbackTransporter.sendMail({
        from: fromAddress,
        to: email,
        subject,
        html: htmlContent,
      });
      console.log(`[Email Service] Fallback verification link sent via Ethereal to ${email} (Message ID: ${info.messageId})`);
      const previewUrl = nodemailer.getTestMessageUrl(info);
      if (previewUrl) {
        console.log(`[Email Service] Ethereal preview URL: ${previewUrl}`);
      }
    } catch (fallbackErr: any) {
      // Safe fallback
    }
  }

  // 2. Dispatch trigger to Firebase Firestore Trigger Email Extension
  try {
    const configPath = path.join(process.cwd(), 'firebase-applet-config.json');
    if (fs.existsSync(configPath)) {
      const firebaseConfig = JSON.parse(fs.readFileSync(configPath, 'utf8'));
      if (firebaseConfig.projectId && firebaseConfig.apiKey) {
        const firestoreUrl = `https://firestore.googleapis.com/v1/projects/${firebaseConfig.projectId}/databases/${firebaseConfig.firestoreDatabaseId || '(default)'}/documents/mail?key=${firebaseConfig.apiKey}`;
        
        fetch(firestoreUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            fields: {
              to: { arrayValue: { values: [{ stringValue: email }] } },
              message: {
                mapValue: {
                  fields: {
                    subject: { stringValue: subject },
                    html: { stringValue: htmlContent }
                  }
                }
              },
              createdAt: { timestampValue: new Date().toISOString() }
            }
          })
        }).catch((err) => console.log('[Firebase Mail Extension] Trigger status:', err.message));

        // Also trigger Firebase Identity Toolkit OOB Email Link if user exists in Firebase Auth
        const firebaseAuthOobUrl = `https://identitytoolkit.googleapis.com/v1/accounts:sendOobCode?key=${firebaseConfig.apiKey}`;
        fetch(firebaseAuthOobUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            requestType: purpose === 'FORGOT' ? 'PASSWORD_RESET' : 'EMAIL_SIGNIN',
            email,
            continueUrl: verifyLink,
            canHandleCodeInApp: true,
          })
        }).then(r => r.json()).then(authRes => {
          if (authRes.email) {
            console.log('[Firebase Auth] Dispatched native OOB Email Link for', email);
          }
        }).catch(() => {});
      }
    }
  } catch (e) {
    // Graceful fallback
  }
}

// In-memory OTP helpers
function saveOtpRecord(email: string, code: string, purpose: 'REGISTER' | 'LOGIN' | 'FORGOT', payload?: any) {
  const targetEmail = email.trim().toLowerCase();
  const existing = otpStore.get(targetEmail);

  const record: OtpRecord = {
    code,
    expiresAt: Date.now() + 10 * 60 * 1000, // 10 minutes
    purpose,
    payload: payload || existing?.payload,
  };

  otpStore.set(targetEmail, record);
  sendOtpEmail(targetEmail, code, purpose);
}

function getOtpRecord(email: string): OtpRecord | undefined {
  const targetEmail = email.trim().toLowerCase();
  const record = otpStore.get(targetEmail);
  if (!record) return undefined;
  if (Date.now() > record.expiresAt) {
    otpStore.delete(targetEmail);
    return undefined;
  }
  return record;
}

function removeOtpRecord(email: string) {
  const targetEmail = email.trim().toLowerCase();
  otpStore.delete(targetEmail);
}

// REST API ROUTES

// --- AUTH ROUTES ---

// Request / Resend OTP Code
app.post('/api/auth/send-otp', (req, res) => {
  const { email, purpose } = req.body;
  const targetEmail = (email || '').trim().toLowerCase();

  if (!targetEmail) {
    return res.status(400).json({ error: 'Email address is required to send OTP.' });
  }

  const db = loadDB();
  const existingUser = db.users.find((u) => u.email.toLowerCase() === targetEmail);

  if (purpose === 'LOGIN' || purpose === 'FORGOT') {
    if (!existingUser) {
      return res.status(404).json({ error: 'No account found with this email address.' });
    }
  }

  const code = generateOtpCode();
  const currentRecord = getOtpRecord(targetEmail);
  saveOtpRecord(
    targetEmail,
    code,
    purpose || 'REGISTER',
    currentRecord?.payload || (existingUser ? { userId: existingUser.id, email: targetEmail } : undefined)
  );

  const rawBaseUrl = process.env.APP_URL || `${req.protocol}://${req.get('host')}`;
  const baseUrl = rawBaseUrl.replace(/\/$/, '');
  const verifyLink = `${baseUrl}/?verifyEmail=${encodeURIComponent(targetEmail)}&otpCode=${encodeURIComponent(code)}&purpose=${encodeURIComponent(purpose || 'REGISTER')}`;

  return res.json({
    message: `A one-time verification link has been sent to ${targetEmail}`,
    email: targetEmail,
    previewOtpCode: code,
    previewOtpLink: verifyLink,
  });
});

// 1. Initial Register (Validates inputs and triggers OTP)
app.post('/api/auth/register', (req, res) => {
  const { username, email, password, referralCode } = req.body;
  const cleanUsername = (username || '').trim();
  const cleanEmail = (email || '').trim().toLowerCase();
  const cleanPassword = (password || '').trim();

  if (!cleanUsername || !cleanEmail || !cleanPassword) {
    return res.status(400).json({ error: 'Username, email and password are required' });
  }

  if (cleanPassword.length < 6) {
    return res.status(400).json({ error: 'Password must be at least 6 characters long' });
  }

  const db = loadDB();
  const existingUser = db.users.find(
    (u) => u.email.toLowerCase() === cleanEmail || u.username.toLowerCase() === cleanUsername.toLowerCase()
  );

  if (existingUser) {
    return res.status(400).json({ error: 'Username or Email is already registered' });
  }

  const passwordHash = bcrypt.hashSync(cleanPassword, 10);
  const code = generateOtpCode();

  saveOtpRecord(cleanEmail, code, 'REGISTER', {
    username: cleanUsername,
    email: cleanEmail,
    passwordHash,
    referralCode: referralCode ? String(referralCode).trim() : undefined,
  });

  const rawBaseUrl = process.env.APP_URL || `${req.protocol}://${req.get('host')}`;
  const baseUrl = rawBaseUrl.replace(/\/$/, '');
  const verifyLink = `${baseUrl}/?verifyEmail=${encodeURIComponent(cleanEmail)}&otpCode=${encodeURIComponent(code)}&purpose=REGISTER`;

  return res.json({
    requireOtp: true,
    purpose: 'REGISTER',
    email: cleanEmail,
    message: `A one-time verification link has been sent to ${cleanEmail}`,
    previewOtpCode: code,
    previewOtpLink: verifyLink,
  });
});

// 2. Initial Login (Validates password and triggers OTP)
app.post('/api/auth/login', (req, res) => {
  const { emailOrUsername, password } = req.body;
  const identifier = (emailOrUsername || '').trim().toLowerCase();
  const pass = (password || '').trim();

  if (!identifier || !pass) {
    return res.status(400).json({ error: 'Please enter your username/email and password' });
  }

  const db = loadDB();
  const user = db.users.find(
    (u) =>
      u.email.toLowerCase() === identifier ||
      u.username.toLowerCase() === identifier
  );

  if (!user) {
    return res.status(400).json({ error: 'Invalid credentials. Please check your username/email and password.' });
  }

  if (user.isBanned) {
    return res.status(403).json({ error: 'Account suspended. Please contact support.' });
  }

  const isMatch = bcrypt.compareSync(pass, user.passwordHash);
  if (!isMatch) {
    return res.status(400).json({ error: 'Invalid credentials. Please check your password.' });
  }

  // Credentials match! Trigger OTP step for email verification
  const code = generateOtpCode();

  saveOtpRecord(user.email.toLowerCase(), code, 'LOGIN', {
    userId: user.id,
    email: user.email.toLowerCase(),
  });

  const rawBaseUrl = process.env.APP_URL || `${req.protocol}://${req.get('host')}`;
  const baseUrl = rawBaseUrl.replace(/\/$/, '');
  const verifyLink = `${baseUrl}/?verifyEmail=${encodeURIComponent(user.email.toLowerCase())}&otpCode=${encodeURIComponent(code)}&purpose=LOGIN`;

  return res.json({
    requireOtp: true,
    purpose: 'LOGIN',
    email: user.email,
    message: `A one-time login link has been sent to ${user.email}`,
    previewOtpCode: code,
    previewOtpLink: verifyLink,
  });
});

// 3. Initial Forgot Password (Triggers OTP)
app.post('/api/auth/forgot-password', (req, res) => {
  const { email, newPassword } = req.body;
  const targetEmail = (email || '').trim().toLowerCase();
  const pass = (newPassword || '').trim();

  if (!targetEmail) {
    return res.status(400).json({ error: 'Email address is required' });
  }

  if (pass && pass.length < 6) {
    return res.status(400).json({ error: 'New password must be at least 6 characters long' });
  }

  const db = loadDB();
  const user = db.users.find((u) => u.email.toLowerCase() === targetEmail);

  if (!user) {
    return res.status(404).json({ error: 'No account found with this email address.' });
  }

  const code = generateOtpCode();

  saveOtpRecord(targetEmail, code, 'FORGOT', {
    userId: user.id,
    email: targetEmail,
    passwordHash: pass ? bcrypt.hashSync(pass, 10) : undefined,
  });

  const rawBaseUrl = process.env.APP_URL || `${req.protocol}://${req.get('host')}`;
  const baseUrl = rawBaseUrl.replace(/\/$/, '');
  const verifyLink = `${baseUrl}/?verifyEmail=${encodeURIComponent(targetEmail)}&otpCode=${encodeURIComponent(code)}&purpose=FORGOT`;

  return res.json({
    requireOtp: true,
    purpose: 'FORGOT',
    email: targetEmail,
    message: `Password reset verification link sent to ${targetEmail}`,
    previewOtpCode: code,
    previewOtpLink: verifyLink,
  });
});

// 4. Verify OTP Code (Final step for REGISTER, LOGIN, or FORGOT)
app.post('/api/auth/verify-otp', (req, res) => {
  const { email, otpCode, purpose, newPassword } = req.body;
  const targetEmail = (email || '').trim().toLowerCase();
  const inputOtp = (otpCode || '').trim();

  if (!targetEmail || !inputOtp) {
    return res.status(400).json({ error: 'Email and 6-digit OTP code are required.' });
  }

  const record = getOtpRecord(targetEmail);

  if (!record) {
    return res.status(400).json({ error: 'No OTP requested for this email or code has expired. Please click "Resend Code".' });
  }

  if (record.code !== inputOtp) {
    return res.status(400).json({ error: 'Invalid 6-digit verification code. Please check your email and try again.' });
  }

  const db = loadDB();

  // OTP IS VALID! Process action based on purpose
  const activePurpose = purpose || record.purpose;

  if (activePurpose === 'REGISTER') {
    const payload = record.payload;
    if (!payload || !payload.username || !payload.passwordHash) {
      return res.status(400).json({ error: 'Registration payload lost. Please re-enter signup details.' });
    }

    // Double check email/username duplicate in DB
    const duplicate = db.users.find(
      (u) => u.email.toLowerCase() === targetEmail || u.username.toLowerCase() === payload.username!.toLowerCase()
    );

    if (duplicate) {
      removeOtpRecord(targetEmail);
      return res.status(400).json({ error: 'Username or email already exists.' });
    }

    let referrerId: string | undefined = undefined;
    if (payload.referralCode) {
      const refUser = db.users.find((u) => u.referralCode === payload.referralCode);
      if (refUser) {
        referrerId = refUser.id;
        const bonus = db.settings.referralPointsBonus || 10;
        refUser.referralPoints = (refUser.referralPoints || 0) + bonus;
        refUser.airdropPoints = (refUser.airdropPoints || 0) + bonus;
        refUser.referralCount = (refUser.referralCount || 0) + 1;

        db.referralLogs.push({
          id: 'ref-' + Date.now(),
          referrerId: refUser.id,
          referredUsername: payload.username,
          pointsAwarded: bonus,
          ruleTriggered: 'REGISTRATION',
          createdAt: new Date().toISOString(),
        });

        db.pointTransactions.push({
          id: 'pt-' + Date.now(),
          userId: refUser.id,
          amount: bonus,
          type: 'REFERRAL_BONUS',
          description: `Earned +${bonus} XP for inviting user ${payload.username}`,
          createdAt: new Date().toISOString(),
        });

        db.notifications.push({
          id: 'notif-' + Date.now(),
          userId: refUser.id,
          title: 'Referral Bonus Received! 🎁',
          message: `You earned +${bonus} XP for inviting @${payload.username}!`,
          type: 'REFERRAL',
          isRead: false,
          createdAt: new Date().toISOString(),
        });
      }
    }

    const newReferralCode = payload.username.toUpperCase().slice(0, 5) + Math.floor(100 + Math.random() * 900);

    const newUser = {
      id: 'usr-' + Date.now(),
      email: targetEmail,
      username: payload.username,
      passwordHash: payload.passwordHash,
      role: 'USER',
      avatar: `https://api.dicebear.com/7.x/bottts/svg?seed=${payload.username}`,
      country: 'Nigeria',
      isEmailVerified: true,
      isBanned: false,
      availableBalance: 0.0,
      pendingBalance: 0.0,
      totalWithdrawn: 0.0,
      airdropPoints: 50, // Welcome signup bonus
      referralPoints: 0,
      dailyStreak: 1,
      referralCode: newReferralCode,
      referredById: referrerId,
      createdAt: new Date().toISOString(),
      lastLoginAt: new Date().toISOString(),
    };

    db.users.push(newUser);
    removeOtpRecord(targetEmail);
    saveDB(db);

    const token = jwt.sign(
      { id: newUser.id, email: newUser.email, username: newUser.username, role: newUser.role },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    const { passwordHash: _, ...safeUser } = newUser;
    return res.json({
      token,
      user: safeUser,
      message: 'Email verified! Account created successfully.',
    });

  } else if (activePurpose === 'LOGIN') {
    const user = db.users.find((u) => u.email.toLowerCase() === targetEmail);

    if (!user) {
      removeOtpRecord(targetEmail);
      return res.status(404).json({ error: 'User account not found.' });
    }

    user.isEmailVerified = true;
    user.lastLoginAt = new Date().toISOString();
    removeOtpRecord(targetEmail);
    saveDB(db);

    const token = jwt.sign(
      { id: user.id, email: user.email, username: user.username, role: user.role },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    const { passwordHash: _, ...safeUser } = user;
    return res.json({
      token,
      user: safeUser,
      message: 'Login verified successfully!',
    });

  } else if (activePurpose === 'FORGOT') {
    const user = db.users.find((u) => u.email.toLowerCase() === targetEmail);

    if (!user) {
      removeOtpRecord(targetEmail);
      return res.status(404).json({ error: 'User account not found.' });
    }

    const finalPasswordHash = record.payload?.passwordHash || (newPassword ? bcrypt.hashSync(newPassword.trim(), 10) : null);

    if (!finalPasswordHash) {
      return res.status(400).json({ error: 'Please provide a new password to reset.' });
    }

    user.passwordHash = finalPasswordHash;
    user.isEmailVerified = true;
    removeOtpRecord(targetEmail);
    saveDB(db);

    // Auto-login user after password reset
    const token = jwt.sign(
      { id: user.id, email: user.email, username: user.username, role: user.role },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    const { passwordHash: _, ...safeUser } = user;
    return res.json({
      token,
      user: safeUser,
      message: 'Password reset verified and updated! You are now logged in.',
    });
  }

  return res.status(400).json({ error: 'Unknown verification purpose.' });
});

// 5. Direct GET Endpoint for Magic Verification Links
app.get('/api/auth/verify-link', (req, res) => {
  const targetEmail = (req.query.email || req.query.verifyEmail || '').toString().trim().toLowerCase();
  const inputOtp = (req.query.otp || req.query.code || req.query.otpCode || '').toString().trim();
  const rawBaseUrl = process.env.APP_URL || `${req.protocol}://${req.get('host')}`;
  const baseUrl = rawBaseUrl.replace(/\/$/, '');

  if (!targetEmail || !inputOtp) {
    return res.redirect(`${baseUrl}/?authError=${encodeURIComponent('Invalid verification link parameters.')}`);
  }

  const record = getOtpRecord(targetEmail);
  if (!record || record.code !== inputOtp) {
    return res.redirect(`${baseUrl}/?authError=${encodeURIComponent('Verification link has expired or is invalid. Please request a new code.')}`);
  }

  const db = loadDB();
  const activePurpose = record.purpose;

  if (activePurpose === 'REGISTER') {
    const payload = record.payload;
    if (!payload || !payload.username || !payload.passwordHash) {
      return res.redirect(`${baseUrl}/?authError=${encodeURIComponent('Registration session expired. Please sign up again.')}`);
    }

    const duplicate = db.users.find(
      (u) => u.email.toLowerCase() === targetEmail || u.username.toLowerCase() === payload.username!.toLowerCase()
    );

    if (duplicate) {
      removeOtpRecord(targetEmail);
      return res.redirect(`${baseUrl}/?authError=${encodeURIComponent('Account with this username or email already exists.')}`);
    }

    let referrerId: string | undefined = undefined;
    if (payload.referralCode) {
      const refUser = db.users.find((u) => u.referralCode === payload.referralCode);
      if (refUser) {
        referrerId = refUser.id;
        const bonus = db.settings.referralPointsBonus || 10;
        refUser.referralPoints = (refUser.referralPoints || 0) + bonus;
        refUser.airdropPoints = (refUser.airdropPoints || 0) + bonus;
        refUser.referralCount = (refUser.referralCount || 0) + 1;
      }
    }

    const newReferralCode = payload.username.toUpperCase().slice(0, 5) + Math.floor(100 + Math.random() * 900);
    const newUser = {
      id: 'usr-' + Date.now(),
      email: targetEmail,
      username: payload.username,
      passwordHash: payload.passwordHash,
      role: 'USER',
      avatar: `https://api.dicebear.com/7.x/bottts/svg?seed=${payload.username}`,
      country: 'Nigeria',
      isEmailVerified: true,
      isBanned: false,
      availableBalance: 0.0,
      pendingBalance: 0.0,
      totalWithdrawn: 0.0,
      airdropPoints: 50,
      referralPoints: 0,
      dailyStreak: 1,
      referralCode: newReferralCode,
      referredById: referrerId,
      createdAt: new Date().toISOString(),
      lastLoginAt: new Date().toISOString(),
    };

    db.users.push(newUser);
    removeOtpRecord(targetEmail);
    saveDB(db);

    const token = jwt.sign(
      { id: newUser.id, email: newUser.email, username: newUser.username, role: newUser.role },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    return res.redirect(`${baseUrl}/?token=${token}&authSuccess=true&msg=${encodeURIComponent(`Welcome to TaskPoint, @${newUser.username}! Email verified.`)}`);
  } else {
    // LOGIN or FORGOT
    const user = db.users.find((u) => u.email.toLowerCase() === targetEmail);
    if (!user) {
      removeOtpRecord(targetEmail);
      return res.redirect(`${baseUrl}/?authError=${encodeURIComponent('User account not found.')}`);
    }

    user.isEmailVerified = true;
    user.lastLoginAt = new Date().toISOString();
    removeOtpRecord(targetEmail);
    saveDB(db);

    const token = jwt.sign(
      { id: user.id, email: user.email, username: user.username, role: user.role },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    return res.redirect(`${baseUrl}/?token=${token}&authSuccess=true&msg=${encodeURIComponent(`Welcome back, @${user.username}! Signed in via OTP link.`)}`);
  }
});

app.get('/api/auth/me', authenticateToken, (req: any, res) => {
  const db = loadDB();
  const user = db.users.find((u) => u.id === req.user.id);
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }
  const { passwordHash: _, ...safeUser } = user;
  return res.json({ user: safeUser });
});

app.post('/api/auth/streak-claim', authenticateToken, (req: any, res) => {
  const db = loadDB();
  const user = db.users.find((u) => u.id === req.user.id);
  if (!user) return res.status(404).json({ error: 'User not found' });

  if (user.isRestricted) {
    return res.status(403).json({ error: 'Your account is currently restricted from claiming daily streak bonuses.' });
  }

  const todayStr = new Date().toISOString().split('T')[0];

  if (user.lastStreakClaimDate === todayStr) {
    return res.status(400).json({ error: 'You have already claimed your daily streak bonus today! Please check back tomorrow.' });
  }

  const yesterdayDate = new Date(Date.now() - 86400000);
  const yesterdayStr = yesterdayDate.toISOString().split('T')[0];

  if (user.lastStreakClaimDate === yesterdayStr) {
    user.dailyStreak = (user.dailyStreak || 0) + 1;
  } else {
    // Missed a day or first claim
    user.dailyStreak = 1;
  }

  user.lastStreakClaimDate = todayStr;
  const streakBonus = 10;
  user.airdropPoints = (user.airdropPoints || 0) + streakBonus;

  db.pointTransactions.push({
    id: 'pt-' + Date.now(),
    userId: user.id,
    amount: streakBonus,
    type: 'DAILY_STREAK',
    description: `Claimed Day ${user.dailyStreak} streak bonus (+${streakBonus} XP)`,
    createdAt: new Date().toISOString(),
  });

  saveDB(db);
  const { passwordHash: _, ...safeUser } = user;
  return res.json({ user: safeUser, bonusPoints: streakBonus });
});

// --- TASKS ENDPOINTS ---
app.get('/api/tasks', (req, res) => {
  const { category, search, difficulty } = req.query;
  const authUser = getAuthenticatedUser(req);
  const db = loadDB();

  let filtered = db.tasks.filter((t) => t.status === 'ACTIVE');

  if (category && category !== 'ALL') {
    filtered = filtered.filter((t) => t.category === category);
  }
  if (difficulty && difficulty !== 'ALL') {
    filtered = filtered.filter((t) => t.difficulty === difficulty);
  }
  if (search) {
    const q = (search as string).toLowerCase();
    filtered = filtered.filter(
      (t) => t.title.toLowerCase().includes(q) || t.description.toLowerCase().includes(q)
    );
  }

  // Attach submission status and bookmark if user is logged in
  const mapped = filtered.map((task) => {
    let userSubmissionStatus = undefined;
    let isBookmarked = false;
    if (authUser) {
      const sub = db.submissions.find((s) => s.taskId === task.id && s.userId === authUser.id);
      if (sub) userSubmissionStatus = sub.status;

      isBookmarked = db.bookmarks.some((b) => b.taskId === task.id && b.userId === authUser.id);
    }
    return {
      ...task,
      userSubmissionStatus,
      isBookmarked,
    };
  });

  return res.json(mapped);
});

app.post('/api/tasks/bookmark', authenticateToken, (req: any, res) => {
  const { taskId } = req.body;
  const db = loadDB();
  const index = db.bookmarks.findIndex((b) => b.taskId === taskId && b.userId === req.user.id);
  let isBookmarked = false;

  if (index >= 0) {
    db.bookmarks.splice(index, 1);
    isBookmarked = false;
  } else {
    db.bookmarks.push({
      id: 'bm-' + Date.now(),
      taskId,
      userId: req.user.id,
      createdAt: new Date().toISOString(),
    });
    isBookmarked = true;
  }
  saveDB(db);
  return res.json({ isBookmarked });
});

// --- TASK SUBMISSIONS ENDPOINTS ---
app.post('/api/submissions', authenticateToken, (req: any, res) => {
  const { taskId, proofScreenshot, proofScreenshot2, proofText, proofUrl, proofUsername } = req.body;
  const db = loadDB();

  const task = db.tasks.find((t) => t.id === taskId);
  if (!task) return res.status(404).json({ error: 'Task not found' });

  const user = db.users.find((u) => u.id === req.user.id);
  if (!user) return res.status(404).json({ error: 'User not found' });

  if (user.isRestricted) {
    return res.status(403).json({ error: 'Your account is currently restricted from submitting task proofs.' });
  }

  if (task.totalSlots > 0 && task.totalSlots < 999999 && task.filledSlots >= task.totalSlots) {
    return res.status(400).json({ error: 'Task is fully completed! No slots remaining.' });
  }

  const existing = db.submissions.find((s) => s.taskId === taskId && s.userId === req.user.id);
  if (existing) {
    return res.status(400).json({ error: 'You have already submitted proof for this task!' });
  }

  const newSubmission = {
    id: 'sub-' + Date.now(),
    taskId,
    userId: user.id,
    proofScreenshot: proofScreenshot || null,
    proofScreenshot2: proofScreenshot2 || null,
    proofText: proofText || null,
    proofUrl: proofUrl || null,
    proofUsername: proofUsername || null,
    status: 'PENDING',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  db.submissions.push(newSubmission);
  user.pendingBalance += task.rewardCash;
  task.filledSlots += 1;

  saveDB(db);
  return res.json({ message: 'Submission uploaded successfully!', submission: newSubmission });
});

app.get('/api/submissions/my', authenticateToken, (req: any, res) => {
  const db = loadDB();
  const mySubmissions = db.submissions.filter((s) => s.userId === req.user.id);

  const populated = mySubmissions.map((s) => {
    const task = db.tasks.find((t) => t.id === s.taskId);
    const dispute = db.disputes.find((d) => d.submissionId === s.id);
    return {
      ...s,
      taskTitle: task?.title || 'Unknown Task',
      taskCategory: task?.category,
      rewardCash: task?.rewardCash,
      rewardPoints: task?.rewardPoints,
      dispute,
    };
  });

  return res.json(populated);
});

// --- WALLET & WITHDRAWALS ---
app.get('/api/wallet/history', authenticateToken, (req: any, res) => {
  const db = loadDB();
  const userWithdrawals = db.withdrawals.filter((w) => w.userId === req.user.id);
  return res.json(userWithdrawals);
});

app.post('/api/wallet/withdraw', authenticateToken, (req: any, res) => {
  const { amount, currency, method, details } = req.body;
  const db = loadDB();
  const user = db.users.find((u) => u.id === req.user.id);

  if (!user) return res.status(404).json({ error: 'User not found' });

  if (user.isRestricted) {
    return res.status(403).json({ error: 'Your account is currently restricted from requesting payouts.' });
  }

  const minAmount = db.settings.minWithdrawalUSD || 5.0;
  if (amount < minAmount) {
    return res.status(400).json({ error: `Minimum withdrawal amount is $${minAmount.toFixed(2)} USD` });
  }

  if (user.availableBalance < amount) {
    return res.status(400).json({ error: 'Insufficient available balance' });
  }

  // Deduct available balance and hold
  user.availableBalance -= amount;

  const newWithdrawal = {
    id: 'wd-' + Date.now(),
    userId: user.id,
    amount,
    currency: currency || 'USDT',
    method: method || 'USDT',
    details,
    status: 'PENDING',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  db.withdrawals.push(newWithdrawal);

  db.notifications.push({
    id: 'notif-' + Date.now(),
    userId: user.id,
    title: 'Withdrawal Requested 💸',
    message: `Your payout request of $${amount.toFixed(2)} USD is pending admin review.`,
    type: 'WITHDRAWAL',
    isRead: false,
    createdAt: new Date().toISOString(),
  });

  saveDB(db);
  return res.json({ message: 'Withdrawal submitted successfully', withdrawal: newWithdrawal });
});

// --- REFERRALS & LEADERBOARD ---
app.get('/api/referrals/my', authenticateToken, (req: any, res) => {
  const db = loadDB();
  const user = db.users.find((u) => u.id === req.user.id);
  if (!user) return res.status(404).json({ error: 'User not found' });

  const logs = db.referralLogs.filter((r) => r.referrerId === user.id);
  const referredUsers = db.users
    .filter((u) => u.referredById === user.id)
    .map((u) => ({
      username: u.username,
      avatar: u.avatar,
      createdAt: u.createdAt,
      airdropPoints: u.airdropPoints,
    }));

  return res.json({
    referralCode: user.referralCode,
    referralPoints: user.referralPoints,
    totalReferrals: referredUsers.length,
    history: logs,
    referredUsers,
    bonusPerReferral: db.settings.referralPointsBonus || 100,
  });
});

const GLOBAL_SEED_LEADERBOARD: any[] = [];

app.get('/api/leaderboard', (req, res) => {
  const { type = 'POINTS' } = req.query; // POINTS, EARNERS, REFERRALS
  const db = loadDB();

  // Combine DB users with global seed earners
  const realUserEntries = db.users.map((u) => {
    const cashEarned = (u.availableBalance || 0) + (u.totalWithdrawn || 0);
    const referralCount = db.users.filter((x) => x.referredById === u.id).length;
    const referralPoints = u.referralPoints !== undefined && u.referralPoints !== null ? u.referralPoints : (referralCount * 10);
    const airdropPoints = u.airdropPoints || 0;

    return {
      userId: u.id,
      username: u.username,
      avatar: u.avatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${u.username}`,
      country: u.country || 'Global',
      cashEarned,
      airdropPoints,
      referralPoints,
      referralCount,
    };
  });

  const combined = [...realUserEntries];
  GLOBAL_SEED_LEADERBOARD.forEach((seed) => {
    if (!combined.some((item) => item.userId === seed.userId || item.username === seed.username)) {
      combined.push(seed);
    }
  });

  if (type === 'EARNERS') {
    combined.sort((a, b) => b.cashEarned - a.cashEarned);
  } else if (type === 'REFERRALS') {
    combined.sort((a, b) => b.referralPoints - a.referralPoints);
  } else {
    combined.sort((a, b) => b.airdropPoints - a.airdropPoints);
  }

  const leaderboard = combined.slice(0, 20).map((u, idx) => {
    let primaryValue = u.airdropPoints;
    if (type === 'EARNERS') primaryValue = u.cashEarned;
    if (type === 'REFERRALS') primaryValue = u.referralPoints;

    return {
      rank: idx + 1,
      userId: u.userId,
      username: u.username,
      avatar: u.avatar,
      country: u.country,
      value: primaryValue,
      cashEarned: u.cashEarned,
      airdropPoints: u.airdropPoints,
      referralPoints: u.referralPoints,
      referralCount: u.referralCount,
      change: 0,
    };
  });

  return res.json(leaderboard);
});

// Airdrop Pool Statistics
app.get('/api/airdrop/stats', (req, res) => {
  const db = loadDB();
  const TOTAL_POOL_XP = 400000;

  const realUsersXP = db.users.reduce((acc, u) => acc + (u.airdropPoints || 0), 0);
  const seedUsersXP = GLOBAL_SEED_LEADERBOARD.filter(
    (seed) => !db.users.some((u) => u.id === seed.userId || u.username === seed.username)
  ).reduce((acc, seed) => acc + (seed.airdropPoints || 0), 0);

  const totalClaimedXP = realUsersXP + seedUsersXP;
  const availableToClaimXP = Math.max(0, TOTAL_POOL_XP - totalClaimedXP);

  return res.json({
    totalPoolXP: TOTAL_POOL_XP,
    totalClaimedXP,
    availableToClaimXP,
  });
});

// --- SUPPORT TICKETS ---
app.get('/api/support/tickets', authenticateToken, (req: any, res) => {
  const db = loadDB();
  const isAdmin = req.user.role === 'ADMIN' || req.user.role === 'SUPPORT' || req.user.role === 'MODERATOR';
  const tickets = isAdmin 
    ? [...db.tickets].sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())
    : db.tickets.filter((t) => t.userId === req.user.id).sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
  return res.json(tickets);
});

app.put('/api/support/tickets/:id/status', authenticateToken, (req: any, res) => {
  const { status } = req.body;
  const db = loadDB();
  const ticket = db.tickets.find((t) => t.id === req.params.id);
  if (!ticket) return res.status(404).json({ error: 'Ticket not found' });

  const isAdmin = req.user.role === 'ADMIN' || req.user.role === 'SUPPORT' || req.user.role === 'MODERATOR';
  if (!isAdmin && ticket.userId !== req.user.id) {
    return res.status(403).json({ error: 'Unauthorized' });
  }

  ticket.status = status;
  ticket.updatedAt = new Date().toISOString();

  if (isAdmin) {
    db.notifications.push({
      id: 'notif-' + Date.now(),
      userId: ticket.userId,
      title: 'Support Ticket Status Updated 🎟️',
      message: `Your ticket "${ticket.subject}" has been marked as ${status}.`,
      type: 'SUPPORT',
      isRead: false,
      createdAt: new Date().toISOString(),
    });
  }

  saveDB(db);
  return res.json(ticket);
});

app.post('/api/support/tickets', authenticateToken, (req: any, res) => {
  const { subject, category, priority, message } = req.body;
  const db = loadDB();
  const user = db.users.find((u) => u.id === req.user.id);

  const newTicket = {
    id: 'tkt-' + Date.now(),
    userId: req.user.id,
    username: user?.username,
    userEmail: user?.email,
    subject,
    category: category || 'General',
    priority: priority || 'MEDIUM',
    status: 'OPEN',
    replies: [
      {
        id: 'rep-' + Date.now(),
        ticketId: 'tkt-' + Date.now(),
        userId: req.user.id,
        username: user?.username || 'User',
        userAvatar: user?.avatar,
        message,
        isAdminReply: false,
        createdAt: new Date().toISOString(),
      },
    ],
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  db.tickets.push(newTicket);
  saveDB(db);
  return res.json(newTicket);
});

app.post('/api/support/tickets/:id/reply', authenticateToken, (req: any, res) => {
  const { message } = req.body;
  const db = loadDB();
  const ticket = db.tickets.find((t) => t.id === req.params.id);
  if (!ticket) return res.status(404).json({ error: 'Ticket not found' });

  const user = db.users.find((u) => u.id === req.user.id);
  const isAdmin = req.user.role === 'ADMIN' || req.user.role === 'SUPPORT';

  ticket.replies.push({
    id: 'rep-' + Date.now(),
    ticketId: ticket.id,
    userId: req.user.id,
    username: user?.username || 'Support Agent',
    userAvatar: user?.avatar,
    message,
    isAdminReply: isAdmin,
    createdAt: new Date().toISOString(),
  });

  ticket.status = isAdmin ? 'IN_PROGRESS' : 'OPEN';
  ticket.updatedAt = new Date().toISOString();

  if (isAdmin) {
    db.notifications.push({
      id: 'notif-' + Date.now(),
      userId: ticket.userId,
      title: 'Support Reply Received 💬',
      message: `Support replied to ticket: "${ticket.subject}"`,
      type: 'SUPPORT',
      isRead: false,
      createdAt: new Date().toISOString(),
    });
  }

  saveDB(db);
  return res.json(ticket);
});

// --- DISPUTES ---
app.post('/api/disputes', authenticateToken, (req: any, res) => {
  const { submissionId, reason, additionalProof } = req.body;
  const db = loadDB();

  const sub = db.submissions.find((s) => s.id === submissionId);
  if (!sub) return res.status(404).json({ error: 'Submission not found' });

  const existing = db.disputes.find((d) => d.submissionId === submissionId);
  if (existing) return res.status(400).json({ error: 'Dispute already opened for this submission' });

  const user = db.users.find((u) => u.id === req.user.id);

  const newDispute = {
    id: 'disp-' + Date.now(),
    submissionId,
    userId: req.user.id,
    username: user?.username,
    reason,
    additionalProof: additionalProof || null,
    status: 'PENDING',
    createdAt: new Date().toISOString(),
  };

  db.disputes.push(newDispute);
  saveDB(db);
  return res.json(newDispute);
});

// --- NOTIFICATIONS ---
app.get('/api/notifications', authenticateToken, (req: any, res) => {
  const db = loadDB();
  const myNotifs = db.notifications.filter((n) => n.userId === req.user.id);
  return res.json(myNotifs.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
});

app.put('/api/notifications/read-all', authenticateToken, (req: any, res) => {
  const db = loadDB();
  db.notifications.forEach((n) => {
    if (n.userId === req.user.id) n.isRead = true;
  });
  saveDB(db);
  return res.json({ success: true });
});

// --- ANNOUNCEMENTS ---
app.get('/api/announcements', (req, res) => {
  const db = loadDB();
  return res.json(db.announcements.filter((a) => a.isActive));
});

// --- ADMIN ENDPOINTS (Protected) ---
function requireAdmin(req: Request & { user?: any }, res: Response, next: any) {
  if (!req.user || (req.user.role !== 'ADMIN' && req.user.role !== 'MODERATOR' && req.user.role !== 'SUPPORT')) {
    return res.status(403).json({ error: 'Admin access privileges required' });
  }
  next();
}

app.get('/api/admin/stats', authenticateToken, requireAdmin, (req, res) => {
  const db = loadDB();

  const totalUsers = db.users.length;
  const activeUsers = db.users.filter((u) => !u.isBanned).length;
  const pendingSubmissions = db.submissions.filter((s) => s.status === 'PENDING').length;
  const pendingWithdrawals = db.withdrawals.filter((w) => w.status === 'PENDING').length;

  const todayStr = new Date().toISOString().split('T')[0];
  const todaySignups = db.users.filter((u) => u.createdAt && u.createdAt.startsWith(todayStr)).length;

  const approvedToday = db.submissions.filter(
    (s) => s.status === 'APPROVED' && s.updatedAt && s.updatedAt.startsWith(todayStr)
  ).length;

  const rejectedToday = db.submissions.filter(
    (s) => s.status === 'REJECTED' && s.updatedAt && s.updatedAt.startsWith(todayStr)
  ).length;

  const totalCashDistributed = db.users.reduce((acc, u) => acc + (u.totalWithdrawn || 0) + (u.availableBalance || 0), 0);
  const totalPointsDistributed = db.users.reduce((acc, u) => acc + (u.airdropPoints || 0), 0);
  const totalReferralPointsAwarded = db.users.reduce((acc, u) => acc + (u.referralPoints || 0), 0);

  // Generate 7-day activity metrics based on actual data
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const dailyStats = days.map((date) => {
    return {
      date,
      users: totalUsers,
      tasks: db.submissions.length,
      payouts: totalCashDistributed,
    };
  });

  return res.json({
    totalUsers,
    activeUsers,
    todaySignups,
    pendingSubmissions,
    approvedToday,
    rejectedToday,
    pendingWithdrawals,
    totalCashDistributed,
    totalPointsDistributed,
    totalReferralPointsAwarded,
    dailyStats,
  });
});

// Admin Submissions List & Actions
app.get('/api/admin/submissions', authenticateToken, requireAdmin, (req, res) => {
  const db = loadDB();
  const populated = db.submissions.map((s) => {
    const task = db.tasks.find((t) => t.id === s.taskId);
    const user = db.users.find((u) => u.id === s.userId);
    return {
      ...s,
      taskTitle: task?.title || 'Unknown Task',
      taskCategory: task?.category,
      rewardCash: task?.rewardCash,
      rewardPoints: task?.rewardPoints,
      username: user?.username || 'Unknown User',
      userEmail: user?.email,
      userAvatar: user?.avatar,
    };
  });
  return res.json(populated);
});

app.put('/api/admin/submissions/:id', authenticateToken, requireAdmin, (req: any, res) => {
  const { status, adminComment } = req.body;
  const db = loadDB();
  const sub = db.submissions.find((s) => s.id === req.params.id);
  if (!sub) return res.status(404).json({ error: 'Submission not found' });

  const user = db.users.find((u) => u.id === sub.userId);
  const task = db.tasks.find((t) => t.id === sub.taskId);

  const prevStatus = sub.status;
  sub.status = status;
  sub.adminComment = adminComment || null;
  sub.updatedAt = new Date().toISOString();

  // If approving for the first time
  if (status === 'APPROVED' && prevStatus !== 'APPROVED') {
    if (user && task) {
      // Deduct pending balance and move to available balance
      user.pendingBalance = Math.max(0, user.pendingBalance - task.rewardCash);
      user.availableBalance += task.rewardCash;
      user.airdropPoints += task.rewardPoints;

      db.pointTransactions.push({
        id: 'pt-' + Date.now(),
        userId: user.id,
        amount: task.rewardPoints,
        type: 'TASK_REWARD',
        description: `Approved task: "${task.title}"`,
        createdAt: new Date().toISOString(),
      });

      db.notifications.push({
        id: 'notif-' + Date.now(),
        userId: user.id,
        title: 'Task Approved! 🟢',
        message: `Your task "${task.title}" was approved! $${task.rewardCash.toFixed(2)} + ${task.rewardPoints} Points added to your wallet!`,
        type: 'TASK',
        isRead: false,
        createdAt: new Date().toISOString(),
      });
    }
  } else if (status === 'REJECTED' && prevStatus === 'PENDING') {
    if (user && task) {
      user.pendingBalance = Math.max(0, user.pendingBalance - task.rewardCash);

      db.notifications.push({
        id: 'notif-' + Date.now(),
        userId: user.id,
        title: 'Task Submission Rejected 🔴',
        message: `Submission for "${task.title}" rejected. Reason: ${adminComment || 'Requirements not met'}. Click to dispute if this is an error.`,
        type: 'DISPUTE',
        isRead: false,
        createdAt: new Date().toISOString(),
      });
    }
  }

  saveDB(db);
  return res.json({ message: 'Submission updated', submission: sub });
});

// Admin Task CRUD
app.post('/api/admin/tasks', authenticateToken, requireAdmin, (req, res) => {
  const db = loadDB();
  const newTask = {
    id: 'task-' + Date.now(),
    ...req.body,
    filledSlots: 0,
    status: req.body.status || 'ACTIVE',
    createdAt: new Date().toISOString(),
  };
  db.tasks.push(newTask);
  saveDB(db);
  return res.json(newTask);
});

app.put('/api/admin/tasks/:id', authenticateToken, requireAdmin, (req, res) => {
  const db = loadDB();
  const taskIdx = db.tasks.findIndex((t) => t.id === req.params.id);
  if (taskIdx === -1) return res.status(404).json({ error: 'Task not found' });

  db.tasks[taskIdx] = {
    ...db.tasks[taskIdx],
    ...req.body,
    updatedAt: new Date().toISOString(),
  };
  saveDB(db);
  return res.json(db.tasks[taskIdx]);
});

app.delete('/api/admin/tasks/:id', authenticateToken, requireAdmin, (req, res) => {
  const db = loadDB();
  db.tasks = db.tasks.filter((t) => t.id !== req.params.id);
  saveDB(db);
  return res.json({ success: true });
});

// Admin Users Management
app.get('/api/admin/users', authenticateToken, requireAdmin, (req, res) => {
  const db = loadDB();
  const safeUsers = db.users.map(({ passwordHash, ...u }) => u);
  return res.json(safeUsers);
});

// Admin Add Support Account
app.post('/api/admin/users/support', authenticateToken, requireAdmin, (req, res) => {
  const { username, email, password } = req.body;
  if (!username || !email || !password) {
    return res.status(400).json({ error: 'Username, email, and password are required' });
  }

  const db = loadDB();
  const existing = db.users.find(
    (u) => u.email.toLowerCase() === email.toLowerCase() || u.username.toLowerCase() === username.toLowerCase()
  );
  if (existing) {
    return res.status(400).json({ error: 'Username or email is already in use' });
  }

  const salt = bcrypt.genSaltSync(10);
  const passwordHash = bcrypt.hashSync(password, salt);

  const newUser = {
    id: 'user-' + Date.now(),
    email,
    username,
    passwordHash,
    role: 'SUPPORT',
    country: 'Global Support',
    isEmailVerified: true,
    isBanned: false,
    isRestricted: false,
    availableBalance: 0,
    pendingBalance: 0,
    totalWithdrawn: 0,
    airdropPoints: 0,
    referralPoints: 0,
    dailyStreak: 0,
    referralCode: 'SUP' + Math.floor(1000 + Math.random() * 9000),
    createdAt: new Date().toISOString(),
  };

  db.users.push(newUser);
  saveDB(db);

  const { passwordHash: _, ...safeUser } = newUser;
  return res.json({ message: 'Support account created successfully', user: safeUser });
});

// Admin Update User Role (e.g., Promote to Support or Demote to User)
app.put('/api/admin/users/:id/role', authenticateToken, requireAdmin, (req, res) => {
  const { role } = req.body;
  const db = loadDB();
  const user = db.users.find((u) => u.id === req.params.id);
  if (!user) return res.status(404).json({ error: 'User not found' });

  if (!['USER', 'SUPPORT', 'ADMIN', 'MODERATOR'].includes(role)) {
    return res.status(400).json({ error: 'Invalid role' });
  }

  user.role = role;
  saveDB(db);

  const { passwordHash: _, ...safeUser } = user;
  return res.json({ success: true, user: safeUser });
});

// Admin Update User Status (Ban / Restrict / Unban)
app.put('/api/admin/users/:id/status', authenticateToken, requireAdmin, (req, res) => {
  const { isBanned, isRestricted, status, reason } = req.body;
  const db = loadDB();
  const user = db.users.find((u) => u.id === req.params.id);
  if (!user) return res.status(404).json({ error: 'User not found' });

  if (status === 'BANNED') {
    user.isBanned = true;
    user.isRestricted = false;
  } else if (status === 'RESTRICTED') {
    user.isBanned = false;
    user.isRestricted = true;
  } else if (status === 'ACTIVE') {
    user.isBanned = false;
    user.isRestricted = false;
  } else {
    if (typeof isBanned === 'boolean') user.isBanned = isBanned;
    if (typeof isRestricted === 'boolean') user.isRestricted = isRestricted;
  }

  // Push notification to target user
  let notifMsg = 'Your account status was updated by an administrator.';
  if (user.isBanned) {
    notifMsg = `Your account has been BANNED by an administrator.${reason ? ` Reason: ${reason}` : ''}`;
  } else if (user.isRestricted) {
    notifMsg = `Your account has been RESTRICTED. Submissions and payouts are temporarily disabled.${reason ? ` Reason: ${reason}` : ''}`;
  } else {
    notifMsg = 'Your account status has been set to ACTIVE. Full access restored.';
  }

  if (!db.notifications) db.notifications = [];
  db.notifications.push({
    id: 'notif-' + Date.now(),
    userId: user.id,
    title: user.isBanned ? 'Account Banned' : user.isRestricted ? 'Account Restricted' : 'Account Reactivated',
    message: notifMsg,
    read: false,
    createdAt: new Date().toISOString(),
  });

  saveDB(db);
  const { passwordHash: _, ...safeUser } = user;
  return res.json({ success: true, user: safeUser });
});

// Admin Delete User / Support Account
app.delete('/api/admin/users/:id', authenticateToken, requireAdmin, (req: any, res) => {
  const db = loadDB();
  const index = db.users.findIndex((u) => u.id === req.params.id);
  if (index === -1) return res.status(404).json({ error: 'User not found' });

  const targetUser = db.users[index];

  // Protect the primary root admin account 'usr-admin-01' from being deleted
  if (targetUser.id === 'usr-admin-01') {
    return res.status(403).json({ error: 'The primary system administrator account cannot be deleted.' });
  }

  // Prevent an admin from deleting their own active logged-in account
  if (targetUser.id === req.user.id) {
    return res.status(403).json({ error: 'You cannot delete your own active admin session account.' });
  }

  // Remove associated records
  if (db.submissions) db.submissions = db.submissions.filter((s) => s.userId !== targetUser.id);
  if (db.withdrawals) db.withdrawals = db.withdrawals.filter((w) => w.userId !== targetUser.id);
  if (db.pointTransactions) db.pointTransactions = db.pointTransactions.filter((pt) => pt.userId !== targetUser.id);
  if (db.referralLogs) db.referralLogs = db.referralLogs.filter((rl) => rl.referrerId !== targetUser.id && rl.referredId !== targetUser.id);
  if (db.notifications) db.notifications = db.notifications.filter((n) => n.userId !== targetUser.id);

  db.users.splice(index, 1);
  saveDB(db);
  return res.json({ success: true, message: `Account @${targetUser.username} was permanently deleted.` });
});

app.put('/api/admin/users/:id/adjust-balance', authenticateToken, requireAdmin, (req, res) => {
  const { availableBalance, airdropPoints } = req.body;
  const db = loadDB();
  const user = db.users.find((u) => u.id === req.params.id);
  if (!user) return res.status(404).json({ error: 'User not found' });

  if (typeof availableBalance === 'number') user.availableBalance = availableBalance;
  if (typeof airdropPoints === 'number') user.airdropPoints = airdropPoints;

  saveDB(db);
  return res.json({ success: true, user });
});

// Admin Withdrawals Management
app.get('/api/admin/withdrawals', authenticateToken, requireAdmin, (req, res) => {
  const db = loadDB();
  const populated = db.withdrawals.map((w) => {
    const user = db.users.find((u) => u.id === w.userId);
    return {
      ...w,
      username: user?.username || 'Unknown',
      userEmail: user?.email,
    };
  });
  return res.json(populated);
});

app.put('/api/admin/withdrawals/:id', authenticateToken, requireAdmin, (req, res) => {
  const { status, paymentRef, adminNotes } = req.body;
  const db = loadDB();
  const w = db.withdrawals.find((item) => item.id === req.params.id);
  if (!w) return res.status(404).json({ error: 'Withdrawal not found' });

  const prevStatus = w.status;
  w.status = status;
  w.paymentRef = paymentRef || w.paymentRef;
  w.adminNotes = adminNotes || w.adminNotes;
  w.updatedAt = new Date().toISOString();

  const user = db.users.find((u) => u.id === w.userId);

  if (status === 'APPROVED' && prevStatus !== 'APPROVED' && user) {
    user.totalWithdrawn += w.amount;

    db.notifications.push({
      id: 'notif-' + Date.now(),
      userId: user.id,
      title: 'Withdrawal Approved! 💰',
      message: `Your payment of $${w.amount.toFixed(2)} USD has been processed! Ref: ${paymentRef || 'PAYOUT-OK'}`,
      type: 'WITHDRAWAL',
      isRead: false,
      createdAt: new Date().toISOString(),
    });
  } else if (status === 'REJECTED' && prevStatus === 'PENDING' && user) {
    // Refund balance back to available
    user.availableBalance += w.amount;

    db.notifications.push({
      id: 'notif-' + Date.now(),
      userId: user.id,
      title: 'Withdrawal Declined ❌',
      message: `Withdrawal request was declined and $${w.amount.toFixed(2)} USD returned to your available balance. Reason: ${adminNotes || 'Invalid account details'}`,
      type: 'WITHDRAWAL',
      isRead: false,
      createdAt: new Date().toISOString(),
    });
  }

  saveDB(db);
  return res.json({ message: 'Withdrawal updated', withdrawal: w });
});

// Admin Disputes
app.get('/api/admin/disputes', authenticateToken, requireAdmin, (req, res) => {
  const db = loadDB();
  const populated = db.disputes.map((d) => {
    const sub = db.submissions.find((s) => s.id === d.submissionId);
    const task = sub ? db.tasks.find((t) => t.id === sub.taskId) : null;
    const user = db.users.find((u) => u.id === d.userId);
    return {
      ...d,
      submission: sub,
      taskTitle: task?.title,
      rewardCash: task?.rewardCash,
      rewardPoints: task?.rewardPoints,
      username: user?.username,
    };
  });
  return res.json(populated);
});

app.put('/api/admin/disputes/:id', authenticateToken, requireAdmin, (req, res) => {
  const { status, adminComment } = req.body; // APPROVED or REJECTED
  const db = loadDB();
  const dispute = db.disputes.find((d) => d.id === req.params.id);
  if (!dispute) return res.status(404).json({ error: 'Dispute not found' });

  dispute.status = status;
  dispute.adminComment = adminComment;

  const sub = db.submissions.find((s) => s.id === dispute.submissionId);
  if (sub) {
    if (status === 'APPROVED') {
      sub.status = 'APPROVED';
      const user = db.users.find((u) => u.id === dispute.userId);
      const task = db.tasks.find((t) => t.id === sub.taskId);
      if (user && task) {
        user.availableBalance += task.rewardCash;
        user.airdropPoints += task.rewardPoints;

        db.notifications.push({
          id: 'notif-' + Date.now(),
          userId: user.id,
          title: 'Dispute Approved! 🎉',
          message: `Your dispute was reviewed and accepted! $${task.rewardCash.toFixed(2)} + ${task.rewardPoints} Points added to wallet.`,
          type: 'DISPUTE',
          isRead: false,
          createdAt: new Date().toISOString(),
        });
      }
    } else {
      db.notifications.push({
        id: 'notif-' + Date.now(),
        userId: dispute.userId,
        title: 'Dispute Decision ℹ️',
        message: `Your dispute review was finalized as REJECTED. Comment: ${adminComment || 'Original decision upheld.'}`,
        type: 'DISPUTE',
        isRead: false,
        createdAt: new Date().toISOString(),
      });
    }
  }

  saveDB(db);
  return res.json(dispute);
});

// Admin System Settings
app.get('/api/admin/settings', (req, res) => {
  const db = loadDB();
  return res.json(db.settings);
});

app.put('/api/admin/settings', authenticateToken, requireAdmin, (req, res) => {
  const db = loadDB();
  db.settings = { ...db.settings, ...req.body };
  saveDB(db);
  return res.json(db.settings);
});

// Announcements CRUD
app.post('/api/admin/announcements', authenticateToken, requireAdmin, (req, res) => {
  const db = loadDB();
  const newAnc = {
    id: 'anc-' + Date.now(),
    ...req.body,
    isActive: true,
    createdAt: new Date().toISOString(),
  };
  db.announcements.push(newAnc);
  saveDB(db);
  return res.json(newAnc);
});

// SERVER STARTUP & VITE INTEGRATION
async function startServer() {
  // Vite Dev Server Middleware or Static Production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR === 'true' ? false : undefined,
        watch: process.env.DISABLE_HMR === 'true' ? null : {},
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`TaskPoint Fullstack Server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
