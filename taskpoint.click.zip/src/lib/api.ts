import { User, Task, TaskSubmission, Withdrawal, SupportTicket, Dispute, Notification, Announcement, LeaderboardEntry, SystemSettings, AdminStats, AirdropStats } from '../types';

const API_BASE = '/api';

function getAuthHeader(): Record<string, string> {
  const token = localStorage.getItem('taskpoint_token');
  return token ? { Authorization: `Bearer ${token}` } : {};
}

async function handleResponse<T>(res: Response): Promise<T> {
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.error || 'API Request failed');
  }
  return data as T;
}

export const api = {
  // Auth
  async register(body: { username: string; email: string; password: string; referralCode?: string }) {
    const res = await fetch(`${API_BASE}/auth/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    return handleResponse<{ requireOtp?: boolean; email: string; message: string; token?: string; user?: User }>(res);
  },

  async login(body: { emailOrUsername: string; password: string }) {
    const res = await fetch(`${API_BASE}/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    return handleResponse<{ requireOtp?: boolean; email: string; message: string; token?: string; user?: User }>(res);
  },

  async forgotPassword(body: { email: string; newPassword?: string }) {
    const res = await fetch(`${API_BASE}/auth/forgot-password`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    return handleResponse<{ requireOtp?: boolean; email: string; message: string }>(res);
  },

  async sendOtp(body: { email: string; purpose: 'REGISTER' | 'LOGIN' | 'FORGOT' }) {
    const res = await fetch(`${API_BASE}/auth/send-otp`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    return handleResponse<{ message: string; email: string }>(res);
  },

  async verifyOtp(body: { email: string; otpCode: string; purpose: 'REGISTER' | 'LOGIN' | 'FORGOT'; newPassword?: string }) {
    const res = await fetch(`${API_BASE}/auth/verify-otp`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    return handleResponse<{ token?: string; user?: User; message: string }>(res);
  },

  async getMe() {
    const res = await fetch(`${API_BASE}/auth/me`, {
      headers: { ...getAuthHeader() },
    });
    return handleResponse<{ user: User }>(res);
  },

  async claimStreak() {
    const res = await fetch(`${API_BASE}/auth/streak-claim`, {
      method: 'POST',
      headers: { ...getAuthHeader() },
    });
    return handleResponse<{ user: User; bonusPoints: number }>(res);
  },

  // Tasks
  async getTasks(params?: { category?: string; search?: string; difficulty?: string }) {
    const query = new URLSearchParams(params as any).toString();
    const res = await fetch(`${API_BASE}/tasks?${query}`, {
      headers: { ...getAuthHeader() },
    });
    return handleResponse<Task[]>(res);
  },

  async toggleBookmark(taskId: string) {
    const res = await fetch(`${API_BASE}/tasks/bookmark`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...getAuthHeader() },
      body: JSON.stringify({ taskId }),
    });
    return handleResponse<{ isBookmarked: boolean }>(res);
  },

  // Submissions
  async submitTaskProof(body: {
    taskId: string;
    proofScreenshot?: string;
    proofScreenshot2?: string;
    proofText?: string;
    proofUrl?: string;
    proofUsername?: string;
  }) {
    const res = await fetch(`${API_BASE}/submissions`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...getAuthHeader() },
      body: JSON.stringify(body),
    });
    return handleResponse<{ message: string; submission: TaskSubmission }>(res);
  },

  async getMySubmissions() {
    const res = await fetch(`${API_BASE}/submissions/my`, {
      headers: { ...getAuthHeader() },
    });
    return handleResponse<TaskSubmission[]>(res);
  },

  // Wallet
  async getWalletHistory() {
    const res = await fetch(`${API_BASE}/wallet/history`, {
      headers: { ...getAuthHeader() },
    });
    return handleResponse<Withdrawal[]>(res);
  },

  async requestWithdrawal(body: { amount: number; currency: 'USD' | 'USDT'; method: string; details: string }) {
    const res = await fetch(`${API_BASE}/wallet/withdraw`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...getAuthHeader() },
      body: JSON.stringify(body),
    });
    return handleResponse<{ message: string; withdrawal: Withdrawal }>(res);
  },

  // Referrals
  async getReferralInfo() {
    const res = await fetch(`${API_BASE}/referrals/my`, {
      headers: { ...getAuthHeader() },
    });
    return handleResponse<{
      referralCode: string;
      referralPoints: number;
      totalReferrals: number;
      history: any[];
      referredUsers: any[];
      bonusPerReferral: number;
    }>(res);
  },

  // Leaderboard
  async getLeaderboard(type: 'POINTS' | 'EARNERS' | 'REFERRALS' = 'POINTS') {
    const res = await fetch(`${API_BASE}/leaderboard?type=${type}`);
    return handleResponse<LeaderboardEntry[]>(res);
  },

  // Support
  async getTickets() {
    const res = await fetch(`${API_BASE}/support/tickets`, {
      headers: { ...getAuthHeader() },
    });
    return handleResponse<SupportTicket[]>(res);
  },

  async createTicket(body: { subject: string; category: string; priority: string; message: string }) {
    const res = await fetch(`${API_BASE}/support/tickets`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...getAuthHeader() },
      body: JSON.stringify(body),
    });
    return handleResponse<SupportTicket>(res);
  },

  async replyTicket(ticketId: string, message: string) {
    const res = await fetch(`${API_BASE}/support/tickets/${ticketId}/reply`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...getAuthHeader() },
      body: JSON.stringify({ message }),
    });
    return handleResponse<SupportTicket>(res);
  },

  async updateTicketStatus(ticketId: string, status: string) {
    const res = await fetch(`${API_BASE}/support/tickets/${ticketId}/status`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', ...getAuthHeader() },
      body: JSON.stringify({ status }),
    });
    return handleResponse<SupportTicket>(res);
  },

  // Disputes
  async submitDispute(body: { submissionId: string; reason: string; additionalProof?: string }) {
    const res = await fetch(`${API_BASE}/disputes`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...getAuthHeader() },
      body: JSON.stringify(body),
    });
    return handleResponse<Dispute>(res);
  },

  // Notifications
  async getNotifications() {
    const res = await fetch(`${API_BASE}/notifications`, {
      headers: { ...getAuthHeader() },
    });
    return handleResponse<Notification[]>(res);
  },

  async markNotificationsRead() {
    const res = await fetch(`${API_BASE}/notifications/read-all`, {
      method: 'PUT',
      headers: { ...getAuthHeader() },
    });
    return handleResponse<{ success: boolean }>(res);
  },

  // Announcements
  async getAnnouncements() {
    const res = await fetch(`${API_BASE}/announcements`);
    return handleResponse<Announcement[]>(res);
  },

  // Airdrop Stats
  async getAirdropStats() {
    const res = await fetch(`${API_BASE}/airdrop/stats`);
    return handleResponse<AirdropStats>(res);
  },

  // ADMIN API CALLS
  async getAdminStats() {
    const res = await fetch(`${API_BASE}/admin/stats`, {
      headers: { ...getAuthHeader() },
    });
    return handleResponse<AdminStats>(res);
  },

  async getAdminSubmissions() {
    const res = await fetch(`${API_BASE}/admin/submissions`, {
      headers: { ...getAuthHeader() },
    });
    return handleResponse<TaskSubmission[]>(res);
  },

  async reviewSubmission(id: string, body: { status: 'APPROVED' | 'REJECTED'; adminComment?: string }) {
    const res = await fetch(`${API_BASE}/admin/submissions/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', ...getAuthHeader() },
      body: JSON.stringify(body),
    });
    return handleResponse<{ message: string; submission: TaskSubmission }>(res);
  },

  async adminCreateTask(taskData: any) {
    const res = await fetch(`${API_BASE}/admin/tasks`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...getAuthHeader() },
      body: JSON.stringify(taskData),
    });
    return handleResponse<Task>(res);
  },

  async adminUpdateTask(id: string, taskData: any) {
    const res = await fetch(`${API_BASE}/admin/tasks/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', ...getAuthHeader() },
      body: JSON.stringify(taskData),
    });
    return handleResponse<Task>(res);
  },

  async adminDeleteTask(id: string) {
    const res = await fetch(`${API_BASE}/admin/tasks/${id}`, {
      method: 'DELETE',
      headers: { ...getAuthHeader() },
    });
    return handleResponse<{ success: boolean }>(res);
  },

  async adminGetUsers() {
    const res = await fetch(`${API_BASE}/admin/users`, {
      headers: { ...getAuthHeader() },
    });
    return handleResponse<User[]>(res);
  },

  async adminCreateSupport(body: { username: string; email: string; password: string }) {
    const res = await fetch(`${API_BASE}/admin/users/support`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...getAuthHeader() },
      body: JSON.stringify(body),
    });
    return handleResponse<{ message: string; user: User }>(res);
  },

  async adminUpdateUserRole(id: string, role: string) {
    const res = await fetch(`${API_BASE}/admin/users/${id}/role`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', ...getAuthHeader() },
      body: JSON.stringify({ role }),
    });
    return handleResponse<{ success: boolean; user: User }>(res);
  },

  async adminUpdateUserStatus(id: string, body: { isBanned?: boolean; isRestricted?: boolean; status?: 'ACTIVE' | 'BANNED' | 'RESTRICTED'; reason?: string }) {
    const res = await fetch(`${API_BASE}/admin/users/${id}/status`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', ...getAuthHeader() },
      body: JSON.stringify(body),
    });
    return handleResponse<{ success: boolean; user: User }>(res);
  },

  async adminDeleteUser(id: string) {
    const res = await fetch(`${API_BASE}/admin/users/${id}`, {
      method: 'DELETE',
      headers: { ...getAuthHeader() },
    });
    return handleResponse<{ success: boolean; message: string }>(res);
  },

  async adminSetUserBan(id: string, isBanned: boolean) {
    const res = await fetch(`${API_BASE}/admin/users/${id}/status`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', ...getAuthHeader() },
      body: JSON.stringify({ isBanned }),
    });
    return handleResponse<{ success: boolean; isBanned: boolean }>(res);
  },

  async adminAdjustUserBalance(id: string, body: { availableBalance?: number; airdropPoints?: number }) {
    const res = await fetch(`${API_BASE}/admin/users/${id}/adjust-balance`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', ...getAuthHeader() },
      body: JSON.stringify(body),
    });
    return handleResponse<{ success: boolean; user: User }>(res);
  },

  async adminGetWithdrawals() {
    const res = await fetch(`${API_BASE}/admin/withdrawals`, {
      headers: { ...getAuthHeader() },
    });
    return handleResponse<Withdrawal[]>(res);
  },

  async adminReviewWithdrawal(id: string, body: { status: 'APPROVED' | 'REJECTED'; paymentRef?: string; adminNotes?: string }) {
    const res = await fetch(`${API_BASE}/admin/withdrawals/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', ...getAuthHeader() },
      body: JSON.stringify(body),
    });
    return handleResponse<{ message: string; withdrawal: Withdrawal }>(res);
  },

  async adminGetDisputes() {
    const res = await fetch(`${API_BASE}/admin/disputes`, {
      headers: { ...getAuthHeader() },
    });
    return handleResponse<Dispute[]>(res);
  },

  async adminReviewDispute(id: string, body: { status: 'APPROVED' | 'REJECTED'; adminComment: string }) {
    const res = await fetch(`${API_BASE}/admin/disputes/${id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', ...getAuthHeader() },
      body: JSON.stringify(body),
    });
    return handleResponse<Dispute>(res);
  },

  async getSettings() {
    const res = await fetch(`${API_BASE}/admin/settings`);
    return handleResponse<SystemSettings>(res);
  },

  async updateSettings(settings: Partial<SystemSettings>) {
    const res = await fetch(`${API_BASE}/admin/settings`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json', ...getAuthHeader() },
      body: JSON.stringify(settings),
    });
    return handleResponse<SystemSettings>(res);
  },

  async adminCreateAnnouncement(body: { title: string; content: string; type: string; actionUrl?: string; active?: boolean }) {
    const res = await fetch(`${API_BASE}/admin/announcements`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', ...getAuthHeader() },
      body: JSON.stringify(body),
    });
    return handleResponse<Announcement>(res);
  },

  async adminDeleteAnnouncement(id: string) {
    const res = await fetch(`${API_BASE}/admin/announcements/${id}`, {
      method: 'DELETE',
      headers: { ...getAuthHeader() },
    });
    return handleResponse<{ success: boolean }>(res);
  },
};
