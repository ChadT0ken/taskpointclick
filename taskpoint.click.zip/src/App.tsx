import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ThemeProvider } from './context/ThemeContext';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { AuthModal } from './components/AuthModal';
import { UserDashboard } from './components/UserDashboard';
import { TaskList } from './components/TaskList';
import { WalletView } from './components/WalletView';
import { AirdropPointsView } from './components/AirdropPointsView';
import { LeaderboardView } from './components/LeaderboardView';
import { ReferralsView } from './components/ReferralsView';
import { SupportView } from './components/SupportView';
import { DisputesView } from './components/DisputesView';
import { ProfileView } from './components/ProfileView';
import { LandingLeaderboard } from './components/LandingLeaderboard';
import { AccessDeniedView } from './components/AccessDeniedView';
import { api } from './lib/api';

// Admin Views
import { AdminDashboard } from './components/Admin/AdminDashboard';
import { TaskManagement } from './components/Admin/TaskManagement';
import { SubmissionReview } from './components/Admin/SubmissionReview';
import { UserManagement } from './components/Admin/UserManagement';
import { WithdrawalManagement } from './components/Admin/WithdrawalManagement';
import { DisputeManagement } from './components/Admin/DisputeManagement';
import { SupportTicketManagement } from './components/Admin/SupportTicketManagement';
import { AnnouncementsManagement } from './components/Admin/AnnouncementsManagement';
import { SettingsManagement } from './components/Admin/SettingsManagement';

import { Sparkles, Coins, ArrowRight, ShieldCheck, Trophy, Users, CheckCircle2, AlertCircle, Loader2 } from 'lucide-react';

const MainAppContent: React.FC = () => {
  const { user, loading, setAuthSession } = useAuth();
  const [currentView, setCurrentView] = useState('dashboard');
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  // Link OTP verification feedback states
  const [verifyingLink, setVerifyingLink] = useState(false);
  const [linkBannerMsg, setLinkBannerMsg] = useState<string | null>(null);
  const [linkBannerError, setLinkBannerError] = useState<string | null>(null);

  // Handle URL Query Params for 1-Click OTP Links / Direct Tokens
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const verifyEmail = params.get('verifyEmail') || params.get('email');
    const otpCode = params.get('otpCode') || params.get('otp');
    const purpose = (params.get('purpose') as any) || 'LOGIN';
    const directToken = params.get('token');
    const authSuccess = params.get('authSuccess');
    const authError = params.get('authError');
    const msg = params.get('msg');

    if (authError) {
      setLinkBannerError(decodeURIComponent(authError));
      window.history.replaceState({}, document.title, window.location.pathname);
      return;
    }

    if (directToken) {
      setVerifyingLink(true);
      api.getMe().then((res) => {
        if (res.user) {
          setAuthSession(directToken, res.user);
          setLinkBannerMsg(msg ? decodeURIComponent(msg) : `Welcome back, @${res.user.username}! Signed in via 1-Click verification link.`);
        }
      }).catch((err) => {
        setLinkBannerError(err.message || 'Failed to restore session from token.');
      }).finally(() => {
        setVerifyingLink(false);
        window.history.replaceState({}, document.title, window.location.pathname);
      });
      return;
    }

    if (verifyEmail && otpCode) {
      setVerifyingLink(true);
      api.verifyOtp({ email: verifyEmail, otpCode, purpose })
        .then((res) => {
          if (res.token && res.user) {
            setAuthSession(res.token, res.user);
            setLinkBannerMsg(`Welcome @${res.user.username}! Verification successful via 1-Click OTP link.`);
          } else {
            setLinkBannerMsg('Verification successful! Please sign in with your credentials.');
          }
        })
        .catch((err) => {
          setLinkBannerError(err.message || 'Invalid or expired OTP verification link.');
        })
        .finally(() => {
          setVerifyingLink(false);
          window.history.replaceState({}, document.title, window.location.pathname);
        });
    }
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-950 text-white">
        <div className="text-center space-y-3">
          <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center font-bold text-white mx-auto shadow-lg shadow-blue-600/50">
            T
          </div>
          <p className="font-bold text-xs tracking-widest text-blue-400 uppercase">TaskPoint Loading...</p>
        </div>
      </div>
    );
  }

  // Guest Visitor Landing Page
  if (!user) {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between selection:bg-blue-600 selection:text-white">
        
        {/* OTP Link Verification Status Toasts/Banners */}
        {verifyingLink && (
          <div className="bg-blue-600 text-white text-xs font-bold px-4 py-2.5 flex items-center justify-center gap-2 shadow-lg animate-pulse">
            <Loader2 className="w-4 h-4 animate-spin" />
            <span>Verifying your OTP magic link... Please wait.</span>
          </div>
        )}

        {linkBannerMsg && (
          <div className="bg-emerald-600 text-white text-xs font-bold px-4 py-2.5 flex items-center justify-between shadow-lg">
            <div className="flex items-center gap-2 max-w-7xl mx-auto w-full">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>{linkBannerMsg}</span>
            </div>
            <button onClick={() => setLinkBannerMsg(null)} className="opacity-80 hover:opacity-100 text-xs px-2 py-0.5">✕</button>
          </div>
        )}

        {linkBannerError && (
          <div className="bg-rose-600 text-white text-xs font-bold px-4 py-2.5 flex items-center justify-between shadow-lg">
            <div className="flex items-center gap-2 max-w-7xl mx-auto w-full">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{linkBannerError}</span>
            </div>
            <button onClick={() => setLinkBannerError(null)} className="opacity-80 hover:opacity-100 text-xs px-2 py-0.5">✕</button>
          </div>
        )}

        {/* Guest Navbar */}
        <nav className="p-5 border-b border-slate-800 max-w-7xl mx-auto w-full flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center font-bold text-white shadow-md shadow-blue-600/30 text-base">
              T
            </div>
            <span className="text-xl font-bold text-white tracking-tight">TaskPoint</span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => { setAuthMode('login'); setShowAuthModal(true); }}
              className="px-4 py-2 rounded-lg text-xs font-bold text-slate-300 hover:text-white transition-colors"
            >
              Log In
            </button>
            <button
              onClick={() => { setAuthMode('register'); setShowAuthModal(true); }}
              className="px-5 py-2.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-md shadow-blue-600/30 transition-all"
            >
              Get Started
            </button>
          </div>
        </nav>

        {/* Hero Banner Section */}
        <main className="max-w-5xl mx-auto px-6 py-16 text-center space-y-8 my-auto">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-bold">
            <Sparkles className="w-4 h-4 text-amber-400 animate-pulse" />
            <span>TaskPoint Airdrop Season 1 Live</span>
          </div>

          <h1 className="text-4xl sm:text-6xl font-bold text-white tracking-tight max-w-4xl mx-auto leading-tight">
            Earn Real Cash & Airdrop XP Completing Microtasks
          </h1>

          <p className="text-sm sm:text-base text-slate-400 max-w-2xl mx-auto leading-relaxed">
            Complete quick social tasks, app downloads, and surveys. Get instant USDT crypto payouts (Solana & TRC20 networks), plus accumulate $TASK Airdrop XP for the mainnet token listing.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
            <button
              onClick={() => { setAuthMode('register'); setShowAuthModal(true); }}
              className="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm shadow-lg shadow-blue-600/30 flex items-center justify-center gap-2 transition-all"
            >
              <span>Create Free Account</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => { setAuthMode('login'); setShowAuthModal(true); }}
              className="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-sm border border-slate-800 transition-all"
            >
              Sign In To Workspace
            </button>
          </div>

          {/* Feature Highlights Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-16 border-t border-slate-800 text-left">
            <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
              <Coins className="w-8 h-8 text-emerald-400" />
              <h3 className="font-bold text-base text-white">Instant USD Cash Payouts</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Instant USDT crypto payouts via Solana (SOL) and Tron (TRC20) networks.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
              <Trophy className="w-8 h-8 text-blue-400" />
              <h3 className="font-bold text-base text-white">Limited Airdrop XP</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                XP accumulates alongside cash rewards during the upcoming TGE snapshot.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
              <ShieldCheck className="w-8 h-8 text-purple-400" />
              <h3 className="font-bold text-base text-white">Admin-Verified Proof Integrity</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Zero scam tasks. Every proof submission is verified with screenshot zoom and dispute resolution.
              </p>
            </div>
          </div>

          {/* Live Community Cash Leaderboard Section */}
          <LandingLeaderboard onOpenAuth={() => { setAuthMode('register'); setShowAuthModal(true); }} />
        </main>

        <footer className="py-6 border-t border-slate-800/80 text-center text-xs text-slate-500">
          © {new Date().getFullYear()} TaskPoint Inc. All rights reserved. Built with precision.
        </footer>

        {showAuthModal && (
          <AuthModal
            initialMode={authMode}
            onClose={() => setShowAuthModal(false)}
          />
        )}
      </div>
    );
  }

  const isAdminView = currentView.startsWith('admin-');
  const hasAdminPermission = user.role === 'ADMIN';

  // Authenticated User Layout
  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans">
      {linkBannerMsg && (
        <div className="bg-emerald-600 text-white text-xs font-bold px-4 py-2.5 flex items-center justify-between shadow-lg">
          <div className="flex items-center gap-2 max-w-7xl mx-auto w-full">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{linkBannerMsg}</span>
          </div>
          <button onClick={() => setLinkBannerMsg(null)} className="opacity-80 hover:opacity-100 text-xs px-2 py-0.5">✕</button>
        </div>
      )}

      {linkBannerError && (
        <div className="bg-rose-600 text-white text-xs font-bold px-4 py-2.5 flex items-center justify-between shadow-lg">
          <div className="flex items-center gap-2 max-w-7xl mx-auto w-full">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{linkBannerError}</span>
          </div>
          <button onClick={() => setLinkBannerError(null)} className="opacity-80 hover:opacity-100 text-xs px-2 py-0.5">✕</button>
        </div>
      )}

      <Navbar 
        onToggleSidebar={() => setMobileSidebarOpen(!mobileSidebarOpen)}
        onNavigate={setCurrentView}
        activeView={currentView}
        onOpenAuth={() => setShowAuthModal(true)}
      />

      <div className="flex-1 flex max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-6 gap-6">
        <Sidebar 
          activeView={currentView} 
          onNavigate={setCurrentView} 
          isOpenMobile={mobileSidebarOpen}
          onCloseMobile={() => setMobileSidebarOpen(false)}
        />

        <main className="flex-1 min-w-0">
          {currentView === 'dashboard' && <UserDashboard onNavigate={setCurrentView} />}
          {currentView === 'tasks' && <TaskList />}
          {currentView === 'wallet' && <WalletView />}
          {currentView === 'airdrop' && <AirdropPointsView />}
          {currentView === 'leaderboard' && <LeaderboardView />}
          {currentView === 'referrals' && <ReferralsView />}
          {currentView === 'support' && <SupportView />}
          {currentView === 'disputes' && <DisputesView />}
          {currentView === 'profile' && <ProfileView />}

          {/* Admin Routes with Security Verification */}
          {isAdminView && (
            hasAdminPermission ? (
              <>
                {currentView === 'admin-dashboard' && <AdminDashboard onNavigate={setCurrentView} />}
                {currentView === 'admin-tasks' && <TaskManagement />}
                {currentView === 'admin-submissions' && <SubmissionReview />}
                {currentView === 'admin-users' && <UserManagement />}
                {currentView === 'admin-withdrawals' && <WithdrawalManagement />}
                {currentView === 'admin-disputes' && <DisputeManagement />}
                {currentView === 'admin-support' && <SupportTicketManagement />}
                {currentView === 'admin-announcements' && <AnnouncementsManagement />}
                {currentView === 'admin-settings' && <SettingsManagement />}
              </>
            ) : (
              <AccessDeniedView onReturn={() => setCurrentView('dashboard')} />
            )
          )}
        </main>
      </div>
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <ThemeProvider>
        <MainAppContent />
      </ThemeProvider>
    </AuthProvider>
  );
}
