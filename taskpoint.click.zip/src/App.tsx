import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ThemeProvider } from './context/ThemeContext';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { AuthModal } from './components/AuthModal';
import { UserDashboard } from './components/UserDashboard';
import { TaskList } from './components/TaskList';
import { WalletView } from './components/WalletView';
import { AirdropPointsView } from './components/AirdropPointsView';
import { LeaderboardView } from './components/LeaderboardView';
import { ReferralsView } from './components/ReferralsView';
import { SupportView } from './components/SupportView';
import { DisputesView } from './components/DisputesView';
import { ProfileView } from './components/ProfileView';
import { LandingLeaderboard } from './components/LandingLeaderboard';
import { AccessDeniedView } from './components/AccessDeniedView';
import { LandingSupportModal } from './components/LandingSupportModal';
import { api } from './lib/api';

// Admin Views
import { AdminDashboard } from './components/Admin/AdminDashboard';
import { TaskManagement } from './components/Admin/TaskManagement';
import { SubmissionReview } from './components/Admin/SubmissionReview';
import { UserManagement } from './components/Admin/UserManagement';
import { WithdrawalManagement } from './components/Admin/WithdrawalManagement';
import { DisputeManagement } from './components/Admin/DisputeManagement';
import { SupportTicketManagement } from './components/Admin/SupportTicketManagement';
import { AnnouncementsManagement } from './components/Admin/AnnouncementsManagement';
import { SettingsManagement } from './components/Admin/SettingsManagement';

import { Sparkles, Coins, ArrowRight, ShieldCheck, Trophy, Users, LifeBuoy, MessageSquare, X } from 'lucide-react';

const MainAppContent: React.FC = () => {
  const { user, loading } = useAuth();
  const [currentView, setCurrentView] = useState('dashboard');
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [showLandingSupport, setShowLandingSupport] = useState(false);
  const [landingSupportInitialUser, setLandingSupportInitialUser] = useState('');
  const [landingSupportCategory, setLandingSupportCategory] = useState('Account Ban / Suspension Appeal');
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-950 text-white">
        <div className="text-center space-y-3">
          <div className="w-10 h-10 rounded-xl bg-blue-600 flex items-center justify-center font-bold text-white mx-auto shadow-lg shadow-blue-600/50">
            T
          </div>
          <p className="font-bold text-xs tracking-widest text-blue-400 uppercase">TaskPoint Loading...</p>
        </div>
      </div>
    );
  }

  // Guest Visitor Landing Page
  if (!user) {
    return (
      <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between selection:bg-blue-600 selection:text-white">
        {/* Guest Navbar */}
        <nav className="p-5 border-b border-slate-800 max-w-7xl mx-auto w-full flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center font-bold text-white shadow-md shadow-blue-600/30 text-base">
              T
            </div>
            <span className="text-xl font-bold text-white tracking-tight">TaskPoint</span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                setLandingSupportInitialUser('');
                setLandingSupportCategory('General Support');
                setShowLandingSupport(true);
              }}
              className="px-3 py-2 rounded-lg text-xs font-bold text-slate-300 hover:text-white hover:bg-slate-900 transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <LifeBuoy className="w-3.5 h-3.5 text-blue-400" />
              <span>Support</span>
            </button>
            <button
              onClick={() => { setAuthMode('login'); setShowAuthModal(true); }}
              className="px-4 py-2 rounded-lg text-xs font-bold text-slate-300 hover:text-white transition-colors cursor-pointer"
            >
              Log In
            </button>
            <button
              onClick={() => { setAuthMode('register'); setShowAuthModal(true); }}
              className="px-5 py-2.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-md shadow-blue-600/30 transition-all cursor-pointer"
            >
              Get Started
            </button>
          </div>
        </nav>

        {/* Hero Banner Section */}
        <main className="max-w-5xl mx-auto px-6 py-16 text-center space-y-8 my-auto">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-xs font-bold">
            <Sparkles className="w-4 h-4 text-amber-400 animate-pulse" />
            <span>TaskPoint Airdrop Season 1 Live</span>
          </div>

          <h1 className="text-4xl sm:text-6xl font-bold text-white tracking-tight max-w-4xl mx-auto leading-tight">
            Earn Real Cash & Airdrop XP Completing Microtasks
          </h1>

          <p className="text-sm sm:text-base text-slate-400 max-w-2xl mx-auto leading-relaxed">
            Complete quick social tasks, app downloads, and surveys. Get instant USDT crypto payouts (Solana & TRC20 networks), plus accumulate $TASK Airdrop XP for the mainnet token listing.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
            <button
              onClick={() => { setAuthMode('register'); setShowAuthModal(true); }}
              className="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm shadow-lg shadow-blue-600/30 flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <span>Create Free Account</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => { setAuthMode('login'); setShowAuthModal(true); }}
              className="w-full sm:w-auto px-8 py-3.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-sm border border-slate-800 transition-all cursor-pointer"
            >
              Sign In To Workspace
            </button>
          </div>

          <div className="pt-2">
            <button
              onClick={() => {
                setLandingSupportInitialUser('');
                setLandingSupportCategory('Account Ban / Suspension Appeal');
                setShowLandingSupport(true);
              }}
              className="text-xs text-slate-400 hover:text-blue-400 transition-colors inline-flex items-center gap-1.5 cursor-pointer underline decoration-slate-700 underline-offset-4"
            >
              <LifeBuoy className="w-3.5 h-3.5 text-blue-400" />
              <span>Need help or appealing a banned account? Submit a support ticket</span>
            </button>
          </div>

          {/* Feature Highlights Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-16 border-t border-slate-800 text-left">
            <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
              <Coins className="w-8 h-8 text-emerald-400" />
              <h3 className="font-bold text-base text-white">Instant USD Cash Payouts</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Instant USDT crypto payouts via Solana (SOL) and Tron (TRC20) networks.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
              <Trophy className="w-8 h-8 text-blue-400" />
              <h3 className="font-bold text-base text-white">Limited Airdrop XP</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                XP accumulates alongside cash rewards during the upcoming TGE snapshot.
              </p>
            </div>

            <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
              <ShieldCheck className="w-8 h-8 text-purple-400" />
              <h3 className="font-bold text-base text-white">Admin-Verified Proof Integrity</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Zero scam tasks. Every proof submission is verified with screenshot zoom and dispute resolution.
              </p>
            </div>
          </div>

          {/* Live Community Cash Leaderboard Section */}
          <LandingLeaderboard onOpenAuth={() => { setAuthMode('register'); setShowAuthModal(true); }} />
        </main>

        <footer className="py-6 border-t border-slate-800/80 text-xs text-slate-500 max-w-7xl mx-auto w-full px-6 flex flex-col sm:flex-row items-center justify-between gap-3">
          <span>© {new Date().getFullYear()} TaskPoint Inc. All rights reserved. Built with precision.</span>
          <button
            onClick={() => {
              setLandingSupportInitialUser('');
              setLandingSupportCategory('General Support');
              setShowLandingSupport(true);
            }}
            className="text-slate-400 hover:text-white transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <LifeBuoy className="w-3.5 h-3.5 text-blue-400" />
            <span>Public Support Ticket Desk</span>
          </button>
        </footer>

        {showAuthModal && (
          <AuthModal
            initialMode={authMode}
            onClose={() => setShowAuthModal(false)}
            onOpenSupport={(un) => {
              if (un) setLandingSupportInitialUser(un);
              setLandingSupportCategory('Account Ban / Suspension Appeal');
              setShowLandingSupport(true);
            }}
          />
        )}

        {showLandingSupport && (
          <LandingSupportModal
            isOpen={showLandingSupport}
            initialUsername={landingSupportInitialUser}
            initialCategory={landingSupportCategory}
            onClose={() => setShowLandingSupport(false)}
          />
        )}
      </div>
    );
  }

  const isAdminView = currentView.startsWith('admin-');
  const SUPPORT_ALLOWED_VIEWS = [
    'admin-dashboard',
    'admin-tasks',
    'admin-submissions',
    'admin-users',
    'admin-disputes',
    'admin-support',
  ];

  const hasAdminPermission = 
    user.role === 'ADMIN' || 
    user.role === 'MODERATOR' ||
    (user.role === 'SUPPORT' && SUPPORT_ALLOWED_VIEWS.includes(currentView));

  // Authenticated User Layout
  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans">
      <Navbar 
        onToggleSidebar={() => setMobileSidebarOpen(!mobileSidebarOpen)}
        onNavigate={setCurrentView}
        activeView={currentView}
        onOpenAuth={() => setShowAuthModal(true)}
      />

      <div className="flex-1 flex max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-6 gap-6">
        <Sidebar 
          activeView={currentView} 
          onNavigate={setCurrentView} 
          isOpenMobile={mobileSidebarOpen}
          onCloseMobile={() => setMobileSidebarOpen(false)}
        />

        <main className="flex-1 min-w-0">
          {currentView === 'dashboard' && <UserDashboard onNavigate={setCurrentView} />}
          {currentView === 'tasks' && <TaskList />}
          {currentView === 'wallet' && <WalletView onNavigate={setCurrentView} />}
          {currentView === 'airdrop' && <AirdropPointsView />}
          {currentView === 'leaderboard' && <LeaderboardView />}
          {currentView === 'referrals' && <ReferralsView />}
          {currentView === 'support' && <SupportView />}
          {currentView === 'disputes' && <DisputesView />}
          {(currentView === 'profile' || currentView === 'settings') && <ProfileView onNavigate={setCurrentView} />}

          {/* Admin Routes with Security Verification */}
          {isAdminView && (
            hasAdminPermission ? (
              <>
                {currentView === 'admin-dashboard' && <AdminDashboard onNavigate={setCurrentView} />}
                {currentView === 'admin-tasks' && <TaskManagement />}
                {currentView === 'admin-submissions' && <SubmissionReview />}
                {currentView === 'admin-users' && <UserManagement />}
                {currentView === 'admin-withdrawals' && <WithdrawalManagement />}
                {currentView === 'admin-disputes' && <DisputeManagement />}
                {currentView === 'admin-support' && <SupportTicketManagement />}
                {currentView === 'admin-announcements' && <AnnouncementsManagement />}
                {currentView === 'admin-settings' && <SettingsManagement />}
              </>
            ) : (
              <AccessDeniedView onReturn={() => setCurrentView('dashboard')} />
            )
          )}
        </main>
      </div>
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <ThemeProvider>
        <MainAppContent />
      </ThemeProvider>
    </AuthProvider>
  );
}
