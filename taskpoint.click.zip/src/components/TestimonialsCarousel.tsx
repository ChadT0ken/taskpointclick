import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, Star, CheckCircle2, Quote, ShieldCheck } from 'lucide-react';

interface Testimonial {
  id: string;
  name: string;
  handle: string;
  country: string;
  flag: string;
  avatar: string;
  rating: number;
  earned: string;
  payoutMethod: string;
  text: string;
  date: string;
}

const TESTIMONIALS: Testimonial[] = [
  {
    id: '1',
    name: 'Amina Yusuf',
    handle: '@amina_crypto',
    country: 'Nigeria',
    flag: '🇳🇬',
    avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=AminaYusuf',
    rating: 5,
    earned: '$340.00 USDT',
    payoutMethod: 'USDT TRC20',
    text: 'I was skeptical at first, but after completing 8 app download tasks, I requested a $25 USDT payout and got it in under 15 minutes! The TRC20 withdrawal is fast with minimal fees.',
    date: '2 hours ago',
  },
  {
    id: '2',
    name: 'Carlos Mendoza',
    handle: '@carlos_tasks',
    country: 'Philippines',
    flag: '🇵🇭',
    avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=CarlosMendoza',
    rating: 5,
    earned: '$820.50 USDT',
    payoutMethod: 'USDT Solana',
    text: 'TaskPoint is by far the most reliable microtask platform. The proof verification is super fair, and accumulating $TASK Airdrop points alongside daily USDT cash is an amazing perk!',
    date: '5 hours ago',
  },
  {
    id: '3',
    name: 'Sarah Jenkins',
    handle: '@sarah_j_web3',
    country: 'United States',
    flag: '🇺🇸',
    avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=SarahJenkins',
    rating: 5,
    earned: '$1,150.00 USDT',
    payoutMethod: 'USDT TRC20',
    text: 'I refer my Telegram community members here and earn 10% referral commission automatically. The payout process is reliable and support is always responsive.',
    date: '1 day ago',
  },
  {
    id: '4',
    name: 'Rajesh Kumar',
    handle: '@rajesh_earner',
    country: 'India',
    flag: '🇮🇳',
    avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=RajeshKumar',
    rating: 5,
    earned: '$415.20 USDT',
    payoutMethod: 'USDT Solana',
    text: 'The daily streak bonuses and instant USDT payouts keep me active every day. Earned over $400 USDT doing simple social media tasks in my free time.',
    date: '2 days ago',
  },
  {
    id: '5',
    name: 'Elena Rostova',
    handle: '@elena_crypto_v',
    country: 'Germany',
    flag: '🇩🇪',
    avatar: 'https://api.dicebear.com/7.x/bottts/svg?seed=ElenaRostova',
    rating: 5,
    earned: '$670.00 USDT',
    payoutMethod: 'USDT TRC20',
    text: 'Clean interface, unambiguous task rules, and transparent payout tracking. Highly recommended for anyone wanting legitimate USDT crypto payouts online!',
    date: '3 days ago',
  },
];

export const TestimonialsCarousel: React.FC = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAutoplay, setIsAutoplay] = useState(true);

  useEffect(() => {
    if (!isAutoplay) return;
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % TESTIMONIALS.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [isAutoplay]);

  const handlePrev = () => {
    setIsAutoplay(false);
    setCurrentIndex((prev) => (prev === 0 ? TESTIMONIALS.length - 1 : prev - 1));
  };

  const handleNext = () => {
    setIsAutoplay(false);
    setCurrentIndex((prev) => (prev + 1) % TESTIMONIALS.length);
  };

  const current = TESTIMONIALS[currentIndex];

  return (
    <div 
      className="py-12 border-t border-slate-800/80 space-y-8"
      onMouseEnter={() => setIsAutoplay(false)}
      onMouseLeave={() => setIsAutoplay(true)}
    >
      {/* Section Header */}
      <div className="text-center space-y-2">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-extrabold">
          <ShieldCheck className="w-3.5 h-3.5" />
          <span>Verified Payout Reviews</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
          Trusted by Top Micro-Earners Worldwide
        </h2>
        <p className="text-xs sm:text-sm text-slate-400 max-w-xl mx-auto">
          See what active members say about instant USDT payouts and $TASK Airdrop rewards.
        </p>
      </div>

      {/* Main Carousel Card */}
      <div className="relative max-w-3xl mx-auto px-4">
        <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-2xl relative overflow-hidden backdrop-blur-sm transition-all duration-300">
          
          {/* Subtle background quote icon */}
          <Quote className="absolute top-6 right-6 w-20 h-20 text-slate-800/40 pointer-events-none" />

          {/* User Info Header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 relative z-10">
            <div className="flex items-center gap-3">
              <img 
                src={current.avatar} 
                alt={current.name} 
                className="w-12 h-12 rounded-2xl bg-slate-800 p-1 border border-slate-700/60 object-cover shadow-inner"
              />
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-extrabold text-white text-base sm:text-lg tracking-tight">
                    {current.name}
                  </h3>
                  <span className="text-sm">{current.flag}</span>
                </div>
                <div className="flex items-center gap-2 text-xs text-slate-400">
                  <span>{current.handle}</span>
                  <span>•</span>
                  <span>{current.country}</span>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2 sm:justify-end">
              <span className="px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-extrabold text-xs flex items-center gap-1.5 shadow-sm">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>{current.earned}</span>
              </span>
              <span className="px-2.5 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-300 text-[11px] font-bold">
                {current.payoutMethod}
              </span>
            </div>
          </div>

          {/* Rating Stars */}
          <div className="flex items-center gap-1 mb-4">
            {[...Array(current.rating)].map((_, i) => (
              <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
            ))}
            <span className="text-xs text-slate-400 ml-2 font-semibold">{current.date}</span>
          </div>

          {/* Quote Body */}
          <p className="text-sm sm:text-base text-slate-200 leading-relaxed font-medium italic relative z-10">
            "{current.text}"
          </p>

          {/* Navigation Controls inside card footer */}
          <div className="flex items-center justify-between pt-6 mt-6 border-t border-slate-800/80">
            <div className="flex items-center gap-1.5">
              {TESTIMONIALS.map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setIsAutoplay(false);
                    setCurrentIndex(idx);
                  }}
                  className={`h-2 rounded-full transition-all duration-300 ${
                    idx === currentIndex
                      ? 'w-6 bg-blue-500'
                      : 'w-2 bg-slate-700 hover:bg-slate-600'
                  }`}
                  aria-label={`Go to slide ${idx + 1}`}
                />
              ))}
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handlePrev}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700/60 transition-all active:scale-95"
                aria-label="Previous testimonial"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                onClick={handleNext}
                className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700/60 transition-all active:scale-95"
                aria-label="Next testimonial"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>

        </div>
      </div>

      {/* Grid view preview cards for multi-card look */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-4xl mx-auto px-4 opacity-75">
        {TESTIMONIALS.slice(0, 3).map((item) => (
          <div 
            key={item.id}
            onClick={() => {
              setIsAutoplay(false);
              setCurrentIndex(TESTIMONIALS.findIndex((t) => t.id === item.id));
            }}
            className={`p-4 rounded-2xl border text-left cursor-pointer transition-all ${
              item.id === current.id
                ? 'bg-blue-950/40 border-blue-500/50 shadow-md'
                : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
            }`}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-bold text-white flex items-center gap-1">
                <span>{item.flag}</span>
                <span>{item.name}</span>
              </span>
              <span className="text-[10px] font-extrabold text-emerald-400">{item.earned}</span>
            </div>
            <p className="text-xs text-slate-400 line-clamp-2 italic">
              "{item.text}"
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};
