import React, { useEffect, useState } from 'react';
import { 
  Wallet as WalletIcon, 
  Coins, 
  ArrowUpRight, 
  ShieldCheck, 
  Clock, 
  CheckCircle2, 
  AlertCircle,
  PlusCircle,
  Calendar,
  Lock,
  Info,
  Check,
  Settings,
  DollarSign,
  X,
  Sparkles
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { api } from '../lib/api';
import { Withdrawal } from '../types';

interface WalletViewProps {
  onNavigate?: (view: string) => void;
}

export const WalletView: React.FC<WalletViewProps> = ({ onNavigate }) => {
  const { user, refreshUser } = useAuth();
  const [withdrawals, setWithdrawals] = useState<Withdrawal[]>([]);
  const [loadingHistory, setLoadingHistory] = useState(true);

  // Confirmation Modal state
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [amount, setAmount] = useState<string>('');
  const [submitting, setSubmitting] = useState(false);
  const [withdrawError, setWithdrawError] = useState<string | null>(null);
  const [withdrawSuccess, setWithdrawSuccess] = useState<string | null>(null);

  const loadWalletHistory = async () => {
    try {
      const data = await api.getWalletHistory();
      setWithdrawals(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingHistory(false);
    }
  };

  useEffect(() => {
    loadWalletHistory();
  }, []);

  if (!user) return null;

  const minPayout = 5;

  // Determine current day of week (2 = Tuesday, 3 = Wednesday)
  const currentDayOfWeek = new Date().getDay();
  const isTuesday = currentDayOfWeek === 2;
  const isWednesday = currentDayOfWeek === 3;

  const handleGoToSettings = () => {
    if (onNavigate) {
      onNavigate('settings');
    }
  };

  const handleOpenConfirmModal = () => {
    setWithdrawError(null);
    setWithdrawSuccess(null);
    setAmount(user.availableBalance > 0 ? user.availableBalance.toString() : '');
    setShowConfirmModal(true);
  };

  const handleConfirmWithdrawal = async (e: React.FormEvent) => {
    e.preventDefault();
    setWithdrawError(null);

    if (!user.savedWalletAddress) {
      setWithdrawError('Please add and save your payout wallet address in Settings first before requesting a withdrawal.');
      return;
    }

    const numericAmount = parseFloat(amount);
    if (isNaN(numericAmount) || numericAmount <= 0) {
      setWithdrawError('Please enter a valid positive withdrawal amount.');
      return;
    }

    if (numericAmount < minPayout) {
      setWithdrawError(`Minimum withdrawal amount is $${minPayout}.00 USD`);
      return;
    }

    if (numericAmount > user.availableBalance) {
      setWithdrawError(`Insufficient balance. You currently have $${user.availableBalance.toFixed(2)} USD available.`);
      return;
    }

    setSubmitting(true);
    try {
      const detailsString = `USDT (${user.savedWalletNetwork || 'TRC20'}): ${user.savedWalletAddress}`;
      const res = await api.requestWithdrawal({
        amount: numericAmount,
        currency: 'USDT',
        method: 'USDT',
        details: detailsString,
      });

      setWithdrawSuccess(res.message || 'Withdrawal request submitted! Payments requested on Tuesdays will be sent Wednesday.');
      setShowConfirmModal(false);
      await refreshUser();
      await loadWalletHistory();
    } catch (err: any) {
      setWithdrawError(err.message || 'Withdrawal failed');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-300">
      
      {/* Header */}
      <div>
        <h1 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">
          Wallet & USDT Cash Payouts
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          Withdraw your earnings directly via USDT Crypto (Solana SOL & Tron TRC20 networks).
        </p>
      </div>

      {/* Weekly Schedule Banner */}
      <div className="p-4 rounded-3xl bg-gradient-to-r from-blue-600/10 via-indigo-600/10 to-purple-600/10 border border-blue-200 dark:border-blue-900/50 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-2xl bg-blue-600 text-white shrink-0 shadow-md shadow-blue-600/20">
            <Calendar className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-xs font-black text-slate-900 dark:text-white flex items-center gap-2">
              <span>Weekly Payout Schedule</span>
              {isTuesday && (
                <span className="px-2 py-0.5 rounded-full bg-emerald-500 text-white text-[10px] font-extrabold uppercase animate-pulse">
                  Open Today (Tuesday)
                </span>
              )}
              {isWednesday && (
                <span className="px-2 py-0.5 rounded-full bg-blue-500 text-white text-[10px] font-extrabold uppercase">
                  Payout Processing Day (Wednesday)
                </span>
              )}
            </h3>
            <p className="text-[11px] text-slate-600 dark:text-slate-300 mt-0.5">
              Withdrawals are requested every <strong className="text-blue-600 dark:text-blue-400 font-extrabold">Tuesday</strong>. Payouts and payments are verified & sent every <strong className="text-indigo-600 dark:text-indigo-400 font-extrabold">Wednesday</strong>.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs font-bold text-slate-500 dark:text-slate-400 self-end sm:self-center">
          <Clock className="w-4 h-4 text-blue-500" />
          <span>Tuesday Requests ➔ Wednesday Payments</span>
        </div>
      </div>

      {/* Balance Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* Available Balance */}
        <div className="p-6 rounded-3xl bg-gradient-to-br from-emerald-600 to-teal-700 text-white shadow-xl shadow-emerald-600/15 relative overflow-hidden">
          <div className="flex items-center justify-between mb-4">
            <span className="text-xs font-bold text-emerald-100 uppercase tracking-wider">
              Available Cash
            </span>
            <div className="p-2 rounded-xl bg-white/10">
              <Coins className="w-5 h-5 text-emerald-200" />
            </div>
          </div>
          <h2 className="text-3xl font-black tracking-tight font-mono">
            ${user.availableBalance.toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </h2>
          <p className="text-xs text-emerald-100 mt-2 font-medium">
            Ready for USDT payout request
          </p>
        </div>

        {/* Pending Earnings */}
        <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Pending Earnings
            </span>
            <div className="p-2 rounded-xl bg-amber-50 dark:bg-amber-950 text-amber-600">
              <Clock className="w-5 h-5" />
            </div>
          </div>
          <h2 className="text-3xl font-black text-slate-900 dark:text-white tracking-tight font-mono">
            ${user.pendingBalance.toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-2">
            Tasks undergoing verification
          </p>
        </div>

        {/* Lifetime Withdrawn */}
        <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Total Withdrawn
            </span>
            <div className="p-2 rounded-xl bg-sky-50 dark:bg-sky-950 text-sky-600">
              <ShieldCheck className="w-5 h-5" />
            </div>
          </div>
          <h2 className="text-3xl font-black text-slate-900 dark:text-white tracking-tight font-mono">
            ${user.totalWithdrawn.toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-2">
            Successfully paid out to date
          </p>
        </div>

      </div>

      {/* Main Action & History Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Request Payout Action Card */}
        <div id="card-request-payout-action" className="lg:col-span-1 p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="font-extrabold text-base text-slate-900 dark:text-white flex items-center gap-2">
                <WalletIcon className="w-5 h-5 text-blue-600 dark:text-blue-400" />
                <span>Request Withdrawal</span>
              </h2>
              <span className="text-[11px] font-bold text-blue-600 dark:text-blue-400 bg-blue-50 dark:bg-blue-950/60 px-2.5 py-0.5 rounded-full">
                USDT Only
              </span>
            </div>

            {withdrawSuccess && (
              <div className="p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 text-emerald-600 dark:text-emerald-300 text-xs font-semibold flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{withdrawSuccess}</span>
              </div>
            )}

            {/* Primary Action Button */}
            <button
              id="btn-trigger-request-payout"
              type="button"
              onClick={handleOpenConfirmModal}
              className="w-full py-4 px-4 rounded-2xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-sm shadow-xl shadow-blue-600/30 transition-all flex items-center justify-center gap-2 group"
            >
              <span>Request Payout</span>
              <ArrowUpRight className="w-4 h-4 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
            </button>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-400">
            <p className="flex items-center gap-1.5">
              <Info className="w-3.5 h-3.5 text-blue-500 shrink-0" />
              <span>Requested payouts are queued for Wednesday dispatch.</span>
            </p>
          </div>
        </div>

        {/* Withdrawal History Table */}
        <div className="lg:col-span-2 p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-extrabold text-base text-slate-900 dark:text-white">
              Payout History & Logs
            </h2>
            <span className="text-xs text-slate-400">
              {withdrawals.length} Total Requests
            </span>
          </div>

          {loadingHistory ? (
            <div className="p-8 text-center text-xs text-slate-400 animate-pulse">
              Loading payout logs...
            </div>
          ) : withdrawals.length === 0 ? (
            <div className="py-12 text-center">
              <Coins className="w-10 h-10 text-slate-300 dark:text-slate-700 mx-auto mb-2" />
              <p className="text-xs font-bold text-slate-500 dark:text-slate-400">No withdrawal requests yet</p>
              <p className="text-[11px] text-slate-400 mt-1">
                Link your address in Settings and request payout on Tuesday. Payment is sent Wednesday.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-100 dark:border-slate-800 text-slate-400 font-bold uppercase text-[10px]">
                    <th className="pb-3">Date</th>
                    <th className="pb-3">Amount</th>
                    <th className="pb-3">Method & Details</th>
                    <th className="pb-3">Status</th>
                    <th className="pb-3">Disbursement</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60">
                  {withdrawals.map((w) => (
                    <tr key={w.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                      <td className="py-3 text-slate-600 dark:text-slate-300 font-medium">
                        {new Date(w.createdAt).toLocaleDateString()}
                      </td>
                      <td className="py-3 font-extrabold font-mono text-slate-900 dark:text-white">
                        ${w.amount.toFixed(2)} USD
                      </td>
                      <td className="py-3 text-slate-500 dark:text-slate-400 max-w-[200px]">
                        <span className="font-bold text-blue-600 dark:text-blue-400 block">USDT</span>
                        <span className="text-[10px] text-slate-400 block truncate font-mono" title={w.details}>
                          {w.details}
                        </span>
                      </td>
                      <td className="py-3">
                        <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${
                          w.status === 'APPROVED' || w.status === 'COMPLETED'
                            ? 'bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300'
                            : w.status === 'REJECTED'
                            ? 'bg-rose-100 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300'
                            : 'bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300'
                        }`}>
                          {w.status}
                        </span>
                      </td>
                      <td className="py-3 text-[11px] text-slate-500 dark:text-slate-400">
                        {w.status === 'APPROVED' || w.status === 'COMPLETED' ? (
                          <span className="text-emerald-600 font-bold">Sent (Wednesday)</span>
                        ) : (
                          <span className="text-amber-600 font-medium">Queued (Wed Payout)</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

      </div>

      {/* Confirmation & Total Cash Earned Modal */}
      {showConfirmModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="relative w-full max-w-md rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-6 sm:p-8 overflow-hidden text-slate-900 dark:text-white">
            
            {/* Header */}
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2.5">
                <div className="p-2.5 rounded-2xl bg-blue-600 text-white shadow-md shadow-blue-600/30">
                  <WalletIcon className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-black tracking-tight text-slate-900 dark:text-white">
                    Confirm Withdrawal
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    USDT Payout Request Summary
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowConfirmModal(false)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {withdrawError && (
              <div className="mb-4 p-3.5 rounded-2xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800/80 text-rose-600 dark:text-rose-300 text-xs font-semibold">
                {withdrawError}
              </div>
            )}

            {/* Total Cash Earned Display Card */}
            <div className="mb-5 p-5 rounded-2xl bg-gradient-to-br from-emerald-600/15 via-teal-600/10 to-blue-600/10 border border-emerald-200 dark:border-emerald-800/50 text-center">
              <span className="text-[11px] font-extrabold uppercase tracking-wider text-emerald-700 dark:text-emerald-400 block">
                Total Available Cash Earned
              </span>
              <div className="text-3xl font-black text-slate-900 dark:text-white font-mono mt-1">
                ${user.availableBalance.toLocaleString('en-US', { minimumFractionDigits: 2 })} <span className="text-sm font-bold text-slate-500">USD</span>
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-1">
                Accumulated from completed tasks & referrals
              </p>
            </div>

            <form onSubmit={handleConfirmWithdrawal} className="space-y-4">
              
              {/* Amount to Withdraw */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                    Withdrawal Amount ($ USD)
                  </label>
                  <span className="text-[11px] font-semibold text-blue-600 dark:text-blue-400">
                    Min: $5.00
                  </span>
                </div>
                <div className="relative">
                  <input
                    type="number"
                    step="any"
                    required
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="e.g. 25.00"
                    className="w-full pl-4 pr-14 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs font-bold font-mono outline-none focus:ring-2 focus:ring-blue-500"
                  />
                  <button
                    type="button"
                    onClick={() => setAmount(user.availableBalance.toString())}
                    className="absolute right-2 top-2 px-2 py-1 rounded-lg bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-400 text-[10px] font-bold hover:bg-blue-200 dark:hover:bg-blue-900 transition-colors"
                  >
                    MAX
                  </button>
                </div>
              </div>

              {/* Destination Wallet Summary */}
              {user.savedWalletAddress ? (
                <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-xs space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500 dark:text-slate-400 font-medium">Payout Network:</span>
                    <span className="font-bold text-blue-600 dark:text-blue-400">
                      USDT ({user.savedWalletNetwork === 'SOL' ? 'Solana SOL' : 'Tron TRC20'})
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-500 dark:text-slate-400 font-medium block">Destination Address:</span>
                    <span className="font-mono text-[11px] font-bold text-slate-900 dark:text-slate-100 break-all block">
                      {user.savedWalletAddress}
                    </span>
                  </div>
                </div>
              ) : (
                <div className="p-3.5 rounded-xl bg-amber-50 dark:bg-amber-950/50 border border-amber-200 dark:border-amber-900/50 text-xs space-y-2">
                  <p className="text-amber-700 dark:text-amber-300 font-medium">
                    No USDT payout address linked yet. Please add your wallet address in Settings.
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      setShowConfirmModal(false);
                      handleGoToSettings();
                    }}
                    className="text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1"
                  >
                    <Settings className="w-3.5 h-3.5" />
                    <span>Go to Settings to Link Wallet</span>
                  </button>
                </div>
              )}

              {/* Weekly Schedule Note */}
              <div className="p-3 rounded-xl bg-blue-50 dark:bg-blue-950/50 border border-blue-200 dark:border-blue-900/50 text-[11px] text-blue-700 dark:text-blue-300 flex items-center gap-2">
                <Clock className="w-4 h-4 shrink-0 text-blue-500" />
                <span>Withdrawals are requested on Tuesday and sent on Wednesday.</span>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowConfirmModal(false)}
                  className="flex-1 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 font-bold text-xs hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
                >
                  Cancel
                </button>
                <button
                  id="btn-confirm-withdrawal-submit"
                  type="submit"
                  disabled={submitting}
                  className="flex-1 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-md shadow-blue-600/30 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {submitting ? (
                    <span>Submitting...</span>
                  ) : (
                    <>
                      <span>Confirm Payout</span>
                      <ArrowUpRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>

            </form>

          </div>
        </div>
      )}

    </div>
  );
};
