import React, { useEffect, useState } from 'react';
import { 
  Wallet as WalletIcon, 
  Coins, 
  ArrowUpRight, 
  Building, 
  ShieldCheck, 
  Clock, 
  CheckCircle2, 
  XCircle, 
  AlertCircle,
  HelpCircle,
  DollarSign
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { api } from '../lib/api';
import { Withdrawal } from '../types';

export const WalletView: React.FC = () => {
  const { user, refreshUser } = useAuth();
  const [withdrawals, setWithdrawals] = useState<Withdrawal[]>([]);
  const [loadingHistory, setLoadingHistory] = useState(true);

  // Form states - USDT only (SOL & TRC20)
  const [network, setNetwork] = useState<'TRC' | 'SOL'>('TRC');
  const [amount, setAmount] = useState<string>('');
  const [cryptoAddress, setCryptoAddress] = useState('');

  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const loadWalletHistory = async () => {
    try {
      const data = await api.getWalletHistory();
      setWithdrawals(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingHistory(false);
    }
  };

  useEffect(() => {
    loadWalletHistory();
  }, []);

  if (!user) return null;

  const minPayout = 5;

  const handleWithdrawSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);

    const numericAmount = parseFloat(amount);
    if (isNaN(numericAmount) || numericAmount <= 0) {
      setError('Please enter a valid positive withdrawal amount');
      return;
    }

    if (numericAmount < minPayout) {
      setError(`Minimum withdrawal amount is $${minPayout}.00 USD`);
      return;
    }

    if (numericAmount > user.availableBalance) {
      setError('Insufficient available balance');
      return;
    }

    const trimmedAddress = cryptoAddress.trim();
    if (!trimmedAddress || trimmedAddress.length < 8) {
      setError(`Please enter a valid USDT ${network === 'TRC' ? 'TRC20' : 'Solana (SOL)'} wallet address`);
      return;
    }

    if (network === 'TRC' && !trimmedAddress.startsWith('T')) {
      setError('TRC20 USDT wallet addresses typically start with "T". Please verify your TRC20 address.');
      return;
    }

    const detailsString = `Network: USDT (${network === 'TRC' ? 'TRC20 (Tron)' : 'SOL (Solana)'}) | Address: ${trimmedAddress}`;

    setSubmitting(true);
    try {
      await api.requestWithdrawal({
        amount: numericAmount,
        currency: 'USDT',
        method: 'USDT',
        details: detailsString,
      });

      setSuccessMsg('USDT Payout request submitted! Pending admin verification.');
      setAmount('');
      setCryptoAddress('');
      await refreshUser();
      await loadWalletHistory();
    } catch (err: any) {
      setError(err.message || 'Withdrawal failed');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-300">
      
      {/* Header */}
      <div>
        <h1 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">
          Wallet & USDT Cash Payouts
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          Withdraw your earnings directly via USDT Crypto (Solana SOL & Tron TRC20 networks).
        </p>
      </div>

      {/* Balance Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* Available Balance */}
        <div className="p-6 rounded-3xl bg-gradient-to-br from-emerald-600 to-teal-700 text-white shadow-xl shadow-emerald-600/15 relative overflow-hidden">
          <div className="flex items-center justify-between mb-4">
            <span className="text-xs font-bold text-emerald-100 uppercase tracking-wider">
              Available Cash
            </span>
            <div className="p-2 rounded-xl bg-white/10">
              <Coins className="w-5 h-5 text-emerald-200" />
            </div>
          </div>
          <h2 className="text-3xl font-black tracking-tight font-mono">
            ${user.availableBalance.toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </h2>
          <p className="text-xs text-emerald-100 mt-2 font-medium">
            Ready for instant cash payout
          </p>
        </div>

        {/* Pending Earnings */}
        <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Pending Earnings
            </span>
            <div className="p-2 rounded-xl bg-amber-50 dark:bg-amber-950 text-amber-600">
              <Clock className="w-5 h-5" />
            </div>
          </div>
          <h2 className="text-3xl font-black text-slate-900 dark:text-white tracking-tight font-mono">
            ${user.pendingBalance.toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-2">
            Tasks undergoing admin verification
          </p>
        </div>

        {/* Lifetime Withdrawn */}
        <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Total Withdrawn
            </span>
            <div className="p-2 rounded-xl bg-sky-50 dark:bg-sky-950 text-sky-600">
              <ShieldCheck className="w-5 h-5" />
            </div>
          </div>
          <h2 className="text-3xl font-black text-slate-900 dark:text-white tracking-tight font-mono">
            ${user.totalWithdrawn.toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-2">
            Successfully paid out to date
          </p>
        </div>

      </div>

      {/* Main Form & History Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Request Payout Form */}
        <div className="lg:col-span-1 p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
          <h2 className="font-extrabold text-base text-slate-900 dark:text-white mb-4 flex items-center gap-2">
            <WalletIcon className="w-5 h-5 text-indigo-600" />
            <span>Request Withdrawal</span>
          </h2>

          {error && (
            <div className="mb-4 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 text-rose-600 text-xs font-semibold">
              {error}
            </div>
          )}

          {successMsg && (
            <div className="mb-4 p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 text-emerald-600 text-xs font-semibold flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>{successMsg}</span>
            </div>
          )}

          <form onSubmit={handleWithdrawSubmit} className="space-y-4">
            
            {/* Payout Network Selector - USDT Only */}
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                USDT Payout Network
              </label>
              <div className="grid grid-cols-2 gap-2 p-1 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs">
                <button
                  type="button"
                  onClick={() => setNetwork('TRC')}
                  className={`py-2 rounded-lg font-extrabold transition-all flex items-center justify-center gap-1.5 ${
                    network === 'TRC' ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  <span>USDT (TRC20)</span>
                </button>
                <button
                  type="button"
                  onClick={() => setNetwork('SOL')}
                  className={`py-2 rounded-lg font-extrabold transition-all flex items-center justify-center gap-1.5 ${
                    network === 'SOL' ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  <span>USDT (SOL)</span>
                </button>
              </div>
            </div>

            {/* Amount Input */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                  Amount ($ USD)
                </label>
                <span className="text-[11px] font-semibold text-indigo-600">
                  Min: $5.00
                </span>
              </div>
              <div className="relative">
                <input
                  type="number"
                  step="any"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="e.g. 25.00"
                  className="w-full pl-4 pr-12 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs font-bold outline-none focus:ring-2 focus:ring-indigo-500 font-mono"
                />
                <button
                  type="button"
                  onClick={() => setAmount(user.availableBalance.toString())}
                  className="absolute right-2 top-2 px-2 py-1 rounded bg-indigo-100 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 text-[10px] font-bold"
                >
                  MAX
                </button>
              </div>
            </div>

            {/* Wallet Address Input */}
            <div className="pt-1">
              <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-400 mb-1">
                USDT {network === 'TRC' ? 'TRC20 (Tron)' : 'SOL (Solana)'} Wallet Address
              </label>
              <input
                type="text"
                value={cryptoAddress}
                onChange={(e) => setCryptoAddress(e.target.value)}
                placeholder={network === 'TRC' ? "T... (e.g. TRC20 Wallet Address)" : "e.g. Solana Base58 Wallet Address"}
                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs outline-none focus:ring-2 focus:ring-indigo-500 font-mono"
              />
              <p className="text-[10px] text-slate-400 mt-1">
                {network === 'TRC'
                  ? 'Ensure your TRC20 address is correct. Starts with "T".'
                  : 'Ensure your Solana (SOL) wallet supports USDT tokens.'}
              </p>
            </div>

            <button
              type="submit"
              disabled={submitting}
              className="w-full py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg shadow-indigo-600/30 transition-all disabled:opacity-50"
            >
              {submitting ? 'Processing Request...' : `Submit USDT (${network}) Payout Request`}
            </button>
          </form>
        </div>

        {/* Withdrawal History Table */}
        <div className="lg:col-span-2 p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
          <h2 className="font-extrabold text-base text-slate-900 dark:text-white mb-4">
            Payout History & Logs
          </h2>

          {loadingHistory ? (
            <div className="p-8 text-center text-xs text-slate-400 animate-pulse">
              Loading payout logs...
            </div>
          ) : withdrawals.length === 0 ? (
            <div className="py-12 text-center">
              <Coins className="w-10 h-10 text-slate-300 dark:text-slate-700 mx-auto mb-2" />
              <p className="text-xs font-bold text-slate-500">No withdrawal requests yet</p>
              <p className="text-[11px] text-slate-400 mt-1">Submit your first cash payout request when minimum threshold is met.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-100 dark:border-slate-800 text-slate-400 font-bold uppercase text-[10px]">
                    <th className="pb-3">Date</th>
                    <th className="pb-3">Amount</th>
                    <th className="pb-3">Method & Network</th>
                    <th className="pb-3">Status</th>
                    <th className="pb-3">Ref Code</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60">
                  {withdrawals.map((w) => (
                    <tr key={w.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                      <td className="py-3 text-slate-600 dark:text-slate-300 font-medium">
                        {new Date(w.createdAt).toLocaleDateString()}
                      </td>
                      <td className="py-3 font-extrabold font-mono text-slate-900 dark:text-white">
                        ${w.amount.toFixed(2)} USD
                      </td>
                      <td className="py-3 text-slate-500 dark:text-slate-400 truncate max-w-[180px]">
                        <span className="font-bold text-indigo-600 dark:text-indigo-400">USDT</span>
                        <span className="text-[10px] text-slate-400 block truncate">{w.details}</span>
                      </td>
                      <td className="py-3">
                        <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${
                          w.status === 'APPROVED'
                            ? 'bg-emerald-100 text-emerald-700'
                            : w.status === 'REJECTED'
                            ? 'bg-rose-100 text-rose-700'
                            : 'bg-amber-100 text-amber-700'
                        }`}>
                          {w.status}
                        </span>
                      </td>
                      <td className="py-3 font-mono text-[11px] text-slate-400">
                        {w.paymentRef || 'PENDING-VERIFY'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

      </div>

    </div>
  );
};
