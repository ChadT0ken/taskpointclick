import React, { useState, useEffect } from 'react';
import { Trophy, ShieldCheck, ArrowRight, DollarSign } from 'lucide-react';
import { LeaderboardEntry } from '../types';

export const LandingLeaderboard: React.FC<{ onOpenAuth: () => void }> = ({ onOpenAuth }) => {
  const [rankings, setRankings] = useState<LeaderboardEntry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let isMounted = true;
    setLoading(true);
    fetch('/api/leaderboard?type=EARNERS')
      .then((res) => res.json())
      .then((data) => {
        if (isMounted) {
          setRankings(data);
          setLoading(false);
        }
      })
      .catch((err) => {
        console.error('Failed to fetch cash leaderboard:', err);
        if (isMounted) setLoading(false);
      });
    return () => {
      isMounted = false;
    };
  }, []);

  return (
    <div className="py-12 border-t border-slate-800/80 space-y-8">
      {/* Section Header */}
      <div className="text-center space-y-2 px-4">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-extrabold">
          <Trophy className="w-3.5 h-3.5" />
          <span>Top Cash Earners Leaderboard</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
          Verified Top Cash Earners ($ USDT)
        </h2>
        <p className="text-xs sm:text-sm text-slate-400 max-w-xl mx-auto">
          Real-time leaderboard showcasing verified cash task payouts and successful crypto withdrawals.
        </p>
      </div>

      {/* Top 3 Podium Highlights */}
      {!loading && rankings.length >= 3 && (
        <div className="max-w-4xl mx-auto px-4 grid grid-cols-1 sm:grid-cols-3 gap-4">
          {/* #2 Silver */}
          <div className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 text-center relative flex flex-col justify-between order-2 sm:order-1 backdrop-blur-sm">
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full bg-slate-700 text-slate-200 font-extrabold text-[10px] border border-slate-600">
              🥈 #2 RANK
            </div>
            <div className="mt-2 space-y-2">
              <img
                src={rankings[1].avatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${rankings[1].username}`}
                alt={rankings[1].username}
                className="w-14 h-14 rounded-2xl mx-auto object-cover border-2 border-slate-600 p-0.5 bg-slate-800"
              />
              <div>
                <h3 className="font-extrabold text-sm text-white truncate">{rankings[1].username}</h3>
                <p className="text-[11px] text-slate-400">{rankings[1].country}</p>
              </div>
            </div>
            <div className="mt-3 pt-3 border-t border-slate-800 space-y-1">
              <span className="text-[10px] text-slate-400 block font-medium">Total Cash Earned</span>
              <p className="text-base font-black text-emerald-400">
                ${(rankings[1].cashEarned || rankings[1].value || 0).toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </p>
            </div>
          </div>

          {/* #1 Gold */}
          <div className="p-6 rounded-3xl bg-gradient-to-b from-amber-500/10 via-amber-950/20 to-slate-900 border-2 border-amber-500/80 text-center relative flex flex-col justify-between order-1 sm:order-2 shadow-2xl shadow-amber-500/10 scale-105 z-10">
            <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 px-3.5 py-0.5 rounded-full bg-amber-400 text-slate-950 font-black text-xs shadow-lg flex items-center gap-1">
              <Trophy className="w-3.5 h-3.5 fill-slate-950" />
              <span>🥇 #1 CHAMPION</span>
            </div>
            <div className="mt-2 space-y-2">
              <img
                src={rankings[0].avatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${rankings[0].username}`}
                alt={rankings[0].username}
                className="w-16 h-16 rounded-2xl mx-auto object-cover border-2 border-amber-400 p-0.5 bg-slate-800 shadow-xl"
              />
              <div>
                <h3 className="font-black text-base text-white truncate">{rankings[0].username}</h3>
                <p className="text-xs text-amber-400 font-bold">{rankings[0].country}</p>
              </div>
            </div>
            <div className="mt-3 pt-3 border-t border-amber-500/30 space-y-1">
              <span className="text-[10px] text-amber-300 block font-bold">Total Cash Earned</span>
              <p className="text-lg font-black text-emerald-400">
                ${(rankings[0].cashEarned || rankings[0].value || 0).toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </p>
            </div>
          </div>

          {/* #3 Bronze */}
          <div className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 text-center relative flex flex-col justify-between order-3 backdrop-blur-sm">
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full bg-amber-900 text-amber-200 font-extrabold text-[10px] border border-amber-700/60">
              🥉 #3 RANK
            </div>
            <div className="mt-2 space-y-2">
              <img
                src={rankings[2].avatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${rankings[2].username}`}
                alt={rankings[2].username}
                className="w-14 h-14 rounded-2xl mx-auto object-cover border-2 border-amber-800/80 p-0.5 bg-slate-800"
              />
              <div>
                <h3 className="font-extrabold text-sm text-white truncate">{rankings[2].username}</h3>
                <p className="text-[11px] text-slate-400">{rankings[2].country}</p>
              </div>
            </div>
            <div className="mt-3 pt-3 border-t border-slate-800 space-y-1">
              <span className="text-[10px] text-slate-400 block font-medium">Total Cash Earned</span>
              <p className="text-base font-black text-emerald-400">
                ${(rankings[2].cashEarned || rankings[2].value || 0).toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Leaderboard Table Container */}
      <div className="max-w-4xl mx-auto px-4">
        <div className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800 shadow-xl overflow-hidden backdrop-blur-sm">
          {loading ? (
            <div className="py-12 text-center text-xs text-slate-400 animate-pulse">
              Loading real-time cash rankings...
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-800 text-slate-400 font-bold uppercase text-[10px]">
                    <th className="pb-3 pl-2">Rank</th>
                    <th className="pb-3">Participant</th>
                    <th className="pb-3">Country</th>
                    <th className="pb-3 text-right pr-2">Total Cash Earned ($)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {rankings.slice(0, 8).map((user) => (
                    <tr key={user.userId} className="hover:bg-slate-800/40 transition-colors">
                      <td className="py-3 pl-2 font-black">
                        <span className={`inline-flex items-center justify-center w-6 h-6 rounded-lg text-xs ${
                          user.rank === 1
                            ? 'bg-amber-400 text-slate-950 font-black'
                            : user.rank === 2
                            ? 'bg-slate-300 text-slate-950 font-black'
                            : user.rank === 3
                            ? 'bg-amber-800 text-white font-black'
                            : 'text-slate-500'
                        }`}>
                          #{user.rank}
                        </span>
                      </td>

                      <td className="py-3">
                        <div className="flex items-center gap-2">
                          <img
                            src={user.avatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${user.username}`}
                            alt={user.username}
                            className="w-7 h-7 rounded-lg bg-slate-800 object-cover"
                          />
                          <div>
                            <span className="font-extrabold text-white block">{user.username}</span>
                            <span className="text-[9px] text-emerald-400 font-medium inline-flex items-center gap-1">
                              <ShieldCheck className="w-3 h-3" /> Verified Earner
                            </span>
                          </div>
                        </div>
                      </td>

                      <td className="py-3 text-slate-400 font-medium">{user.country}</td>

                      <td className="py-3 text-right pr-2 font-black text-emerald-400 text-sm">
                        ${(user.cashEarned || user.value || 0).toLocaleString('en-US', { minimumFractionDigits: 2 })}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* Table Bottom Action Banner */}
          <div className="mt-6 pt-6 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="text-center sm:text-left">
              <h4 className="font-bold text-white text-xs">Ready to join the top cash earners?</h4>
              <p className="text-[11px] text-slate-400">Complete instant tasks to earn real cash and withdraw via Solana (SOL) or USDT.</p>
            </div>
            <button
              onClick={onOpenAuth}
              className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs shadow-md transition-all flex items-center gap-2 shrink-0 active:scale-95"
            >
              <span>Join & Start Earning Cash</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
