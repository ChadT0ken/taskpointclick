import React, { useEffect, useState } from 'react';
import { 
  HelpCircle, 
  MessageSquare, 
  Search, 
  Filter, 
  CheckCircle2, 
  Clock, 
  AlertCircle, 
  Send, 
  User, 
  Tag, 
  X,
  ChevronRight,
  ShieldCheck,
  RefreshCw
} from 'lucide-react';
import { api } from '../../lib/api';
import { SupportTicket, TicketStatus } from '../../types';

export const SupportTicketManagement: React.FC = () => {
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedTicket, setSelectedTicket] = useState<SupportTicket | null>(null);
  const [replyMessage, setReplyMessage] = useState('');
  const [submittingReply, setSubmittingReply] = useState(false);
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [searchTerm, setSearchTerm] = useState('');
  const [updatingStatus, setUpdatingStatus] = useState(false);

  const fetchTickets = async () => {
    setLoading(true);
    try {
      const data = await api.getTickets();
      setTickets(data);
      // Keep active ticket in sync if selected
      if (selectedTicket) {
        const updated = data.find((t) => t.id === selectedTicket.id);
        if (updated) setSelectedTicket(updated);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTickets();
  }, []);

  const handleSendReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTicket || !replyMessage.trim()) return;

    setSubmittingReply(true);
    try {
      const updatedTicket = await api.replyTicket(selectedTicket.id, replyMessage.trim());
      setReplyMessage('');
      setSelectedTicket(updatedTicket);
      await fetchTickets();
    } catch (e) {
      console.error(e);
    } finally {
      setSubmittingReply(false);
    }
  };

  const handleStatusChange = async (ticketId: string, newStatus: TicketStatus) => {
    setUpdatingStatus(true);
    try {
      const updated = await api.updateTicketStatus(ticketId, newStatus);
      setSelectedTicket(updated);
      await fetchTickets();
    } catch (e) {
      console.error(e);
    } finally {
      setUpdatingStatus(false);
    }
  };

  // Filter tickets
  const filteredTickets = tickets.filter((t) => {
    const matchesStatus = statusFilter === 'ALL' || t.status === statusFilter;
    const q = searchTerm.toLowerCase();
    const matchesSearch = 
      !q || 
      t.subject.toLowerCase().includes(q) || 
      t.username.toLowerCase().includes(q) || 
      t.id.toLowerCase().includes(q) ||
      t.category.toLowerCase().includes(q);
    return matchesStatus && matchesSearch;
  });

  const openCount = tickets.filter((t) => t.status === 'OPEN').length;
  const inProgressCount = tickets.filter((t) => t.status === 'IN_PROGRESS').length;
  const resolvedCount = tickets.filter((t) => t.status === 'RESOLVED').length;

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-300">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">
              Support Ticket Management
            </h1>
            <span className="px-2.5 py-0.5 text-[10px] font-black rounded-full bg-blue-100 dark:bg-blue-950 text-blue-600 dark:text-blue-400 border border-blue-200">
              ADMIN DESK
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Review user inquiries, respond to support requests, and manage ticket resolution workflow.
          </p>
        </div>

        <button
          onClick={fetchTickets}
          className="px-3.5 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold text-xs flex items-center gap-2 transition-all shrink-0 self-start sm:self-auto"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Refresh Desk</span>
        </button>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase">Total Queue</span>
          <h3 className="text-2xl font-black text-slate-900 dark:text-white mt-1">{tickets.length}</h3>
        </div>
        <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/40 text-amber-900 dark:text-amber-200 shadow-xs">
          <span className="text-[11px] font-bold text-amber-600 uppercase">Open / New</span>
          <h3 className="text-2xl font-black text-amber-600 dark:text-amber-400 mt-1">{openCount}</h3>
        </div>
        <div className="p-4 rounded-2xl bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-900/40 text-indigo-900 dark:text-indigo-200 shadow-xs">
          <span className="text-[11px] font-bold text-indigo-600 uppercase">In Progress</span>
          <h3 className="text-2xl font-black text-indigo-600 dark:text-indigo-400 mt-1">{inProgressCount}</h3>
        </div>
        <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-900/40 text-emerald-900 dark:text-emerald-200 shadow-xs">
          <span className="text-[11px] font-bold text-emerald-600 uppercase">Resolved</span>
          <h3 className="text-2xl font-black text-emerald-600 dark:text-emerald-400 mt-1">{resolvedCount}</h3>
        </div>
      </div>

      {/* Controls Bar */}
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search tickets by subject, user, or ID..."
            className="w-full pl-10 pr-4 py-2 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 text-xs text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
          {['ALL', 'OPEN', 'IN_PROGRESS', 'RESOLVED', 'CLOSED'].map((status) => (
            <button
              key={status}
              onClick={() => setStatusFilter(status)}
              className={`px-3 py-1.5 rounded-lg text-xs font-extrabold whitespace-nowrap transition-all ${
                statusFilter === status
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
              }`}
            >
              {status.replace('_', ' ')}
            </button>
          ))}
        </div>
      </div>

      {/* Tickets Main Table / Card List */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
        {loading ? (
          <div className="py-12 text-center text-xs text-slate-400 animate-pulse">
            Loading Support Desk Tickets...
          </div>
        ) : filteredTickets.length === 0 ? (
          <div className="py-12 text-center space-y-2">
            <HelpCircle className="w-10 h-10 text-slate-300 dark:text-slate-700 mx-auto" />
            <p className="text-xs font-bold text-slate-500">No support tickets match your filter</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-100 dark:border-slate-800 text-slate-400 font-bold uppercase text-[10px]">
                  <th className="pb-3">Ticket ID & Subject</th>
                  <th className="pb-3">Submitted By</th>
                  <th className="pb-3">Category</th>
                  <th className="pb-3">Priority</th>
                  <th className="pb-3">Status</th>
                  <th className="pb-3">Updated</th>
                  <th className="pb-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60">
                {filteredTickets.map((t) => (
                  <tr 
                    key={t.id} 
                    className={`hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors ${
                      selectedTicket?.id === t.id ? 'bg-blue-50/50 dark:bg-blue-950/20' : ''
                    }`}
                  >
                    <td className="py-3.5 pr-2">
                      <p className="font-mono text-[10px] text-slate-400 font-bold">{t.id}</p>
                      <p className="font-extrabold text-slate-900 dark:text-white truncate max-w-xs">{t.subject}</p>
                    </td>

                    <td className="py-3.5 text-slate-700 dark:text-slate-300 font-bold">
                      <div className="flex items-center gap-1.5">
                        <User className="w-3.5 h-3.5 text-slate-400" />
                        <span>@{t.username}</span>
                      </div>
                    </td>

                    <td className="py-3.5 text-slate-500 font-medium">
                      <span className="px-2 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-[10px] font-bold">
                        {t.category}
                      </span>
                    </td>

                    <td className="py-3.5">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-black uppercase ${
                        t.priority === 'HIGH' || t.priority === 'URGENT'
                          ? 'bg-rose-100 dark:bg-rose-950 text-rose-600'
                          : t.priority === 'MEDIUM'
                          ? 'bg-amber-100 dark:bg-amber-950 text-amber-600'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-500'
                      }`}>
                        {t.priority}
                      </span>
                    </td>

                    <td className="py-3.5">
                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase ${
                        t.status === 'OPEN'
                          ? 'bg-amber-100 dark:bg-amber-950 text-amber-600'
                          : t.status === 'IN_PROGRESS'
                          ? 'bg-indigo-100 dark:bg-indigo-950 text-indigo-600'
                          : t.status === 'RESOLVED'
                          ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-600'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-400'
                      }`}>
                        {t.status.replace('_', ' ')}
                      </span>
                    </td>

                    <td className="py-3.5 text-slate-400 font-medium text-[11px]">
                      {new Date(t.updatedAt).toLocaleDateString()}
                    </td>

                    <td className="py-3.5 text-right">
                      <button
                        onClick={() => setSelectedTicket(t)}
                        className="px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs transition-all shadow-xs inline-flex items-center gap-1"
                      >
                        <span>Manage Ticket</span>
                        <ChevronRight className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Ticket Details & Reply Modal */}
      {selectedTicket && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 w-full max-w-3xl rounded-3xl border border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col max-h-[90vh] overflow-hidden animate-in zoom-in-95 duration-200">
            
            {/* Modal Header */}
            <div className="p-6 border-b border-slate-100 dark:border-slate-800 flex items-start justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-mono text-xs font-bold text-blue-600 dark:text-blue-400">{selectedTicket.id}</span>
                  <span className={`px-2 py-0.5 rounded-md text-[10px] font-black uppercase ${
                    selectedTicket.status === 'OPEN'
                      ? 'bg-amber-100 dark:bg-amber-950 text-amber-600'
                      : selectedTicket.status === 'IN_PROGRESS'
                      ? 'bg-indigo-100 dark:bg-indigo-950 text-indigo-600'
                      : 'bg-emerald-100 dark:bg-emerald-950 text-emerald-600'
                  }`}>
                    {selectedTicket.status.replace('_', ' ')}
                  </span>
                </div>
                <h2 className="text-xl font-black text-slate-900 dark:text-white">
                  {selectedTicket.subject}
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                  Submitted by <span className="font-bold text-slate-700 dark:text-slate-200">@{selectedTicket.username}</span> ({selectedTicket.userEmail || 'No email'}) • Category: <span className="font-bold">{selectedTicket.category}</span>
                </p>
              </div>

              <button
                onClick={() => setSelectedTicket(null)}
                className="p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-white bg-slate-100 dark:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Quick Status Action Bar */}
            <div className="px-6 py-3 bg-slate-50 dark:bg-slate-800/40 border-b border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2">
              <span className="text-xs font-extrabold text-slate-600 dark:text-slate-300">
                Update Ticket Status:
              </span>
              <div className="flex items-center gap-2">
                <button
                  disabled={updatingStatus || selectedTicket.status === 'IN_PROGRESS'}
                  onClick={() => handleStatusChange(selectedTicket.id, 'IN_PROGRESS')}
                  className="px-3 py-1 rounded-lg text-xs font-extrabold bg-indigo-100 dark:bg-indigo-950 text-indigo-600 hover:bg-indigo-200 disabled:opacity-50 transition-all cursor-pointer"
                >
                  Set In Progress
                </button>
                <button
                  disabled={updatingStatus || selectedTicket.status === 'RESOLVED'}
                  onClick={() => handleStatusChange(selectedTicket.id, 'RESOLVED')}
                  className="px-3 py-1 rounded-lg text-xs font-extrabold bg-emerald-100 dark:bg-emerald-950 text-emerald-600 hover:bg-emerald-200 disabled:opacity-50 transition-all cursor-pointer"
                >
                  Mark Resolved ✓
                </button>
                <button
                  disabled={updatingStatus || selectedTicket.status === 'CLOSED'}
                  onClick={() => handleStatusChange(selectedTicket.id, 'CLOSED')}
                  className="px-3 py-1 rounded-lg text-xs font-extrabold bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-300 disabled:opacity-50 transition-all cursor-pointer"
                >
                  Close Ticket
                </button>
                {selectedTicket.status === 'CLOSED' && (
                  <button
                    onClick={async () => {
                      if (window.confirm('Permanently purge this ticket now?')) {
                        await api.deleteTicket(selectedTicket.id);
                        setSelectedTicket(null);
                        await fetchTickets();
                      }
                    }}
                    className="px-3 py-1 rounded-lg text-xs font-extrabold bg-rose-100 dark:bg-rose-950 text-rose-600 hover:bg-rose-200 transition-all cursor-pointer"
                  >
                    Delete Now
                  </button>
                )}
              </div>
            </div>

            {selectedTicket.status === 'CLOSED' && (
              <div className="px-6 py-2 bg-amber-50 dark:bg-amber-950/40 border-b border-amber-200 dark:border-amber-900/40 text-[11px] text-amber-800 dark:text-amber-300 font-bold flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5" />
                <span>Notice: This ticket is closed and will be automatically purged 72 hours after closure.</span>
              </div>
            )}

            {/* Conversation Messages Thread */}
            <div className="flex-1 overflow-y-auto p-6 space-y-4">
              {selectedTicket.replies?.map((reply, idx) => (
                <div
                  key={idx}
                  className={`p-4 rounded-2xl space-y-2 border ${
                    reply.isAdminReply
                      ? 'bg-blue-50/80 dark:bg-blue-950/30 border-blue-200 dark:border-blue-900/50 ml-6'
                      : 'bg-slate-50 dark:bg-slate-800/50 border-slate-200 dark:border-slate-800 mr-6'
                  }`}
                >
                  <div className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2 font-bold">
                      {reply.isAdminReply ? (
                        <div className="flex items-center gap-1 text-blue-600 dark:text-blue-400">
                          <ShieldCheck className="w-4 h-4" />
                          <span>TaskPoint Support Agent ({reply.username})</span>
                        </div>
                      ) : (
                        <div className="flex items-center gap-1 text-slate-900 dark:text-white">
                          <User className="w-3.5 h-3.5 text-slate-400" />
                          <span>@{reply.username}</span>
                        </div>
                      )}
                    </div>
                    <span className="text-[10px] text-slate-400">
                      {new Date(reply.createdAt).toLocaleString()}
                    </span>
                  </div>

                  <p className="text-xs text-slate-800 dark:text-slate-200 whitespace-pre-line leading-relaxed">
                    {reply.message}
                  </p>
                </div>
              ))}
            </div>

            {/* Reply Input Box */}
            <form onSubmit={handleSendReply} className="p-4 border-t border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 flex items-center gap-3">
              <input
                type="text"
                required
                value={replyMessage}
                onChange={(e) => setReplyMessage(e.target.value)}
                placeholder="Type official support reply to user..."
                className="flex-1 px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-800 text-xs text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-blue-500"
              />
              <button
                type="submit"
                disabled={submittingReply || !replyMessage.trim()}
                className="px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-md flex items-center gap-2 transition-all disabled:opacity-50 shrink-0"
              >
                <Send className="w-4 h-4" />
                <span>{submittingReply ? 'Sending...' : 'Send Reply'}</span>
              </button>
            </form>

          </div>
        </div>
      )}

    </div>
  );
};
