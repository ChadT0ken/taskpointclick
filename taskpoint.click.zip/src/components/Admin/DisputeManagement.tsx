import React, { useEffect, useState } from 'react';
import { 
  AlertTriangle, 
  CheckCircle2, 
  XCircle, 
  ExternalLink, 
  User, 
  FileText
} from 'lucide-react';
import { api } from '../../lib/api';
import { Dispute } from '../../types';

export const DisputeManagement: React.FC = () => {
  const [disputes, setDisputes] = useState<Dispute[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchDisputes = async () => {
    try {
      const data = await api.adminGetDisputes();
      setDisputes(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDisputes();
  }, []);

  const handleResolve = async (id: string, status: 'APPROVED' | 'REJECTED') => {
    try {
      await api.adminReviewDispute(id, { status, adminComment: `Dispute ${status.toLowerCase()} by admin` });
      await fetchDisputes();
    } catch (err: any) {
      alert(err.message || 'Action failed');
    }
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-300">
      
      {/* Header */}
      <div>
        <h1 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">
          Dispute Resolution Center
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          Review user appeals on rejected task submissions. Overturn rejections if updated proof is valid.
        </p>
      </div>

      {/* Disputes Queue */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
        {loading ? (
          <div className="py-8 text-center text-xs text-slate-400 animate-pulse">Loading disputes...</div>
        ) : disputes.length === 0 ? (
          <div className="py-12 text-center">
            <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto mb-2" />
            <h3 className="font-extrabold text-sm text-slate-800 dark:text-slate-200">No active disputes</h3>
          </div>
        ) : (
          <div className="space-y-4">
            {disputes.map((disp) => (
              <div
                key={disp.id}
                className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                <div className="space-y-2 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-black text-xs text-slate-900 dark:text-white">
                      User: @{disp.username}
                    </span>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${
                      disp.status === 'APPROVED' ? 'bg-emerald-100 text-emerald-700' : disp.status === 'REJECTED' ? 'bg-rose-100 text-rose-700' : 'bg-amber-100 text-amber-700'
                    }`}>
                      {disp.status}
                    </span>
                  </div>

                  <p className="text-xs font-semibold text-slate-800 dark:text-slate-200">
                    Appeal Reason: "{disp.reason}"
                  </p>

                  {disp.additionalProof && (
                    <p className="text-xs text-indigo-600 font-bold truncate">
                      Additional Proof: {disp.additionalProof}
                    </p>
                  )}
                </div>

                {disp.status === 'PENDING' && (
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => handleResolve(disp.id, 'APPROVED')}
                      className="px-4 py-2 rounded-xl bg-emerald-600 text-white font-bold text-xs shadow-md shadow-emerald-600/25"
                    >
                      Overturn & Approve Task
                    </button>
                    <button
                      onClick={() => handleResolve(disp.id, 'REJECTED')}
                      className="px-4 py-2 rounded-xl bg-rose-600 text-white font-bold text-xs shadow-md shadow-rose-600/25"
                    >
                      Maintain Rejection
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

    </div>
  );
};
