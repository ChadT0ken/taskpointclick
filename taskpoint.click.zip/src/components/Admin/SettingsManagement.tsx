import React, { useEffect, useState } from 'react';
import { 
  Settings, 
  Save, 
  CheckCircle2, 
  ShieldAlert, 
  Coins, 
  Gift, 
  Power
} from 'lucide-react';
import { api } from '../../lib/api';

export const SettingsManagement: React.FC = () => {
  const [siteName, setSiteName] = useState('TaskPoint');
  const [minWithdrawalUsd, setMinWithdrawalUsd] = useState('5');
  const [referralBonusPoints, setReferralBonusPoints] = useState('100');
  const [maintenanceMode, setMaintenanceMode] = useState(false);

  const [saving, setSaving] = useState(false);
  const [savedMsg, setSavedMsg] = useState(false);

  const fetchSettings = async () => {
    try {
      const data = await api.getSettings();
      setSiteName(data.websiteName || 'TaskPoint');
      setMinWithdrawalUsd(data.minWithdrawalUSD?.toString() || '5');
      setReferralBonusPoints(data.referralPointsBonus?.toString() || '100');
      setMaintenanceMode(!!data.maintenanceMode);
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    fetchSettings();
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setSavedMsg(false);

    try {
      await api.updateSettings({
        websiteName: siteName,
        minWithdrawalUSD: parseFloat(minWithdrawalUsd),
        referralPointsBonus: parseInt(referralBonusPoints),
        maintenanceMode,
      });
      setSavedMsg(true);
      setTimeout(() => setSavedMsg(false), 3000);
    } catch (err: any) {
      alert(err.message || 'Failed to update settings');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-300">
      
      {/* Header */}
      <div>
        <h1 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">
          System Settings & Parameters
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          Configure minimum payout parameters, referral bonuses, and emergency maintenance toggles.
        </p>
      </div>

      {savedMsg && (
        <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 text-emerald-700 text-xs font-bold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-500" />
          <span>System settings updated successfully!</span>
        </div>
      )}

      {/* Form */}
      <form onSubmit={handleSave} className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6 max-w-2xl">
        
        <div>
          <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
            Platform Branding Name
          </label>
          <input
            type="text"
            required
            value={siteName}
            onChange={(e) => setSiteName(e.target.value)}
            className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        <div>
          <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
            Minimum USD Withdrawal ($)
          </label>
          <input
            type="number"
            step="any"
            required
            value={minWithdrawalUsd}
            onChange={(e) => setMinWithdrawalUsd(e.target.value)}
            className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs outline-none focus:ring-2 focus:ring-indigo-500 font-mono"
          />
        </div>

        <div>
          <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
            Referral XP Bonus per Signup (XP)
          </label>
          <input
            type="number"
            required
            value={referralBonusPoints}
            onChange={(e) => setReferralBonusPoints(e.target.value)}
            className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        {/* Maintenance Toggle */}
        <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
          <div>
            <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
              <Power className="w-4 h-4 text-rose-500" />
              <span>System Maintenance Mode</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Temporarily restrict new task submissions and withdrawals for system upgrades.
            </p>
          </div>

          <button
            type="button"
            onClick={() => setMaintenanceMode(!maintenanceMode)}
            className={`w-12 h-6 rounded-full transition-colors relative ${
              maintenanceMode ? 'bg-rose-600' : 'bg-slate-300 dark:bg-slate-700'
            }`}
          >
            <div className={`w-5 h-5 rounded-full bg-white transition-transform absolute top-0.5 ${
              maintenanceMode ? 'translate-x-6' : 'translate-x-0.5'
            }`}></div>
          </button>
        </div>

        <button
          type="submit"
          disabled={saving}
          className="w-full py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 transition-all"
        >
          <Save className="w-4 h-4" />
          <span>{saving ? 'Saving...' : 'Save System Parameters'}</span>
        </button>

      </form>

    </div>
  );
};
