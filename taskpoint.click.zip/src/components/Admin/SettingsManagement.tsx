import React, { useEffect, useState } from 'react';
import { 
  Settings, 
  Save, 
  CheckCircle2, 
  ShieldAlert, 
  Coins, 
  Gift, 
  Power,
  Shield,
  ShieldCheck,
  Globe,
  Search,
  Trash2,
  Plus,
  RefreshCw,
  AlertTriangle,
  Server,
  Activity,
  Zap,
  Lock,
  Mail,
  Send,
  UserX,
  UserCheck
} from 'lucide-react';
import { api } from '../../lib/api';
import { VpnBlockLog, IpInspectionResult, EmailLogEntry } from '../../types';

export const SettingsManagement: React.FC = () => {
  const [siteName, setSiteName] = useState('TaskPoint');
  const [minWithdrawalUsd, setMinWithdrawalUsd] = useState('5');
  const [referralBonusPoints, setReferralBonusPoints] = useState('20');
  const [maintenanceMode, setMaintenanceMode] = useState(false);
  const [strictVpnBlocking, setStrictVpnBlocking] = useState(true);
  const [blockDataCenters, setBlockDataCenters] = useState(true);
  const [vpnWhitelistedIps, setVpnWhitelistedIps] = useState<string[]>([]);
  const [newWhitelistIp, setNewWhitelistIp] = useState('');

  const [saving, setSaving] = useState(false);
  const [savedMsg, setSavedMsg] = useState(false);

  // IP Inspector State
  const [inspectIpInput, setInspectIpInput] = useState('');
  const [inspecting, setInspecting] = useState(false);
  const [inspectResult, setInspectResult] = useState<IpInspectionResult | null>(null);
  const [inspectError, setInspectError] = useState<string | null>(null);

  // VPN Logs State
  const [vpnLogs, setVpnLogs] = useState<VpnBlockLog[]>([]);
  const [loadingLogs, setLoadingLogs] = useState(false);
  const [clearingLogs, setClearingLogs] = useState(false);

  // Email Notification Logs State
  const [emailLogs, setEmailLogs] = useState<EmailLogEntry[]>([]);
  const [loadingEmailLogs, setLoadingEmailLogs] = useState(false);
  const [clearingEmailLogs, setClearingEmailLogs] = useState(false);

  const fetchSettings = async () => {
    try {
      const data = await api.getSettings();
      setSiteName(data.websiteName || 'TaskPoint');
      setMinWithdrawalUsd(data.minWithdrawalUSD?.toString() || '5');
      setReferralBonusPoints(data.referralPointsBonus?.toString() || '20');
      setMaintenanceMode(!!data.maintenanceMode);
      setStrictVpnBlocking(data.strictVpnBlocking !== false);
      setBlockDataCenters(data.blockDataCenters !== false);
      setVpnWhitelistedIps(data.vpnWhitelistedIps || []);
    } catch (e) {
      console.error(e);
    }
  };

  const fetchLogs = async () => {
    setLoadingLogs(true);
    try {
      const logs = await api.adminGetVpnLogs();
      setVpnLogs(logs);
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingLogs(false);
    }
  };

  const fetchEmailLogs = async () => {
    setLoadingEmailLogs(true);
    try {
      const logs = await api.adminGetEmailLogs();
      setEmailLogs(logs);
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingEmailLogs(false);
    }
  };

  const handleClearEmailLogs = async () => {
    if (!window.confirm('Clear all user email notification dispatch logs?')) return;
    setClearingEmailLogs(true);
    try {
      await api.adminClearEmailLogs();
      setEmailLogs([]);
    } catch (e) {
      console.error(e);
    } finally {
      setClearingEmailLogs(false);
    }
  };

  useEffect(() => {
    fetchSettings();
    fetchLogs();
    fetchEmailLogs();
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setSavedMsg(false);

    try {
      await api.updateSettings({
        websiteName: siteName,
        minWithdrawalUSD: parseFloat(minWithdrawalUsd),
        referralPointsBonus: parseInt(referralBonusPoints),
        maintenanceMode,
        strictVpnBlocking,
        blockDataCenters,
        vpnWhitelistedIps,
      });
      setSavedMsg(true);
      setTimeout(() => setSavedMsg(false), 3000);
    } catch (err: any) {
      alert(err.message || 'Failed to update settings');
    } finally {
      setSaving(false);
    }
  };

  const handleAddWhitelistIp = () => {
    const clean = newWhitelistIp.trim();
    if (!clean) return;
    if (vpnWhitelistedIps.includes(clean)) {
      alert('This IP is already whitelisted.');
      return;
    }
    setVpnWhitelistedIps([...vpnWhitelistedIps, clean]);
    setNewWhitelistIp('');
  };

  const handleRemoveWhitelistIp = (ipToRemove: string) => {
    setVpnWhitelistedIps(vpnWhitelistedIps.filter(ip => ip !== ipToRemove));
  };

  const handleInspectIp = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanIp = inspectIpInput.trim();
    if (!cleanIp) return;

    setInspecting(true);
    setInspectResult(null);
    setInspectError(null);

    try {
      const result = await api.adminInspectIp(cleanIp);
      setInspectResult(result);
    } catch (err: any) {
      setInspectError(err.message || 'Failed to inspect IP address');
    } finally {
      setInspecting(false);
    }
  };

  const handleClearLogs = async () => {
    if (!window.confirm('Are you sure you want to clear all VPN and Proxy block logs?')) return;
    setClearingLogs(true);
    try {
      await api.adminClearVpnLogs();
      setVpnLogs([]);
    } catch (err: any) {
      alert(err.message || 'Failed to clear logs');
    } finally {
      setClearingLogs(false);
    }
  };

  return (
    <div className="space-y-8 pb-12 animate-in fade-in duration-300">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight flex items-center gap-2.5">
            <Shield className="w-7 h-7 text-indigo-600 dark:text-indigo-400" />
            <span>System Settings & Security Guard</span>
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Manage anti-fraud proxy/VPN detection, platform payout limits, and whitelisted IP controls.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <div className="px-3 py-1.5 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 text-xs font-bold flex items-center gap-1.5">
            <ShieldCheck className="w-4 h-4 text-emerald-500" />
            <span>Anti-VPN Active</span>
          </div>
        </div>
      </div>

      {savedMsg && (
        <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 text-xs font-bold flex items-center gap-2 animate-in fade-in">
          <CheckCircle2 className="w-4 h-4 text-emerald-500" />
          <span>System and Security settings updated successfully!</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Main Settings Form (Left 7 Cols) */}
        <div className="lg:col-span-7 space-y-6">
          <form onSubmit={handleSave} className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
            
            <div className="flex items-center gap-2 pb-4 border-b border-slate-100 dark:border-slate-800">
              <Settings className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
              <h2 className="text-base font-extrabold text-slate-900 dark:text-white">Core Platform Parameters</h2>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Platform Branding Name
                </label>
                <input
                  type="text"
                  required
                  value={siteName}
                  onChange={(e) => setSiteName(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Minimum USD Withdrawal ($)
                  </label>
                  <input
                    type="number"
                    step="any"
                    required
                    value={minWithdrawalUsd}
                    onChange={(e) => setMinWithdrawalUsd(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs outline-none focus:ring-2 focus:ring-indigo-500 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Referral Bonus XP (per invite)
                  </label>
                  <input
                    type="number"
                    required
                    value={referralBonusPoints}
                    onChange={(e) => setReferralBonusPoints(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>
            </div>

            {/* STRICT VPN & PROXY SECURITY SECTION */}
            <div className="pt-6 border-t border-slate-100 dark:border-slate-800 space-y-5">
              <div className="flex items-center gap-2">
                <ShieldAlert className="w-5 h-5 text-amber-500" />
                <div>
                  <h3 className="font-extrabold text-sm text-slate-900 dark:text-white">Strict VPN & Anti-Proxy Engine</h3>
                  <p className="text-[11px] text-slate-400">Block fraudulent multi-account farmings, VPN relays, and datacenter bots.</p>
                </div>
              </div>

              {/* Strict VPN Toggle */}
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-700/60 flex items-center justify-between gap-4">
                <div>
                  <div className="font-bold text-xs text-slate-800 dark:text-slate-200 flex items-center gap-2">
                    <span>Block VPN & Proxy Authentication</span>
                    {strictVpnBlocking && (
                      <span className="px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 text-[10px] font-mono font-bold">ENFORCED</span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-400 mt-0.5 leading-relaxed">
                    Instantly denies login, registration, and Google Auth from known VPN exit nodes (NordVPN, Surfshark, ExpressVPN, Mullvad, etc.).
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => setStrictVpnBlocking(!strictVpnBlocking)}
                  className={`w-12 h-6 rounded-full transition-colors relative shrink-0 ${
                    strictVpnBlocking ? 'bg-indigo-600' : 'bg-slate-300 dark:bg-slate-700'
                  }`}
                >
                  <div className={`w-5 h-5 rounded-full bg-white transition-transform absolute top-0.5 ${
                    strictVpnBlocking ? 'translate-x-6' : 'translate-x-0.5'
                  }`}></div>
                </button>
              </div>

              {/* Block Datacenter Toggle */}
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-700/60 flex items-center justify-between gap-4">
                <div>
                  <div className="font-bold text-xs text-slate-800 dark:text-slate-200 flex items-center gap-2">
                    <span>Block Datacenter & Cloud Hosting IPs</span>
                    {blockDataCenters && (
                      <span className="px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-600 dark:text-blue-400 text-[10px] font-mono font-bold">ACTIVE</span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-400 mt-0.5 leading-relaxed">
                    Blocks connections originating from AWS, DigitalOcean, Linode, Hetzner, OVH, Google Cloud, and private proxy servers.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => setBlockDataCenters(!blockDataCenters)}
                  className={`w-12 h-6 rounded-full transition-colors relative shrink-0 ${
                    blockDataCenters ? 'bg-indigo-600' : 'bg-slate-300 dark:bg-slate-700'
                  }`}
                >
                  <div className={`w-5 h-5 rounded-full bg-white transition-transform absolute top-0.5 ${
                    blockDataCenters ? 'translate-x-6' : 'translate-x-0.5'
                  }`}></div>
                </button>
              </div>

              {/* IP Whitelist Manager */}
              <div className="space-y-3">
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                  Whitelisted IP Addresses (Exempt from VPN/Proxy rules)
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="e.g. 102.89.33.10"
                    value={newWhitelistIp}
                    onChange={(e) => setNewWhitelistIp(e.target.value)}
                    className="flex-1 px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs outline-none focus:ring-2 focus:ring-indigo-500 font-mono"
                  />
                  <button
                    type="button"
                    onClick={handleAddWhitelistIp}
                    className="px-4 py-2 rounded-xl bg-slate-800 dark:bg-slate-700 hover:bg-slate-700 text-white text-xs font-bold flex items-center gap-1.5 transition-all"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add IP</span>
                  </button>
                </div>

                {vpnWhitelistedIps.length > 0 ? (
                  <div className="flex flex-wrap gap-2 pt-1">
                    {vpnWhitelistedIps.map((ip) => (
                      <span
                        key={ip}
                        className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 text-xs font-mono"
                      >
                        <span>{ip}</span>
                        <button
                          type="button"
                          onClick={() => handleRemoveWhitelistIp(ip)}
                          className="text-slate-400 hover:text-rose-500 p-0.5"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </span>
                    ))}
                  </div>
                ) : (
                  <p className="text-[11px] text-slate-400 italic">No custom whitelisted IPs configured.</p>
                )}
              </div>
            </div>

            {/* Maintenance Toggle */}
            <div className="pt-6 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                  <Power className="w-4 h-4 text-rose-500" />
                  <span>System Maintenance Mode</span>
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Temporarily restrict user actions for maintenance window.
                </p>
              </div>

              <button
                type="button"
                onClick={() => setMaintenanceMode(!maintenanceMode)}
                className={`w-12 h-6 rounded-full transition-colors relative ${
                  maintenanceMode ? 'bg-rose-600' : 'bg-slate-300 dark:bg-slate-700'
                }`}
              >
                <div className={`w-5 h-5 rounded-full bg-white transition-transform absolute top-0.5 ${
                  maintenanceMode ? 'translate-x-6' : 'translate-x-0.5'
                }`}></div>
              </button>
            </div>

            <button
              type="submit"
              disabled={saving}
              className="w-full py-3.5 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-60"
            >
              <Save className="w-4 h-4" />
              <span>{saving ? 'Saving Settings...' : 'Save All System & Security Settings'}</span>
            </button>

          </form>
        </div>

        {/* Live IP Inspector Tool & Block Logs (Right 5 Cols) */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Real-time IP Inspector */}
          <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <div className="flex items-center gap-2">
              <Search className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
              <div>
                <h3 className="font-extrabold text-sm text-slate-900 dark:text-white">IP Intelligence Inspector</h3>
                <p className="text-[11px] text-slate-400">Test any IP address against the VPN detection engine.</p>
              </div>
            </div>

            <form onSubmit={handleInspectIp} className="space-y-2.5">
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Enter IP (e.g. 185.220.101.5)"
                  value={inspectIpInput}
                  onChange={(e) => setInspectIpInput(e.target.value)}
                  className="flex-1 px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs outline-none focus:ring-2 focus:ring-indigo-500 font-mono"
                />
                <button
                  type="submit"
                  disabled={inspecting}
                  className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold flex items-center gap-1.5 transition-all disabled:opacity-60 cursor-pointer"
                >
                  <Activity className="w-3.5 h-3.5" />
                  <span>{inspecting ? 'Testing...' : 'Inspect'}</span>
                </button>
              </div>
            </form>

            {inspectError && (
              <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800 text-rose-600 text-xs font-semibold">
                {inspectError}
              </div>
            )}

            {inspectResult && (
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-3 animate-in fade-in">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-xs font-bold text-slate-900 dark:text-white">
                    {inspectResult.ip}
                  </span>
                  <span
                    className={`px-2 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${
                      inspectResult.isVpnOrProxy || inspectResult.isDatacenter || inspectResult.threatScore > 50
                        ? 'bg-rose-500/20 text-rose-600 dark:text-rose-400'
                        : 'bg-emerald-500/20 text-emerald-600 dark:text-emerald-400'
                    }`}
                  >
                    {inspectResult.isVpnOrProxy || inspectResult.isDatacenter || inspectResult.threatScore > 50
                      ? 'BLOCKED / HIGH RISK'
                      : 'ALLOWED / CLEAN'}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-[11px]">
                  <div className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800">
                    <span className="text-slate-400 block text-[10px]">Location</span>
                    <span className="font-bold text-slate-800 dark:text-slate-200">
                      {inspectResult.city ? `${inspectResult.city}, ` : ''}{inspectResult.country} ({inspectResult.countryCode})
                    </span>
                  </div>
                  <div className="p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800">
                    <span className="text-slate-400 block text-[10px]">Threat Score</span>
                    <span className={`font-mono font-bold ${inspectResult.threatScore > 50 ? 'text-rose-500' : 'text-emerald-500'}`}>
                      {inspectResult.threatScore || 0}/100
                    </span>
                  </div>
                  <div className="col-span-2 p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800">
                    <span className="text-slate-400 block text-[10px]">ISP & Network</span>
                    <span className="font-semibold text-slate-700 dark:text-slate-300 truncate block">
                      {inspectResult.isp || inspectResult.org || 'Unknown'} {inspectResult.as ? `(${inspectResult.as})` : ''}
                    </span>
                  </div>
                </div>

                <div className="text-[11px] text-slate-500 dark:text-slate-400 bg-white/70 dark:bg-slate-900/70 p-2.5 rounded-xl border border-slate-100 dark:border-slate-800">
                  <span className="font-bold text-slate-700 dark:text-slate-300">Diagnosis: </span>
                  <span>{inspectResult.reason || 'Clean residential/mobile network.'}</span>
                </div>
              </div>
            )}
          </div>

          {/* Recent Blocked VPN Logs */}
          <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShieldAlert className="w-5 h-5 text-rose-500" />
                <div>
                  <h3 className="font-extrabold text-sm text-slate-900 dark:text-white">Blocked Attempts</h3>
                  <p className="text-[11px] text-slate-400">Live feed of blocked VPN / Proxy logins & actions.</p>
                </div>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={fetchLogs}
                  disabled={loadingLogs}
                  className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                  title="Refresh Logs"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${loadingLogs ? 'animate-spin' : ''}`} />
                </button>
                {vpnLogs.length > 0 && (
                  <button
                    type="button"
                    onClick={handleClearLogs}
                    disabled={clearingLogs}
                    className="p-2 rounded-xl bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-300 hover:bg-rose-100 transition-colors"
                    title="Clear All Logs"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>

            {vpnLogs.length === 0 ? (
              <div className="p-8 text-center rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800">
                <ShieldCheck className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
                <p className="text-xs font-bold text-slate-700 dark:text-slate-300">No Blocked Connections</p>
                <p className="text-[11px] text-slate-400 mt-0.5">All incoming logins and registrations have passed VPN security checks.</p>
              </div>
            ) : (
              <div className="space-y-2.5 max-h-80 overflow-y-auto pr-1">
                {vpnLogs.map((log) => (
                  <div
                    key={log.id}
                    className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-700/60 space-y-1 text-xs"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-mono font-bold text-slate-900 dark:text-white">
                        {log.ip}
                      </span>
                      <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-rose-500/15 text-rose-600 dark:text-rose-400 uppercase font-mono">
                        {log.action}
                      </span>
                    </div>

                    <div className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center justify-between">
                      <span>Target: <strong className="text-slate-700 dark:text-slate-300">{log.usernameOrEmail || 'Anonymous'}</strong></span>
                      <span>{new Date(log.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                    </div>

                    <div className="text-[11px] text-slate-600 dark:text-slate-300 truncate">
                      {log.city ? `${log.city}, ` : ''}{log.country || 'Unknown'} • {log.isp || log.org || 'VPN Provider'}
                    </div>

                    <div className="text-[10px] text-rose-600 dark:text-rose-400 font-medium">
                      Reason: {log.reason}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Recent Email Notification Dispatch Logs */}
          <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Mail className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
                <div>
                  <h3 className="font-extrabold text-sm text-slate-900 dark:text-white">Email Notification Audit</h3>
                  <p className="text-[11px] text-slate-400">Automated emails sent on Ban, Restrict, and Delete actions.</p>
                </div>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={fetchEmailLogs}
                  disabled={loadingEmailLogs}
                  className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                  title="Refresh Email Logs"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${loadingEmailLogs ? 'animate-spin' : ''}`} />
                </button>
                {emailLogs.length > 0 && (
                  <button
                    type="button"
                    onClick={handleClearEmailLogs}
                    disabled={clearingEmailLogs}
                    className="p-2 rounded-xl bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-300 hover:bg-rose-100 transition-colors"
                    title="Clear All Email Logs"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                )}
              </div>
            </div>

            {emailLogs.length === 0 ? (
              <div className="p-8 text-center rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800">
                <Send className="w-8 h-8 text-indigo-400 mx-auto mb-2 opacity-60" />
                <p className="text-xs font-bold text-slate-700 dark:text-slate-300">No Emails Dispatched Yet</p>
                <p className="text-[11px] text-slate-400 mt-0.5">Automated notification emails triggered during user bans, restrictions, and deletions will be logged here.</p>
              </div>
            ) : (
              <div className="space-y-2.5 max-h-80 overflow-y-auto pr-1">
                {emailLogs.map((log) => (
                  <div
                    key={log.id}
                    className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/70 dark:border-slate-700/60 space-y-1 text-xs"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-bold text-slate-900 dark:text-white truncate">
                        {log.toEmail}
                      </span>
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-extrabold uppercase font-mono ${
                          log.action === 'BANNED'
                            ? 'bg-rose-500/20 text-rose-600 dark:text-rose-400'
                            : log.action === 'DELETED'
                            ? 'bg-red-500/25 text-red-700 dark:text-red-300'
                            : log.action === 'RESTRICTED'
                            ? 'bg-amber-500/20 text-amber-600 dark:text-amber-400'
                            : 'bg-emerald-500/20 text-emerald-600 dark:text-emerald-400'
                        }`}
                      >
                        {log.action}
                      </span>
                    </div>

                    <div className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center justify-between">
                      <span>User: <strong className="text-slate-700 dark:text-slate-300">@{log.username}</strong></span>
                      <span>{new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                    </div>

                    <div className="text-[11px] text-slate-600 dark:text-slate-300 font-medium">
                      Subject: {log.subject}
                    </div>

                    {log.reason && (
                      <div className="text-[10px] text-slate-500 dark:text-slate-400 bg-white/70 dark:bg-slate-900/70 p-1.5 rounded-lg border border-slate-100 dark:border-slate-800">
                        Reason: <span className="text-slate-700 dark:text-slate-300">{log.reason}</span>
                      </div>
                    )}

                    <div className="flex items-center justify-between pt-0.5 text-[10px]">
                      <span className="text-slate-400">Status: <strong className="text-emerald-600 dark:text-emerald-400">{log.status}</strong></span>
                      <span className="text-slate-400">{new Date(log.timestamp).toLocaleDateString()}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

        </div>

      </div>

    </div>
  );
};
