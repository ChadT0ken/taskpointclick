import React, { useEffect, useState } from 'react';
import { 
  Users, 
  CheckSquare, 
  Wallet, 
  Sparkles, 
  ShieldAlert, 
  TrendingUp, 
  Clock, 
  AlertTriangle,
  ArrowUpRight,
  BarChart3
} from 'lucide-react';
import { api } from '../../lib/api';
import { AdminStats } from '../../types';

interface AdminDashboardProps {
  onNavigate: (view: string) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onNavigate }) => {
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchStats = async () => {
    try {
      const data = await api.getAdminStats();
      setStats(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStats();
  }, []);

  if (loading) {
    return (
      <div className="py-12 text-center text-xs text-slate-400 animate-pulse">
        Loading Admin Analytics...
      </div>
    );
  }

  if (!stats) return null;

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-300">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">
              Admin Control Center
            </h1>
            <span className="px-2 py-0.5 text-[10px] font-black rounded-full bg-rose-100 dark:bg-rose-950 text-rose-600 dark:text-rose-400 border border-rose-200">
              SECURE PORTAL
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Real-time platform metrics, pending reviews, user management, and system parameters.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigate('admin-submissions')}
            className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs shadow-md shadow-amber-500/25 flex items-center gap-2 transition-all"
          >
            <Clock className="w-4 h-4" />
            <span>Pending Reviews ({stats.pendingSubmissions})</span>
          </button>
        </div>
      </div>

      {/* Primary Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Total Registered Users */}
        <div 
          onClick={() => onNavigate('admin-users')}
          className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm cursor-pointer hover:border-rose-500 transition-all"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Total Users</span>
            <div className="p-2 rounded-xl bg-indigo-50 dark:bg-indigo-950 text-indigo-600">
              <Users className="w-5 h-5" />
            </div>
          </div>
          <h3 className="text-3xl font-black text-slate-900 dark:text-white">{stats.totalUsers}</h3>
          <p className="text-[11px] text-emerald-600 font-bold mt-2 flex items-center gap-1">
            <span>+{stats.todaySignups} signups today</span>
          </p>
        </div>

        {/* Pending Submissions */}
        <div 
          onClick={() => onNavigate('admin-submissions')}
          className="p-5 rounded-3xl bg-gradient-to-br from-amber-500 to-orange-600 text-white shadow-xl shadow-amber-500/15 cursor-pointer hover:scale-[1.02] transition-all"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-amber-100 uppercase tracking-wider">Pending Tasks</span>
            <div className="p-2 rounded-xl bg-white/10">
              <CheckSquare className="w-5 h-5" />
            </div>
          </div>
          <h3 className="text-3xl font-black">{stats.pendingSubmissions}</h3>
          <p className="text-[11px] text-amber-100 mt-2 font-semibold">
            Requires verification
          </p>
        </div>

        {/* Pending Withdrawals */}
        <div 
          onClick={() => onNavigate('admin-withdrawals')}
          className="p-5 rounded-3xl bg-gradient-to-br from-rose-600 to-pink-700 text-white shadow-xl shadow-rose-600/15 cursor-pointer hover:scale-[1.02] transition-all"
        >
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-rose-100 uppercase tracking-wider">Pending Payouts</span>
            <div className="p-2 rounded-xl bg-white/10">
              <Wallet className="w-5 h-5" />
            </div>
          </div>
          <h3 className="text-3xl font-black">{stats.pendingWithdrawals}</h3>
          <p className="text-[11px] text-rose-100 mt-2 font-semibold">
            Bank / USDT payout requests
          </p>
        </div>

        {/* Total Points Distributed */}
        <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Points Awarded</span>
            <div className="p-2 rounded-xl bg-purple-50 dark:bg-purple-950 text-purple-600">
              <Sparkles className="w-5 h-5" />
            </div>
          </div>
          <h3 className="text-3xl font-black text-slate-900 dark:text-white">
            {stats.totalPointsDistributed.toLocaleString()} <span className="text-xs text-purple-500">PTS</span>
          </h3>
          <p className="text-[11px] text-slate-500 mt-2">
            Includes tasks & referral bonuses
          </p>
        </div>

      </div>

      {/* Visual Analytics Chart Placeholder */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="font-extrabold text-base text-slate-900 dark:text-white flex items-center gap-2">
              <BarChart3 className="w-5 h-5 text-indigo-600" />
              <span>7-Day Activity & Payout Volume</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Daily task completions and cash payout distribution metrics.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-7 gap-2 sm:gap-4 items-end h-44 pt-6 pb-2">
          {stats.dailyStats.map((item, idx) => {
            const heightPercent = Math.min(100, Math.max(15, Math.round((item.tasks / 130) * 100)));
            return (
              <div key={idx} className="flex flex-col items-center gap-2 h-full justify-end group">
                <div 
                  className="w-full bg-gradient-to-t from-indigo-600 to-purple-500 rounded-xl group-hover:from-indigo-500 group-hover:to-purple-400 transition-all relative"
                  style={{ height: `${heightPercent}%` }}
                >
                  <div className="opacity-0 group-hover:opacity-100 absolute -top-8 left-1/2 -translate-x-1/2 px-2 py-1 bg-slate-900 text-white text-[10px] rounded font-bold whitespace-nowrap transition-opacity pointer-events-none">
                    {item.tasks} Tasks (${item.payouts.toLocaleString()})
                  </div>
                </div>
                <span className="text-[11px] font-bold text-slate-500">{item.date}</span>
              </div>
            );
          })}
        </div>
      </div>

    </div>
  );
};
