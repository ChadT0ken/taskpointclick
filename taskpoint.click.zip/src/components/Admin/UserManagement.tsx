import React, { useEffect, useState } from 'react';
import { 
  Users, 
  Search, 
  Ban, 
  CheckCircle2, 
  Coins, 
  Sparkles, 
  ShieldCheck,
  ShieldAlert,
  UserPlus,
  Trash2,
  AlertTriangle,
  Lock,
  Unlock,
  X,
  User as UserIcon,
  Mail,
  Key,
  Filter,
  Check,
  Info
} from 'lucide-react';
import { api } from '../../lib/api';
import { User, Role } from '../../types';

export const UserManagement: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState<'ALL' | 'ACTIVE' | 'BANNED' | 'RESTRICTED' | 'STAFF'>('ALL');

  // Add Support Modal
  const [showAddSupportModal, setShowAddSupportModal] = useState(false);
  const [supUsername, setSupUsername] = useState('');
  const [supEmail, setSupEmail] = useState('');
  const [supPassword, setSupPassword] = useState('');
  const [creatingSupport, setCreatingSupport] = useState(false);
  const [supError, setSupError] = useState<string | null>(null);

  // Manual Balance Adjustment Modal
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [cashAdj, setCashAdj] = useState('0');
  const [pointsAdj, setPointsAdj] = useState('0');
  const [reason, setReason] = useState('');

  // Action Confirmation Modal (for Ban / Restrict / Delete / Unban)
  const [actionModalUser, setActionModalUser] = useState<User | null>(null);
  const [actionType, setActionType] = useState<'BAN' | 'RESTRICT' | 'ACTIVE' | 'DELETE' | null>(null);
  const [actionReason, setActionReason] = useState('');
  const [actionProcessing, setActionProcessing] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);

  // Toast notification
  const [toast, setToast] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => {
      setToast(null);
    }, 4000);
  };

  const fetchUsers = async () => {
    try {
      const data = await api.adminGetUsers();
      setUsers(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchUsers();
  };

  const handleCreateSupport = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreatingSupport(true);
    setSupError(null);

    try {
      await api.adminCreateSupport({
        username: supUsername.trim(),
        email: supEmail.trim(),
        password: supPassword,
      });
      setShowAddSupportModal(false);
      setSupUsername('');
      setSupEmail('');
      setSupPassword('');
      showToast('Support staff account created successfully!');
      await fetchUsers();
    } catch (err: any) {
      setSupError(err.message || 'Failed to create support account');
    } finally {
      setCreatingSupport(false);
    }
  };

  const openActionModal = (user: User, type: 'BAN' | 'RESTRICT' | 'ACTIVE' | 'DELETE') => {
    setActionModalUser(user);
    setActionType(type);
    setActionReason('');
    setActionError(null);
  };

  const executeAction = async () => {
    if (!actionModalUser || !actionType) return;
    setActionProcessing(true);
    setActionError(null);

    try {
      if (actionType === 'DELETE') {
        const res = await api.adminDeleteUser(actionModalUser.id);
        showToast(res.message || `Account @${actionModalUser.username} permanently deleted.`);
      } else {
        const newStatus = actionType === 'BAN' ? 'BANNED' : actionType === 'RESTRICT' ? 'RESTRICTED' : 'ACTIVE';
        await api.adminUpdateUserStatus(actionModalUser.id, { 
          status: newStatus,
          reason: actionReason.trim() || undefined 
        });
        
        const actionLabel = actionType === 'BAN' ? 'BANNED' : actionType === 'RESTRICT' ? 'RESTRICTED' : 'SET TO ACTIVE';
        showToast(`Account @${actionModalUser.username} ${actionLabel}.`);
      }

      setActionModalUser(null);
      setActionType(null);
      await fetchUsers();
    } catch (err: any) {
      setActionError(err.message || 'Action failed. Please try again.');
    } finally {
      setActionProcessing(false);
    }
  };

  const handleRoleToggle = async (user: User, newRole: Role) => {
    if (!confirm(`Change role of @${user.username} to ${newRole}?`)) return;

    try {
      await api.adminUpdateUserRole(user.id, newRole);
      showToast(`User @${user.username} role updated to ${newRole}.`);
      await fetchUsers();
    } catch (e: any) {
      alert(e.message || 'Failed to update user role');
    }
  };

  const handleAdjustBalance = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedUser) return;

    try {
      await api.adminAdjustUserBalance(selectedUser.id, {
        availableBalance: (selectedUser.availableBalance || 0) + (parseFloat(cashAdj) || 0),
        airdropPoints: (selectedUser.airdropPoints || 0) + (parseInt(pointsAdj) || 0),
      });
      showToast(`Adjusted wallet balance for @${selectedUser.username}.`);
      setSelectedUser(null);
      setCashAdj('0');
      setPointsAdj('0');
      setReason('');
      await fetchUsers();
    } catch (err: any) {
      alert(err.message || 'Failed to adjust balance');
    }
  };

  const filteredUsers = users.filter((u) => {
    const q = search.toLowerCase();
    const matchesSearch = (
      !q ||
      u.username.toLowerCase().includes(q) ||
      u.email.toLowerCase().includes(q) ||
      u.role.toLowerCase().includes(q)
    );

    if (!matchesSearch) return false;

    if (statusFilter === 'ACTIVE') return !u.isBanned && !u.isRestricted;
    if (statusFilter === 'BANNED') return u.isBanned;
    if (statusFilter === 'RESTRICTED') return u.isRestricted;
    if (statusFilter === 'STAFF') return u.role === 'ADMIN' || u.role === 'SUPPORT' || u.role === 'MODERATOR';

    return true;
  });

  const activeCount = users.filter((u) => !u.isBanned && !u.isRestricted).length;
  const bannedCount = users.filter((u) => u.isBanned).length;
  const restrictedCount = users.filter((u) => u.isRestricted).length;
  const staffCount = users.filter((u) => u.role === 'SUPPORT' || u.role === 'ADMIN').length;

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-300 relative">
      
      {/* Toast Banner */}
      {toast && (
        <div className="fixed top-20 right-6 z-50 px-5 py-3 rounded-2xl bg-slate-900 text-white border border-emerald-500/40 shadow-2xl flex items-center gap-3 animate-in slide-in-from-top-2 duration-200">
          <div className="w-6 h-6 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center shrink-0">
            <Check className="w-3.5 h-3.5" />
          </div>
          <span className="text-xs font-bold">{toast}</span>
        </div>
      )}

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">
              User Accounts & Staff Moderation
            </h1>
            <span className="px-2.5 py-0.5 text-[10px] font-black rounded-full bg-indigo-100 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 border border-indigo-200 dark:border-indigo-800">
              ADMIN VAULT
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Full user moderation suite: Ban spam accounts, restrict suspicious activities, delete accounts, and manage balances.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowAddSupportModal(true)}
            className="px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-md shadow-blue-600/20 flex items-center gap-2 transition-all shrink-0"
          >
            <UserPlus className="w-4 h-4" />
            <span>Add Support Account</span>
          </button>
        </div>
      </div>

      {/* Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
          <p className="text-[10px] font-bold text-slate-400 uppercase">Total Accounts</p>
          <h3 className="text-xl font-black text-slate-900 dark:text-white mt-0.5">{users.length}</h3>
          <p className="text-[10px] text-emerald-600 font-semibold mt-1">{activeCount} active users</p>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs border-l-4 border-l-rose-500">
          <p className="text-[10px] font-bold text-rose-500 uppercase">Banned Accounts</p>
          <h3 className="text-xl font-black text-rose-600 dark:text-rose-400 mt-0.5">{bannedCount}</h3>
          <p className="text-[10px] text-slate-400 mt-1">Blocked from login</p>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs border-l-4 border-l-amber-500">
          <p className="text-[10px] font-bold text-amber-500 uppercase">Restricted Accounts</p>
          <h3 className="text-xl font-black text-amber-600 dark:text-amber-400 mt-0.5">{restrictedCount}</h3>
          <p className="text-[10px] text-slate-400 mt-1">Submissions & payouts paused</p>
        </div>

        <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs border-l-4 border-l-indigo-500">
          <p className="text-[10px] font-bold text-indigo-500 uppercase">Staff Accounts</p>
          <h3 className="text-xl font-black text-indigo-600 dark:text-indigo-400 mt-0.5">{staffCount}</h3>
          <p className="text-[10px] text-slate-400 mt-1">Admins & Support Agents</p>
        </div>
      </div>

      {/* Controls, Filter Tabs & Search Bar */}
      <div className="p-4 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          <form onSubmit={handleSearchSubmit} className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search username, email, or role..."
              className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-800 text-xs text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-blue-500"
            />
          </form>

          {/* Filter Pill Buttons */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
            {(['ALL', 'ACTIVE', 'BANNED', 'RESTRICTED', 'STAFF'] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setStatusFilter(tab)}
                className={`px-3 py-1.5 rounded-xl text-[10px] font-black uppercase transition-all whitespace-nowrap ${
                  statusFilter === tab
                    ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900 shadow-xs'
                    : 'bg-slate-100 dark:bg-slate-800/60 text-slate-500 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Users Table */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
        {loading ? (
          <div className="py-12 text-center text-xs text-slate-400 animate-pulse">Loading user accounts...</div>
        ) : filteredUsers.length === 0 ? (
          <div className="py-12 text-center space-y-2">
            <Users className="w-10 h-10 text-slate-300 dark:text-slate-700 mx-auto" />
            <p className="text-xs font-bold text-slate-500">No matching user accounts found for filter</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-100 dark:border-slate-800 text-slate-400 font-bold uppercase text-[10px]">
                  <th className="pb-3">User & Email</th>
                  <th className="pb-3">Country</th>
                  <th className="pb-3">Cash Balance</th>
                  <th className="pb-3">Airdrop XP</th>
                  <th className="pb-3">Role</th>
                  <th className="pb-3">Status</th>
                  <th className="pb-3 text-right">Moderation Controls</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60">
                {filteredUsers.map((u) => (
                  <tr key={u.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                    
                    {/* User info */}
                    <td className="py-3.5 pr-3">
                      <div className="flex items-center gap-2.5">
                        <img
                          src={u.avatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${u.username}`}
                          alt={u.username}
                          className="w-8 h-8 rounded-xl object-cover bg-slate-100 dark:bg-slate-800 shrink-0"
                        />
                        <div>
                          <p className="font-extrabold text-slate-900 dark:text-white flex items-center gap-1.5">
                            <span>@{u.username}</span>
                            {u.role === 'ADMIN' && (
                              <span className="px-1.5 py-0.2 rounded bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-400 text-[9px] font-black">ADMIN</span>
                            )}
                            {u.role === 'SUPPORT' && (
                              <span className="px-1.5 py-0.2 rounded bg-indigo-100 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-400 text-[9px] font-black">SUPPORT</span>
                            )}
                          </p>
                          <p className="text-[10px] text-slate-400 font-mono">{u.email}</p>
                        </div>
                      </div>
                    </td>

                    <td className="py-3.5 text-slate-500 font-medium">{u.country || 'Global'}</td>

                    <td className="py-3.5 font-bold text-emerald-600 font-mono">
                      ${(u.availableBalance || 0).toLocaleString('en-US', { minimumFractionDigits: 2 })}
                    </td>

                    <td className="py-3.5 font-bold text-indigo-600 dark:text-indigo-400">
                      {(u.airdropPoints || 0).toLocaleString()} XP
                    </td>

                    {/* Role selector / badge */}
                    <td className="py-3.5">
                      {u.role === 'ADMIN' ? (
                        <span className="px-2.5 py-1 rounded-lg bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300 text-[10px] font-black uppercase inline-flex items-center gap-1">
                          <ShieldCheck className="w-3 h-3" />
                          <span>Admin</span>
                        </span>
                      ) : (
                        <select
                          value={u.role}
                          onChange={(e) => handleRoleToggle(u, e.target.value as Role)}
                          className="px-2 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-[10px] font-extrabold outline-none border border-slate-200 dark:border-slate-700 cursor-pointer"
                        >
                          <option value="USER">USER</option>
                          <option value="SUPPORT">SUPPORT Staff</option>
                          <option value="MODERATOR">MODERATOR</option>
                        </select>
                      )}
                    </td>

                    {/* Status badge */}
                    <td className="py-3.5">
                      {u.isBanned ? (
                        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300 uppercase inline-flex items-center gap-1">
                          <Ban className="w-3 h-3" />
                          <span>Banned</span>
                        </span>
                      ) : u.isRestricted ? (
                        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300 uppercase inline-flex items-center gap-1">
                          <AlertTriangle className="w-3 h-3" />
                          <span>Restricted</span>
                        </span>
                      ) : (
                        <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 uppercase inline-flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3" />
                          <span>Active</span>
                        </span>
                      )}
                    </td>

                    {/* Actions Column */}
                    <td className="py-3.5 text-right space-x-1.5 whitespace-nowrap">
                      {/* Balance Adj Button */}
                      <button
                        onClick={() => setSelectedUser(u)}
                        className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-100 dark:hover:bg-indigo-950 transition-all"
                        title="Adjust Wallet Cash / XP Balances"
                      >
                        <Coins className="w-4 h-4" />
                      </button>

                      {/* Ban / Unban Button */}
                      {!u.isBanned ? (
                        <button
                          onClick={() => openActionModal(u, 'BAN')}
                          className="px-2.5 py-1 rounded-lg text-[10px] font-black bg-rose-600 hover:bg-rose-500 text-white shadow-xs transition-all inline-flex items-center gap-1"
                          title="Ban user account completely"
                        >
                          <Ban className="w-3 h-3" />
                          <span>Ban</span>
                        </button>
                      ) : (
                        <button
                          onClick={() => openActionModal(u, 'ACTIVE')}
                          className="px-2.5 py-1 rounded-lg text-[10px] font-black bg-emerald-600 hover:bg-emerald-500 text-white shadow-xs transition-all inline-flex items-center gap-1"
                          title="Lift ban & restore active access"
                        >
                          <Unlock className="w-3 h-3" />
                          <span>Unban</span>
                        </button>
                      )}

                      {/* Restrict / Unrestrict Button */}
                      {!u.isRestricted ? (
                        <button
                          onClick={() => openActionModal(u, 'RESTRICT')}
                          className="px-2.5 py-1 rounded-lg text-[10px] font-black bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-xs transition-all inline-flex items-center gap-1"
                          title="Restrict submissions and payouts"
                        >
                          <Lock className="w-3 h-3" />
                          <span>Restrict</span>
                        </button>
                      ) : (
                        <button
                          onClick={() => openActionModal(u, 'ACTIVE')}
                          className="px-2.5 py-1 rounded-lg text-[10px] font-black bg-blue-600 hover:bg-blue-500 text-white shadow-xs transition-all inline-flex items-center gap-1"
                          title="Lift account restriction"
                        >
                          <Unlock className="w-3 h-3" />
                          <span>Unrestrict</span>
                        </button>
                      )}

                      {/* Permanent Delete Account */}
                      {u.id !== 'usr-admin-01' && (
                        <button
                          onClick={() => openActionModal(u, 'DELETE')}
                          className="p-1.5 rounded-lg bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 hover:bg-rose-600 hover:text-white transition-all"
                          title="Permanently Delete Account"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* ACTION CONFIRMATION MODAL (Ban / Restrict / Unban / Delete) */}
      {actionModalUser && actionType && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="relative w-full max-w-md rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-6 sm:p-8 space-y-5">
            <button
              onClick={() => { setActionModalUser(null); setActionType(null); }}
              className="absolute top-5 right-5 p-2 rounded-xl text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Modal Icon & Title */}
            <div className="text-center space-y-2">
              <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mx-auto shadow-lg ${
                actionType === 'DELETE'
                  ? 'bg-rose-600 text-white shadow-rose-600/30'
                  : actionType === 'BAN'
                  ? 'bg-rose-500/10 border border-rose-500/30 text-rose-500'
                  : actionType === 'RESTRICT'
                  ? 'bg-amber-500/10 border border-amber-500/30 text-amber-500'
                  : 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-500'
              }`}>
                {actionType === 'DELETE' && <Trash2 className="w-7 h-7" />}
                {actionType === 'BAN' && <Ban className="w-7 h-7" />}
                {actionType === 'RESTRICT' && <Lock className="w-7 h-7" />}
                {actionType === 'ACTIVE' && <Unlock className="w-7 h-7" />}
              </div>

              <h3 className="font-black text-xl text-slate-900 dark:text-white">
                {actionType === 'DELETE' && `Delete Account @${actionModalUser.username}`}
                {actionType === 'BAN' && `Ban Account @${actionModalUser.username}`}
                {actionType === 'RESTRICT' && `Restrict Account @${actionModalUser.username}`}
                {actionType === 'ACTIVE' && `Reactivate Account @${actionModalUser.username}`}
              </h3>

              <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                User: <span className="font-bold text-slate-900 dark:text-white">{actionModalUser.email}</span> • Balance: <span className="font-bold text-emerald-600">${(actionModalUser.availableBalance || 0).toFixed(2)}</span>
              </p>
            </div>

            {/* Description Warning Card */}
            <div className={`p-4 rounded-2xl border text-xs leading-relaxed space-y-1 ${
              actionType === 'DELETE'
                ? 'bg-rose-950/20 border-rose-500/30 text-rose-300'
                : actionType === 'BAN'
                ? 'bg-rose-950/20 border-rose-500/30 text-rose-300'
                : actionType === 'RESTRICT'
                ? 'bg-amber-950/20 border-amber-500/30 text-amber-300'
                : 'bg-emerald-950/20 border-emerald-500/30 text-emerald-300'
            }`}>
              <p className="font-bold uppercase tracking-wider text-[10px]">
                {actionType === 'DELETE' && '⚠️ Permanent Purge Warning'}
                {actionType === 'BAN' && '⛔ Complete Suspension'}
                {actionType === 'RESTRICT' && '🔒 Feature Restriction'}
                {actionType === 'ACTIVE' && '✅ Full Access Restoration'}
              </p>
              <p>
                {actionType === 'DELETE' && 'This action WILL PERMANENTLY ERASE all user records, submissions, wallet balance, and notifications from the server database.'}
                {actionType === 'BAN' && 'The user will be immediately logged out and blocked from logging back into the TaskPoint system.'}
                {actionType === 'RESTRICT' && 'The user will remain logged in, but will be BLOCKED from submitting new task proofs, withdrawing funds, or claiming bonuses.'}
                {actionType === 'ACTIVE' && 'Removes all restrictions and lifts suspension. The user will regain full platform capabilities immediately.'}
              </p>
            </div>

            {actionError && (
              <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs font-bold">
                {actionError}
              </div>
            )}

            {/* Reason Input Field for Ban/Restrict/Reactivate */}
            {actionType !== 'DELETE' && (
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Reason / Internal Note (Optional)
                </label>
                <input
                  type="text"
                  value={actionReason}
                  onChange={(e) => setActionReason(e.target.value)}
                  placeholder="e.g. Multiple fake proof submissions / Dispute resolution"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => { setActionModalUser(null); setActionType(null); }}
                className="px-4 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-xs font-bold hover:bg-slate-200 dark:hover:bg-slate-700 transition-all"
              >
                Cancel
              </button>

              <button
                type="button"
                onClick={executeAction}
                disabled={actionProcessing}
                className={`px-6 py-2.5 rounded-xl text-white font-black text-xs shadow-lg transition-all flex items-center justify-center gap-2 disabled:opacity-50 ${
                  actionType === 'DELETE'
                    ? 'bg-rose-600 hover:bg-rose-500 shadow-rose-600/30'
                    : actionType === 'BAN'
                    ? 'bg-rose-600 hover:bg-rose-500 shadow-rose-600/30'
                    : actionType === 'RESTRICT'
                    ? 'bg-amber-600 hover:bg-amber-500 text-slate-950 shadow-amber-600/30'
                    : 'bg-emerald-600 hover:bg-emerald-500 shadow-emerald-600/30'
                }`}
              >
                {actionProcessing ? (
                  <span>Processing...</span>
                ) : (
                  <>
                    {actionType === 'DELETE' && <span>Confirm Permanent Delete</span>}
                    {actionType === 'BAN' && <span>Confirm Ban Account</span>}
                    {actionType === 'RESTRICT' && <span>Confirm Restriction</span>}
                    {actionType === 'ACTIVE' && <span>Confirm Reactivation</span>}
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Support Account Modal */}
      {showAddSupportModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="relative w-full max-w-md rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-6 sm:p-8">
            <button
              onClick={() => setShowAddSupportModal(false)}
              className="absolute top-5 right-5 p-2 rounded-xl text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="text-center mb-5">
              <div className="w-12 h-12 rounded-2xl bg-indigo-600 text-white flex items-center justify-center mx-auto mb-2 shadow-lg shadow-indigo-600/30">
                <UserPlus className="w-6 h-6" />
              </div>
              <h3 className="font-black text-xl text-slate-900 dark:text-white">
                Add Support Staff Account
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Create a new support agent login with access to support tickets desk.
              </p>
            </div>

            {supError && (
              <div className="mb-4 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 text-rose-600 text-xs font-semibold">
                {supError}
              </div>
            )}

            <form onSubmit={handleCreateSupport} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Support Username
                </label>
                <div className="relative">
                  <UserIcon className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <input
                    type="text"
                    required
                    value={supUsername}
                    onChange={(e) => setSupUsername(e.target.value)}
                    placeholder="e.g. Support_Sarah"
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Support Email Address
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <input
                    type="email"
                    required
                    value={supEmail}
                    onChange={(e) => setSupEmail(e.target.value)}
                    placeholder="sarah.support@taskpoint.app"
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Password
                </label>
                <div className="relative">
                  <Key className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <input
                    type="password"
                    required
                    value={supPassword}
                    onChange={(e) => setSupPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={creatingSupport}
                className="w-full py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 transition-all disabled:opacity-50 mt-2"
              >
                {creatingSupport ? 'Creating Account...' : 'Create Support Account'}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Manual Balance Adjustment Modal */}
      {selectedUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="relative w-full max-w-md rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-6">
            <button
              onClick={() => setSelectedUser(null)}
              className="absolute top-5 right-5 p-2 rounded-xl text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="font-black text-lg text-slate-900 dark:text-white mb-1">
              Adjust Balance for @{selectedUser.username}
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              Enter positive or negative values (e.g. 500 or -200).
            </p>

            <form onSubmit={handleAdjustBalance} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Cash Delta ($)
                </label>
                <input
                  type="number"
                  value={cashAdj}
                  onChange={(e) => setCashAdj(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Points Delta (XP)
                </label>
                <input
                  type="number"
                  value={pointsAdj}
                  onChange={(e) => setPointsAdj(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Adjustment Reason
                </label>
                <input
                  type="text"
                  required
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  placeholder="e.g. Manual bonus / dispute compensation"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs outline-none"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setSelectedUser(null)}
                  className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-indigo-600 text-white font-bold text-xs shadow-md"
                >
                  Apply Adjustment
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
