import React, { useEffect, useState } from 'react';
import { 
  CheckCircle2, 
  XCircle, 
  Clock, 
  ExternalLink, 
  Eye, 
  User as UserIcon, 
  FileText,
  X,
  MessageSquare
} from 'lucide-react';
import { api } from '../../lib/api';
import { TaskSubmission } from '../../types';

export const SubmissionReview: React.FC = () => {
  const [submissions, setSubmissions] = useState<TaskSubmission[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterStatus, setFilterStatus] = useState<string>('PENDING');

  // Preview & Reject Modal
  const [activeSub, setActiveSub] = useState<TaskSubmission | null>(null);
  const [adminComment, setAdminComment] = useState('');
  const [zoomedImage, setZoomedImage] = useState<string | null>(null);

  const fetchSubmissions = async () => {
    try {
      const data = await api.getAdminSubmissions();
      setSubmissions(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSubmissions();
  }, []);

  const handleReview = async (id: string, status: 'APPROVED' | 'REJECTED', comment?: string) => {
    try {
      await api.reviewSubmission(id, { status, adminComment: comment });
      setActiveSub(null);
      setAdminComment('');
      await fetchSubmissions();
    } catch (err: any) {
      alert(err.message || 'Review action failed');
    }
  };

  const filtered = submissions.filter((s) => (filterStatus === 'ALL' ? true : s.status === filterStatus));

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-300">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">
            Submission Review Queue
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Review proof screenshots, handles, and URLs submitted by users.
          </p>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-1 bg-white dark:bg-slate-900 p-1 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-xs">
          <button
            onClick={() => setFilterStatus('PENDING')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
              filterStatus === 'PENDING' ? 'bg-amber-500 text-white shadow-xs' : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            Pending ({submissions.filter((s) => s.status === 'PENDING').length})
          </button>
          <button
            onClick={() => setFilterStatus('APPROVED')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
              filterStatus === 'APPROVED' ? 'bg-emerald-600 text-white shadow-xs' : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            Approved
          </button>
          <button
            onClick={() => setFilterStatus('REJECTED')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
              filterStatus === 'REJECTED' ? 'bg-rose-600 text-white shadow-xs' : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            Rejected
          </button>
          <button
            onClick={() => setFilterStatus('ALL')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
              filterStatus === 'ALL' ? 'bg-indigo-600 text-white shadow-xs' : 'text-slate-600 dark:text-slate-400'
            }`}
          >
            All
          </button>
        </div>
      </div>

      {/* Submissions List */}
      {loading ? (
        <div className="py-8 text-center text-xs text-slate-400 animate-pulse">Loading submissions...</div>
      ) : filtered.length === 0 ? (
        <div className="py-16 text-center bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800">
          <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto mb-2" />
          <h3 className="font-extrabold text-sm text-slate-800 dark:text-slate-200">No submissions in this filter</h3>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((sub) => (
            <div
              key={sub.id}
              className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between space-y-4"
            >
              <div>
                {/* User & Task Header */}
                <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
                  <div className="flex items-center gap-2">
                    <img
                      src={sub.userAvatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${sub.username}`}
                      alt={sub.username}
                      className="w-8 h-8 rounded-xl object-cover"
                    />
                    <div>
                      <p className="font-extrabold text-xs text-slate-900 dark:text-white">@{sub.username}</p>
                      <p className="text-[10px] text-slate-400">{new Date(sub.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
                    </div>
                  </div>

                  <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${
                    sub.status === 'APPROVED' ? 'bg-emerald-100 text-emerald-700' : sub.status === 'REJECTED' ? 'bg-rose-100 text-rose-700' : 'bg-amber-100 text-amber-700'
                  }`}>
                    {sub.status}
                  </span>
                </div>

                {/* Campaign Title & Rewards */}
                <div className="mt-3">
                  <span className="text-[10px] font-bold uppercase text-indigo-600 dark:text-indigo-400">
                    {sub.taskCategory} Campaign
                  </span>
                  <h3 className="font-bold text-xs text-slate-900 dark:text-white line-clamp-1 mt-0.5">
                    {sub.taskTitle}
                  </h3>
                  <p className="text-xs font-black text-emerald-600 mt-1">
                    Reward: ${sub.rewardCash?.toFixed(2)} + {sub.rewardPoints} PTS
                  </p>
                </div>

                {/* Proof Elements Box */}
                <div className="mt-3 p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 text-xs space-y-2">
                  {sub.proofUsername && (
                    <p className="font-semibold text-slate-700 dark:text-slate-300">
                      Handle: <span className="font-mono text-indigo-600">{sub.proofUsername}</span>
                    </p>
                  )}

                  {sub.proofUrl && (
                    <a
                      href={sub.proofUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-indigo-600 hover:underline flex items-center gap-1 font-bold truncate"
                    >
                      <ExternalLink className="w-3.5 h-3.5 shrink-0" />
                      <span className="truncate">{sub.proofUrl}</span>
                    </a>
                  )}

                  {sub.proofText && (
                    <p className="text-slate-600 dark:text-slate-300 italic">
                      "{sub.proofText}"
                    </p>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2">
                    {sub.proofScreenshot && (
                      <div 
                        onClick={() => setZoomedImage(sub.proofScreenshot || null)}
                        className="relative h-28 rounded-xl overflow-hidden cursor-pointer group border border-slate-200 dark:border-slate-700"
                      >
                        <img src={sub.proofScreenshot} alt="Proof 1" className="w-full h-full object-cover" />
                        <div className="absolute inset-0 bg-slate-950/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white font-bold text-xs gap-1">
                          <Eye className="w-4 h-4" />
                          <span>Screenshot 1</span>
                        </div>
                      </div>
                    )}

                    {sub.proofScreenshot2 && (
                      <div 
                        onClick={() => setZoomedImage(sub.proofScreenshot2 || null)}
                        className="relative h-28 rounded-xl overflow-hidden cursor-pointer group border border-slate-200 dark:border-slate-700"
                      >
                        <img src={sub.proofScreenshot2} alt="Proof 2" className="w-full h-full object-cover" />
                        <div className="absolute inset-0 bg-slate-950/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center text-white font-bold text-xs gap-1">
                          <Eye className="w-4 h-4" />
                          <span>Screenshot 2</span>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              {sub.status === 'PENDING' && (
                <div className="grid grid-cols-2 gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                  <button
                    onClick={() => handleReview(sub.id, 'APPROVED')}
                    className="py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md shadow-emerald-600/25 flex items-center justify-center gap-1 transition-all"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Approve</span>
                  </button>

                  <button
                    onClick={() => setActiveSub(sub)}
                    className="py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-md shadow-rose-600/25 flex items-center justify-center gap-1 transition-all"
                  >
                    <XCircle className="w-4 h-4" />
                    <span>Reject</span>
                  </button>
                </div>
              )}

            </div>
          ))}
        </div>
      )}

      {/* Reject Comment Modal */}
      {activeSub && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="relative w-full max-w-md rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-6">
            <h3 className="font-black text-lg text-slate-900 dark:text-white mb-2">
              Reject Submission Reason
            </h3>
            <p className="text-xs text-slate-500 mb-4">
              User @{activeSub.username} will receive this explanation.
            </p>

            <textarea
              rows={3}
              required
              value={adminComment}
              onChange={(e) => setAdminComment(e.target.value)}
              placeholder="e.g. Follow status not visible in screenshot / invalid username"
              className="w-full p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs outline-none focus:ring-2 focus:ring-rose-500 resize-none mb-4"
            />

            <div className="flex items-center justify-end gap-2">
              <button
                onClick={() => setActiveSub(null)}
                className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold text-xs"
              >
                Cancel
              </button>
              <button
                onClick={() => handleReview(activeSub.id, 'REJECTED', adminComment)}
                className="px-5 py-2 rounded-xl bg-rose-600 text-white font-bold text-xs shadow-md"
              >
                Confirm Rejection
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Image Zoom Lightbox */}
      {zoomedImage && (
        <div 
          onClick={() => setZoomedImage(null)}
          className="fixed inset-0 z-50 bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4 cursor-pointer animate-in fade-in"
        >
          <button className="absolute top-5 right-5 p-2 rounded-full bg-slate-800 text-white">
            <X className="w-6 h-6" />
          </button>
          <img src={zoomedImage} alt="Zoomed Proof" className="max-w-full max-h-[90vh] rounded-2xl shadow-2xl object-contain" />
        </div>
      )}

    </div>
  );
};
