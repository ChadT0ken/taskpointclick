import React, { useEffect, useState } from 'react';
import { 
  Plus, 
  Edit3, 
  Trash2, 
  PauseCircle, 
  PlayCircle, 
  Coins, 
  Sparkles, 
  Search, 
  X, 
  CheckCircle2,
  Image as ImageIcon,
  Upload,
  Link as LinkIcon,
  ExternalLink
} from 'lucide-react';
import { api } from '../../lib/api';
import { Task, TaskCategory } from '../../types';

export const TaskManagement: React.FC = () => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Modal State
  const [showModal, setShowModal] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);

  // Form Fields
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [instructions, setInstructions] = useState('');
  const [taskUrl, setTaskUrl] = useState('');
  const [category, setCategory] = useState<TaskCategory>('TWITTER');
  const [requirementType, setRequirementType] = useState<'SCREENSHOT' | 'TEXT' | 'BOTH'>('SCREENSHOT');
  const [rewardCash, setRewardCash] = useState<string>('0.1');
  const [rewardPoints, setRewardPoints] = useState<string>('1');
  const [totalSlots, setTotalSlots] = useState<string>('No Limit');
  const [difficulty, setDifficulty] = useState<'Easy' | 'Medium' | 'Hard'>('Easy');
  const [estimatedTime, setEstimatedTime] = useState('3 mins');
  const [bannerImage, setBannerImage] = useState('');
  const [requirementsText, setRequirementsText] = useState('Screenshot of Follow, Username');

  const fetchTasks = async () => {
    try {
      const data = await api.getTasks({});
      setTasks(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTasks();
  }, []);

  const handleOpenModal = (task?: Task) => {
    if (task) {
      setEditingTask(task);
      setTitle(task.title);
      setDescription(task.description);
      setInstructions(task.instructions);
      setTaskUrl(task.taskUrl || '');
      setCategory(task.category);
      setRequirementType(task.requirementType || 'SCREENSHOT');
      setRewardCash(task.rewardCash.toString());
      setRewardPoints(task.rewardPoints.toString());
      setTotalSlots(task.totalSlots >= 999999 || task.totalSlots === 0 ? 'No Limit' : task.totalSlots.toString());
      setDifficulty(task.difficulty);
      setEstimatedTime(task.estimatedTime);
      setBannerImage(task.bannerImage || '');
      setRequirementsText(task.requirements?.join(', ') || '');
    } else {
      setEditingTask(null);
      setTitle('');
      setDescription('');
      setInstructions('');
      setTaskUrl('https://x.com');
      setCategory('TWITTER');
      setRequirementType('SCREENSHOT');
      setRewardCash('0.1');
      setRewardPoints('1');
      setTotalSlots('No Limit');
      setDifficulty('Easy');
      setEstimatedTime('3 mins');
      setBannerImage('https://images.unsplash.com/photo-1611605698335-8b1569810432?w=600&auto=format&fit=crop&q=80');
      setRequirementsText('Screenshot of Follow, Username');
    }
    setShowModal(true);
  };

  const handleBannerUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        alert('Banner image must be under 5MB');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setBannerImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSaveTask = async (e: React.FormEvent) => {
    e.preventDefault();

    let parsedSlots = 999999;
    if (totalSlots && totalSlots.trim().toLowerCase() !== 'no limit' && totalSlots.trim().toLowerCase() !== 'unlimited') {
      const num = parseInt(totalSlots, 10);
      if (!isNaN(num) && num > 0) {
        parsedSlots = num;
      }
    }

    const payload = {
      title,
      description,
      instructions,
      taskUrl: taskUrl.trim() || undefined,
      category,
      requirementType,
      rewardCash: parseFloat(rewardCash) || 0.1,
      rewardPoints: parseInt(rewardPoints, 10) || 1,
      totalSlots: parsedSlots,
      difficulty,
      estimatedTime,
      bannerImage: bannerImage || undefined,
      requirements: requirementsText.split(',').map((s) => s.trim()).filter(Boolean),
      status: editingTask ? editingTask.status : 'ACTIVE',
    };

    try {
      if (editingTask) {
        await api.adminUpdateTask(editingTask.id, payload);
      } else {
        await api.adminCreateTask(payload);
      }
      setShowModal(false);
      await fetchTasks();
    } catch (err: any) {
      alert(err.message || 'Failed to save task');
    }
  };

  const handleDeleteTask = async (id: string) => {
    if (!confirm('Are you sure you want to delete this task?')) return;
    try {
      await api.adminDeleteTask(id);
      await fetchTasks();
    } catch (e) {
      console.error(e);
    }
  };

  const handleTogglePause = async (task: Task) => {
    const newStatus = task.status === 'ACTIVE' ? 'PAUSED' : 'ACTIVE';
    try {
      await api.adminUpdateTask(task.id, { status: newStatus });
      await fetchTasks();
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-300">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">
            Task Management & Creation
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Create, edit, pause, and limit available microtask campaign slots.
          </p>
        </div>

        <button
          onClick={() => handleOpenModal()}
          className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-md shadow-indigo-600/30 flex items-center gap-2 transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>Create New Task</span>
        </button>
      </div>

      {/* Task List Table */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
        {loading ? (
          <div className="py-8 text-center text-xs text-slate-400 animate-pulse">Loading tasks...</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-100 dark:border-slate-800 text-slate-400 font-bold uppercase text-[10px]">
                  <th className="pb-3">Task Campaign</th>
                  <th className="pb-3">Category</th>
                  <th className="pb-3">Cash / Points</th>
                  <th className="pb-3">Slots (Filled/Total)</th>
                  <th className="pb-3">Status</th>
                  <th className="pb-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60">
                {tasks.map((task) => (
                  <tr key={task.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                    <td className="py-3 max-w-[220px]">
                      <p className="font-extrabold text-slate-900 dark:text-white truncate">{task.title}</p>
                      <p className="text-[10px] text-slate-400 truncate">{task.description}</p>
                    </td>

                    <td className="py-3">
                      <span className="px-2 py-0.5 rounded bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 font-bold text-[10px] uppercase">
                        {task.category}
                      </span>
                    </td>

                    <td className="py-3 font-bold text-slate-900 dark:text-white">
                      <span className="text-emerald-600">${task.rewardCash.toFixed(2)}</span> + <span className="text-indigo-500">{task.rewardPoints} PTS</span>
                    </td>

                    <td className="py-3 font-bold text-slate-700 dark:text-slate-300">
                      {task.totalSlots >= 999999 || task.totalSlots === 0 ? (
                        <span className="px-2 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-bold text-[10px]">
                          No Limit
                        </span>
                      ) : (
                        `${task.filledSlots} / ${task.totalSlots}`
                      )}
                    </td>

                    <td className="py-3">
                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${
                        task.status === 'ACTIVE' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'
                      }`}>
                        {task.status}
                      </span>
                    </td>

                    <td className="py-3 text-right space-x-1">
                      <button
                        onClick={() => handleTogglePause(task)}
                        className="p-1.5 rounded-lg text-amber-600 hover:bg-amber-50"
                        title={task.status === 'ACTIVE' ? 'Pause Task' : 'Resume Task'}
                      >
                        {task.status === 'ACTIVE' ? <PauseCircle className="w-4 h-4" /> : <PlayCircle className="w-4 h-4" />}
                      </button>
                      <button
                        onClick={() => handleOpenModal(task)}
                        className="p-1.5 rounded-lg text-indigo-600 hover:bg-indigo-50"
                        title="Edit Task"
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => handleDeleteTask(task.id)}
                        className="p-1.5 rounded-lg text-rose-600 hover:bg-rose-50"
                        title="Delete Task"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Task Creation / Edit Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-6 sm:p-8">
            <button
              onClick={() => setShowModal(false)}
              className="absolute top-5 right-5 p-2 rounded-xl text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>

            <h2 className="text-xl font-black text-slate-900 dark:text-white mb-4">
              {editingTask ? 'Edit Task Campaign' : 'Create New Microtask Campaign'}
            </h2>

            <form onSubmit={handleSaveTask} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Task Title</label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Follow TaskPoint Official X & Retweet Pinned Post"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1 flex items-center gap-1.5">
                  <LinkIcon className="w-3.5 h-3.5 text-indigo-500" />
                  <span>Task Destination URL</span>
                </label>
                <input
                  type="url"
                  required
                  value={taskUrl}
                  onChange={(e) => setTaskUrl(e.target.value)}
                  placeholder="https://x.com/target_post or https://t.me/target_group"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Category</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as TaskCategory)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="TWITTER">Twitter / X</option>
                    <option value="TELEGRAM">Telegram</option>
                    <option value="APP_DOWNLOAD">App Download</option>
                    <option value="SURVEY">Survey</option>
                    <option value="CRYPTO">Crypto & Web3</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Requirement Type</label>
                  <select
                    value={requirementType}
                    onChange={(e) => setRequirementType(e.target.value as any)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="SCREENSHOT">Screenshot Only</option>
                    <option value="TEXT">Text / Username Only</option>
                    <option value="BOTH">Both Screenshot & Text</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Difficulty</label>
                  <select
                    value={difficulty}
                    onChange={(e) => setDifficulty(e.target.value as any)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="Easy">Easy</option>
                    <option value="Medium">Medium</option>
                    <option value="Hard">Hard</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Cash Reward ($)</label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    required
                    value={rewardCash}
                    onChange={(e) => setRewardCash(e.target.value)}
                    placeholder="0.1"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Airdrop Points (XP)</label>
                  <input
                    type="number"
                    step="1"
                    min="0"
                    required
                    value={rewardPoints}
                    onChange={(e) => setRewardPoints(e.target.value)}
                    placeholder="1"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Total Slots</label>
                  <input
                    type="text"
                    value={totalSlots}
                    onChange={(e) => setTotalSlots(e.target.value)}
                    placeholder="No Limit"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs outline-none"
                  />
                  <p className="text-[10px] text-slate-400 mt-0.5">Custom number or "No Limit"</p>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Description</label>
                <input
                  type="text"
                  required
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Short description..."
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Step-by-Step Instructions</label>
                <textarea
                  rows={3}
                  required
                  value={instructions}
                  onChange={(e) => setInstructions(e.target.value)}
                  placeholder="1. Open link... 2. Take screenshot..."
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs outline-none resize-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Requirements (comma separated)</label>
                <input
                  type="text"
                  value={requirementsText}
                  onChange={(e) => setRequirementsText(e.target.value)}
                  placeholder="Screenshot, Username"
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs outline-none"
                />
              </div>

              {/* Banner Image Upload */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5 flex items-center justify-between">
                  <span>Task Banner Image Upload</span>
                  {bannerImage && (
                    <button
                      type="button"
                      onClick={() => setBannerImage('')}
                      className="text-[10px] text-rose-500 hover:underline font-bold"
                    >
                      Remove Image
                    </button>
                  )}
                </label>

                {bannerImage ? (
                  <div className="relative rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 h-28 group">
                    <img src={bannerImage} alt="Banner Preview" className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-slate-900/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2 text-white">
                      <label className="px-3 py-1.5 rounded-lg bg-white/20 backdrop-blur-md text-xs font-bold cursor-pointer hover:bg-white/30">
                        Change Image
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleBannerUpload}
                          className="hidden"
                        />
                      </label>
                    </div>
                  </div>
                ) : (
                  <div className="relative border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-indigo-500 rounded-2xl p-4 text-center cursor-pointer transition-colors bg-slate-50 dark:bg-slate-800/40">
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleBannerUpload}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                    />
                    <div className="space-y-1">
                      <Upload className="w-6 h-6 text-slate-400 mx-auto" />
                      <p className="text-xs font-semibold text-slate-600 dark:text-slate-300">
                        Click or drag to <span className="text-indigo-600">upload banner image</span>
                      </p>
                      <p className="text-[10px] text-slate-400">PNG, JPG or WebP (Max 5MB)</p>
                    </div>
                  </div>
                )}

                <div className="mt-2">
                  <input
                    type="text"
                    value={bannerImage}
                    onChange={(e) => setBannerImage(e.target.value)}
                    placeholder="Or paste banner image URL..."
                    className="w-full px-3 py-1.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 text-slate-900 dark:text-white text-[11px] outline-none"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-5 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 font-bold text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-indigo-600 text-white font-bold text-xs shadow-md shadow-indigo-600/30"
                >
                  Save Task
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

    </div>
  );
};
