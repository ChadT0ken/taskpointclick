import React, { useEffect, useState } from 'react';
import { 
  Wallet, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  ExternalLink, 
  ShieldCheck, 
  X,
  FileText
} from 'lucide-react';
import { api } from '../../lib/api';
import { Withdrawal } from '../../types';

export const WithdrawalManagement: React.FC = () => {
  const [withdrawals, setWithdrawals] = useState<Withdrawal[]>([]);
  const [loading, setLoading] = useState(true);

  // Review Modal State
  const [activeReq, setActiveReq] = useState<Withdrawal | null>(null);
  const [paymentRef, setPaymentRef] = useState('');
  const [adminNote, setAdminNote] = useState('');

  const fetchWithdrawals = async () => {
    try {
      const data = await api.adminGetWithdrawals();
      setWithdrawals(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchWithdrawals();
  }, []);

  const handleReview = async (status: 'APPROVED' | 'REJECTED') => {
    if (!activeReq) return;

    try {
      await api.adminReviewWithdrawal(activeReq.id, {
        status,
        paymentRef: paymentRef || undefined,
        adminNotes: adminNote || undefined,
      });
      setActiveReq(null);
      setPaymentRef('');
      setAdminNote('');
      await fetchWithdrawals();
    } catch (err: any) {
      alert(err.message || 'Review action failed');
    }
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-300">
      
      {/* Header */}
      <div>
        <h1 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">
          Payout & Withdrawal Requests
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          Process crypto USDT payout requests (Solana SOL & Tron TRC20 networks) submitted by users.
        </p>
      </div>

      {/* Table */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
        {loading ? (
          <div className="py-8 text-center text-xs text-slate-400 animate-pulse">Loading withdrawal queue...</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-100 dark:border-slate-800 text-slate-400 font-bold uppercase text-[10px]">
                  <th className="pb-3">User</th>
                  <th className="pb-3">Amount</th>
                  <th className="pb-3">Method & Details</th>
                  <th className="pb-3">Date</th>
                  <th className="pb-3">Status</th>
                  <th className="pb-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60">
                {withdrawals.map((w) => (
                  <tr key={w.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                    <td className="py-3 font-extrabold text-slate-900 dark:text-white">
                      @{w.username || 'User'}
                    </td>

                    <td className="py-3 font-black text-emerald-600 font-mono">
                      ${w.amount.toFixed(2)} USD
                    </td>

                    <td className="py-3 text-slate-600 dark:text-slate-300 max-w-xs truncate">
                      <p className="font-bold">{w.method}</p>
                      <p className="text-[10px] text-slate-400 font-mono truncate">{w.details}</p>
                    </td>

                    <td className="py-3 text-slate-500">
                      {new Date(w.createdAt).toLocaleDateString()}
                    </td>

                    <td className="py-3">
                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${
                        w.status === 'APPROVED' ? 'bg-emerald-100 text-emerald-700' : w.status === 'REJECTED' ? 'bg-rose-100 text-rose-700' : 'bg-amber-100 text-amber-700'
                      }`}>
                        {w.status}
                      </span>
                    </td>

                    <td className="py-3 text-right">
                      {w.status === 'PENDING' ? (
                        <button
                          onClick={() => setActiveReq(w)}
                          className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-sm"
                        >
                          Process Payout
                        </button>
                      ) : (
                        <span className="text-[10px] font-mono text-slate-400">
                          Ref: {w.paymentRef || 'N/A'}
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Review Payout Modal */}
      {activeReq && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="relative w-full max-w-md rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-6">
            <button
              onClick={() => setActiveReq(null)}
              className="absolute top-5 right-5 p-2 rounded-xl text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="font-black text-lg text-slate-900 dark:text-white mb-1">
              Process Payout for @{activeReq.username}
            </h3>
            <p className="text-xs text-emerald-600 font-extrabold mb-4 font-mono">
              Amount: ${activeReq.amount.toFixed(2)} USD
            </p>

            <div className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800/50 text-xs mb-4 space-y-1">
              <p className="font-bold text-slate-700 dark:text-slate-300">Method: {activeReq.method}</p>
              <p className="text-slate-500 font-mono break-all">{activeReq.details}</p>
            </div>

            <div className="space-y-3 mb-6">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Payment Reference / TxHash (Required for Approval)
                </label>
                <input
                  type="text"
                  value={paymentRef}
                  onChange={(e) => setPaymentRef(e.target.value)}
                  placeholder="e.g. PAYOUT-TX-998811 or 0x88f2..."
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Admin Note (Optional)
                </label>
                <input
                  type="text"
                  value={adminNote}
                  onChange={(e) => setAdminNote(e.target.value)}
                  placeholder="e.g. Paid via GTBank API"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs outline-none"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => handleReview('REJECTED')}
                className="py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-md"
              >
                Reject & Refund
              </button>
              <button
                onClick={() => handleReview('APPROVED')}
                className="py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-md"
              >
                Approve & Mark Paid
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
