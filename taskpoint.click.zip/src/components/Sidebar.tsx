import React from 'react';
import { 
  LayoutDashboard, 
  CheckSquare, 
  Wallet, 
  Sparkles, 
  Gift, 
  Trophy, 
  HelpCircle, 
  AlertTriangle, 
  User, 
  ShieldAlert, 
  FileText, 
  Users, 
  Settings, 
  Megaphone,
  X
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface SidebarProps {
  activeView: string;
  onNavigate: (view: string) => void;
  isOpenMobile?: boolean;
  onCloseMobile?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({ 
  activeView, 
  onNavigate, 
  isOpenMobile = false, 
  onCloseMobile = () => {} 
}) => {
  const { user } = useAuth();

  const userMenuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'tasks', label: 'Find Tasks', icon: CheckSquare },
    { id: 'wallet', label: 'Wallet & Cash', icon: Wallet },
    { id: 'airdrop', label: 'Airdrop Hub', icon: Sparkles },
    { id: 'referrals', label: 'Referrals', icon: Gift },
    { id: 'leaderboard', label: 'Leaderboard', icon: Trophy },
    { id: 'disputes', label: 'Disputes', icon: AlertTriangle },
    { id: 'support', label: 'Support', icon: HelpCircle },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  const allAdminMenuItems = [
    { id: 'admin-dashboard', label: 'Admin Overview', icon: ShieldAlert },
    { id: 'admin-tasks', label: 'Manage Tasks', icon: FileText },
    { id: 'admin-submissions', label: 'Review Proofs', icon: CheckSquare },
    { id: 'admin-withdrawals', label: 'Manage Payouts', icon: Wallet },
    { id: 'admin-users', label: 'Manage Users', icon: Users },
    { id: 'admin-disputes', label: 'Manage Disputes', icon: AlertTriangle },
    { id: 'admin-support', label: 'Support Tickets', icon: HelpCircle },
    { id: 'admin-announcements', label: 'Announcements', icon: Megaphone },
    { id: 'admin-settings', label: 'System Settings', icon: Settings },
  ];

  const supportAllowedIds = [
    'admin-dashboard',
    'admin-tasks',
    'admin-submissions',
    'admin-users',
    'admin-disputes',
    'admin-support',
  ];

  const adminMenuItems = user?.role === 'SUPPORT'
    ? allAdminMenuItems.filter((item) => supportAllowedIds.includes(item.id))
    : allAdminMenuItems;

  const isAdmin = user && (user.role === 'ADMIN' || user.role === 'MODERATOR' || user.role === 'SUPPORT');

  const content = (
    <div className="h-full flex flex-col justify-between bg-slate-900 text-slate-300 select-none overflow-y-auto">
      <div>
        {/* Brand Header */}
        <div className="p-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => onNavigate('dashboard')}>
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center font-bold text-white shadow-md shadow-blue-600/30 text-base">
              T
            </div>
            <span className="text-xl font-bold text-white tracking-tight">TaskPoint</span>
          </div>
          
          <button
            onClick={onCloseMobile}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 lg:hidden"
            title="Close menu"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* User Navigation Links */}
        <nav className="p-4 space-y-1">
          <div className="px-3 py-1 text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">
            Menu Navigation
          </div>
          {userMenuItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeView === item.id || (item.id === 'settings' && activeView === 'profile');
            return (
              <button
                key={item.id}
                onClick={() => {
                  onNavigate(item.id);
                  onCloseMobile();
                }}
                className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-xs font-semibold transition-colors ${
                  isActive
                    ? 'bg-blue-600/10 text-blue-400 border border-blue-600/20'
                    : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-blue-400' : 'text-slate-400'}`} />
                <span>{item.label}</span>
              </button>
            );
          })}

          {/* Admin Navigation Links */}
          {isAdmin && (
            <div className="mt-6 pt-4 border-t border-slate-800 space-y-1">
              <div className="px-3 py-1 text-[10px] font-bold text-rose-400 uppercase tracking-wider flex items-center justify-between mb-1">
                <span>Admin Portal</span>
                <span className="text-[9px] px-1.5 py-0.2 rounded bg-rose-500/20 text-rose-300 font-bold border border-rose-500/30">
                  {user?.role}
                </span>
              </div>
              {adminMenuItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeView === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      onNavigate(item.id);
                      onCloseMobile();
                    }}
                    className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-lg text-xs font-semibold transition-colors ${
                      isActive
                        ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20'
                        : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                    }`}
                  >
                    <Icon className={`w-4 h-4 shrink-0 ${isActive ? 'text-rose-400' : 'text-slate-400'}`} />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </div>
          )}
        </nav>
      </div>

      {/* Bottom padding */}
      <div className="p-2 mt-auto" />
    </div>
  );

  return (
    <>
      {/* Desktop Sidebar */}
      <aside className="hidden lg:block w-64 shrink-0 h-[calc(100vh-4rem)] sticky top-16 shadow-lg z-30">
        {content}
      </aside>

      {/* Mobile Drawer Backdrop & Container */}
      {isOpenMobile && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div 
            onClick={onCloseMobile}
            className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs transition-opacity animate-in fade-in"
          />
          <div className="fixed inset-y-0 left-0 w-64 bg-slate-900 shadow-2xl z-50 animate-in slide-in-from-left duration-250">
            {content}
          </div>
        </div>
      )}
    </>
  );
};

