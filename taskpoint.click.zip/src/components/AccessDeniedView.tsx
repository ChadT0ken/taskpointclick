import React from 'react';
import { Lock, ShieldAlert, KeyRound, ArrowLeft } from 'lucide-react';

export const AccessDeniedView: React.FC<{ onReturn: () => void }> = ({ onReturn }) => {
  return (
    <div className="min-h-[70vh] flex items-center justify-center p-6">
      <div className="max-w-md w-full p-8 rounded-3xl bg-slate-900 border border-rose-500/30 text-white text-center space-y-5 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8 opacity-5 pointer-events-none">
          <Lock className="w-48 h-48 text-rose-500" />
        </div>

        <div className="w-16 h-16 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-500 flex items-center justify-center mx-auto shadow-lg shadow-rose-500/10">
          <Lock className="w-8 h-8" />
        </div>

        <div className="space-y-2">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-500/10 border border-rose-500/20 text-rose-400 text-[10px] font-black uppercase tracking-wider">
            <ShieldAlert className="w-3 h-3" />
            <span>Encrypted System Portal</span>
          </div>
          <h2 className="text-xl font-black text-white">
            Admin Access Restricted
          </h2>
          <p className="text-xs text-slate-400 leading-relaxed">
            This module requires 256-bit encrypted Administrator privileges. Your account <span className="text-rose-400 font-bold">does not</span> have authorization to access the Admin Panel or Support Control Vault.
          </p>
        </div>

        <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800 text-left font-mono text-[10px] text-slate-400 space-y-1">
          <p><span className="text-rose-400">STATUS:</span> 403 Forbidden</p>
          <p><span className="text-slate-500 font-bold">AUTH_GATE:</span> RSA-SHA256 Encrypted</p>
          <p><span className="text-slate-500 font-bold">IP_LOG:</span> Encrypted Audit Trail Registered</p>
        </div>

        <button
          onClick={onReturn}
          className="w-full py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-extrabold text-xs transition-all flex items-center justify-center gap-2 border border-slate-700"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Return to User Dashboard</span>
        </button>
      </div>
    </div>
  );
};
