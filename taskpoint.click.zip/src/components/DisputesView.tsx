import React, { useEffect, useState } from 'react';
import { 
  AlertTriangle, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  Upload, 
  FileText, 
  Send,
  HelpCircle,
  X
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { api } from '../lib/api';
import { TaskSubmission } from '../types';

export const DisputesView: React.FC = () => {
  const { user } = useAuth();
  const [submissions, setSubmissions] = useState<TaskSubmission[]>([]);
  const [loading, setLoading] = useState(true);

  // Active dispute target
  const [activeSubForDispute, setActiveSubForDispute] = useState<TaskSubmission | null>(null);
  const [reason, setReason] = useState('');
  const [additionalProof, setAdditionalProof] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const loadSubmissions = async () => {
    try {
      const data = await api.getMySubmissions();
      setSubmissions(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadSubmissions();
  }, []);

  if (!user) return null;

  const rejectedSubs = submissions.filter((s) => s.status === 'REJECTED');

  const handleDisputeSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeSubForDispute || !reason.trim()) return;

    setSubmitting(true);
    try {
      await api.submitDispute({
        submissionId: activeSubForDispute.id,
        reason,
        additionalProof: additionalProof || undefined,
      });
      setSuccessMsg('Dispute submitted! Admin will re-examine your proof.');
      setReason('');
      setAdditionalProof('');
      setActiveSubForDispute(null);
      await loadSubmissions();
    } catch (err: any) {
      alert(err.message || 'Failed to open dispute');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-300">
      
      {/* Header */}
      <div>
        <h1 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">
          Submission Dispute Center
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          If your task submission was rejected by mistake, open a dispute to submit updated proof.
        </p>
      </div>

      {successMsg && (
        <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 text-emerald-700 dark:text-emerald-300 text-xs font-bold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-500" />
          <span>{successMsg}</span>
        </div>
      )}

      {/* Rejected Submissions List */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
        <h2 className="font-extrabold text-base text-slate-900 dark:text-white mb-4">
          Rejected Tasks ({rejectedSubs.length})
        </h2>

        {loading ? (
          <div className="p-8 text-center text-xs text-slate-400 animate-pulse">Loading rejected submissions...</div>
        ) : rejectedSubs.length === 0 ? (
          <div className="py-12 text-center">
            <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto mb-2" />
            <h3 className="font-extrabold text-sm text-slate-800 dark:text-slate-200">No Rejected Tasks!</h3>
            <p className="text-xs text-slate-400 mt-1">You have no active rejected submissions that require dispute.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {rejectedSubs.map((sub) => (
              <div
                key={sub.id}
                className="p-4 rounded-2xl bg-rose-50/50 dark:bg-rose-950/20 border border-rose-200 dark:border-rose-900/40 flex flex-col md:flex-row md:items-center justify-between gap-4"
              >
                <div className="space-y-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300 text-[10px] font-black uppercase">
                      REJECTED
                    </span>
                    <h3 className="font-bold text-xs text-slate-900 dark:text-white truncate">
                      {sub.taskTitle || 'Task Submission'}
                    </h3>
                  </div>

                  <p className="text-xs text-rose-800 dark:text-rose-300 font-semibold">
                    Admin Comment: {sub.adminComment || 'Requirements not satisfied'}
                  </p>

                  <p className="text-[11px] text-slate-500">
                    Submitted on {new Date(sub.createdAt).toLocaleDateString()}
                  </p>
                </div>

                <div className="shrink-0">
                  {sub.dispute ? (
                    <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                      sub.dispute.status === 'APPROVED' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'
                    }`}>
                      Dispute Status: {sub.dispute.status}
                    </span>
                  ) : (
                    <button
                      onClick={() => setActiveSubForDispute(sub)}
                      className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-md shadow-rose-600/25 flex items-center gap-2 transition-all"
                    >
                      <AlertTriangle className="w-4 h-4" />
                      <span>Open Formal Dispute</span>
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Dispute Modal Form */}
      {activeSubForDispute && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="relative w-full max-w-lg rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-6 sm:p-8">
            <button
              onClick={() => setActiveSubForDispute(null)}
              className="absolute top-5 right-5 p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>

            <h2 className="text-xl font-black text-slate-900 dark:text-white mb-1">
              Dispute Rejection Decision
            </h2>
            <p className="text-xs text-slate-500 mb-4">
              Task: {activeSubForDispute.taskTitle}
            </p>

            <form onSubmit={handleDisputeSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Reason for Dispute
                </label>
                <textarea
                  rows={3}
                  required
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  placeholder="Explain why your proof was valid..."
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs outline-none focus:ring-2 focus:ring-indigo-500 resize-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Updated Proof Image / URL
                </label>
                <input
                  type="text"
                  value={additionalProof}
                  onChange={(e) => setAdditionalProof(e.target.value)}
                  placeholder="Paste direct screenshot image URL or tweet link..."
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setActiveSubForDispute(null)}
                  className="px-5 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={submitting}
                  className="px-6 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-md shadow-rose-600/30"
                >
                  {submitting ? 'Submitting...' : 'Submit Dispute'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
