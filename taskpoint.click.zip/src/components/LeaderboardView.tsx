import React, { useState, useEffect } from 'react';
import { Trophy, DollarSign, ShieldCheck, Search, Flame, ArrowUpRight, Award, ExternalLink } from 'lucide-react';
import { LeaderboardEntry } from '../types';

export const LeaderboardView: React.FC = () => {
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    fetchLeaderboard();
  }, []);

  const fetchLeaderboard = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/leaderboard?type=EARNERS');
      const data = await res.json();
      setLeaderboard(data);
    } catch (err) {
      console.error('Failed to load cash leaderboard:', err);
    } finally {
      setLoading(false);
    }
  };

  const filteredLeaderboard = leaderboard.filter(entry =>
    entry.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
    (entry.country && entry.country.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Top Banner Header */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-emerald-900/40 via-slate-900 to-slate-900 border border-emerald-500/30 text-white relative overflow-hidden shadow-xl">
        <div className="absolute top-0 right-0 p-8 opacity-10 pointer-events-none">
          <DollarSign className="w-64 h-64 text-emerald-400" />
        </div>

        <div className="relative z-10 max-w-2xl space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-extrabold">
            <Trophy className="w-3.5 h-3.5" />
            <span>Top Cash Earners Leaderboard</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
            Global Cash Earnings & Payout Rankings
          </h1>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
            Real-time verified standings of top TaskPoint earners who have successfully completed tasks and withdrawn cash via Solana (SOL) and TRC20 (USDT).
          </p>
        </div>
      </div>

      {/* Top 3 Podium Cards */}
      {!loading && leaderboard.length >= 3 && (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
          {/* Rank 2 - Silver */}
          <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-center relative flex flex-col justify-between order-2 sm:order-1 shadow-sm">
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-2.5 py-0.5 rounded-full bg-slate-300 dark:bg-slate-700 text-slate-900 dark:text-slate-100 font-extrabold text-[10px] shadow-sm">
              🥈 #2 SILVER
            </div>
            <div className="mt-2 space-y-2">
              <img
                src={leaderboard[1].avatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${leaderboard[1].username}`}
                alt={leaderboard[1].username}
                className="w-14 h-14 rounded-2xl mx-auto object-cover border-2 border-slate-300 dark:border-slate-600 shadow-md"
              />
              <div>
                <h3 className="font-extrabold text-sm text-slate-900 dark:text-white truncate">
                  {leaderboard[1].username}
                </h3>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">{leaderboard[1].country}</p>
              </div>
            </div>
            <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800 space-y-1">
              <span className="text-xs text-slate-400 font-medium block">Total Cash Earned</span>
              <p className="text-base font-black text-emerald-600 dark:text-emerald-400">
                ${(leaderboard[1].cashEarned || leaderboard[1].value || 0).toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </p>
            </div>
          </div>

          {/* Rank 1 - Gold */}
          <div className="p-6 rounded-2xl bg-gradient-to-b from-amber-500/10 via-slate-900/5 to-white dark:to-slate-900 border-2 border-amber-400/80 text-center relative flex flex-col justify-between order-1 sm:order-2 shadow-lg scale-105 z-10">
            <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full bg-amber-400 text-slate-950 font-black text-xs shadow-md flex items-center gap-1">
              <Trophy className="w-3.5 h-3.5 fill-slate-950" />
              <span>🥇 #1 CHAMPION</span>
            </div>
            <div className="mt-2 space-y-2">
              <img
                src={leaderboard[0].avatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${leaderboard[0].username}`}
                alt={leaderboard[0].username}
                className="w-16 h-16 rounded-2xl mx-auto object-cover border-2 border-amber-400 shadow-xl"
              />
              <div>
                <h3 className="font-black text-base text-slate-900 dark:text-white truncate">
                  {leaderboard[0].username}
                </h3>
                <p className="text-xs text-amber-600 dark:text-amber-400 font-bold">{leaderboard[0].country}</p>
              </div>
            </div>
            <div className="mt-3 pt-3 border-t border-amber-200 dark:border-amber-900/60 space-y-1">
              <span className="text-xs text-slate-400 font-medium block">Total Cash Earned</span>
              <p className="text-lg font-black text-emerald-600 dark:text-emerald-400">
                ${(leaderboard[0].cashEarned || leaderboard[0].value || 0).toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </p>
            </div>
          </div>

          {/* Rank 3 - Bronze */}
          <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-center relative flex flex-col justify-between order-3 shadow-sm">
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-2.5 py-0.5 rounded-full bg-amber-800 text-white font-extrabold text-[10px] shadow-sm">
              🥉 #3 BRONZE
            </div>
            <div className="mt-2 space-y-2">
              <img
                src={leaderboard[2].avatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${leaderboard[2].username}`}
                alt={leaderboard[2].username}
                className="w-14 h-14 rounded-2xl mx-auto object-cover border-2 border-amber-800/60 shadow-md"
              />
              <div>
                <h3 className="font-extrabold text-sm text-slate-900 dark:text-white truncate">
                  {leaderboard[2].username}
                </h3>
                <p className="text-[11px] text-slate-500 dark:text-slate-400">{leaderboard[2].country}</p>
              </div>
            </div>
            <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800 space-y-1">
              <span className="text-xs text-slate-400 font-medium block">Total Cash Earned</span>
              <p className="text-base font-black text-emerald-600 dark:text-emerald-400">
                ${(leaderboard[2].cashEarned || leaderboard[2].value || 0).toLocaleString('en-US', { minimumFractionDigits: 2 })}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Main Leaderboard Table Section */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="font-extrabold text-lg text-slate-900 dark:text-white flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-emerald-500" />
              <span>Verified Cash Earners Ranking</span>
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Live payouts updated in real time. Higher earnings unlock priority task access.
            </p>
          </div>

          {/* Search Input */}
          <div className="relative w-full sm:w-64">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search user or country..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-emerald-500"
            />
          </div>
        </div>

        {loading ? (
          <div className="p-12 text-center text-xs text-slate-400 animate-pulse">
            Loading cash earnings rankings...
          </div>
        ) : filteredLeaderboard.length === 0 ? (
          <div className="p-8 text-center text-xs text-slate-400">
            No earners match your search.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-400 font-bold uppercase text-[10px]">
                  <th className="pb-3 pl-2">Rank</th>
                  <th className="pb-3">Participant</th>
                  <th className="pb-3">Country</th>
                  <th className="pb-3 text-right pr-2">Total Cash Earned ($)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60">
                {filteredLeaderboard.map((entry) => (
                  <tr key={entry.userId} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition-colors">
                    <td className="py-3 pl-2 font-black">
                      <span className={`inline-flex items-center justify-center w-6 h-6 rounded-lg text-xs ${
                        entry.rank === 1
                          ? 'bg-amber-400 text-slate-950 font-black'
                          : entry.rank === 2
                          ? 'bg-slate-300 dark:bg-slate-700 text-slate-950 dark:text-white font-black'
                          : entry.rank === 3
                          ? 'bg-amber-800 text-white font-black'
                          : 'text-slate-500'
                      }`}>
                        #{entry.rank}
                      </span>
                    </td>

                    <td className="py-3">
                      <div className="flex items-center gap-2.5">
                        <img
                          src={entry.avatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${entry.username}`}
                          alt={entry.username}
                          className="w-8 h-8 rounded-xl bg-slate-100 dark:bg-slate-800 object-cover"
                        />
                        <div>
                          <span className="font-extrabold text-slate-900 dark:text-white block">
                            {entry.username}
                          </span>
                          <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-medium inline-flex items-center gap-1">
                            <ShieldCheck className="w-3 h-3" /> Verified Earner
                          </span>
                        </div>
                      </div>
                    </td>

                    <td className="py-3 text-slate-500 dark:text-slate-400 font-medium">
                      {entry.country || 'Global'}
                    </td>

                    <td className="py-3 text-right pr-2 font-black text-emerald-600 dark:text-emerald-400 text-sm">
                      ${(entry.cashEarned || entry.value || 0).toLocaleString('en-US', { minimumFractionDigits: 2 })}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
