import React, { useState, useEffect } from 'react';
import { 
  User as UserIcon, 
  Mail, 
  Globe, 
  ShieldCheck, 
  Lock, 
  Key, 
  CheckCircle2, 
  Clock,
  Sparkles,
  Wallet,
  Check,
  AlertCircle,
  ArrowRight,
  Info
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { api } from '../lib/api';

interface ProfileViewProps {
  onNavigate?: (view: string) => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({ onNavigate }) => {
  const { user, refreshUser } = useAuth();
  
  // Wallet Address Settings State
  const [addressNetwork, setAddressNetwork] = useState<'TRC' | 'SOL'>('TRC');
  const [walletAddress, setWalletAddress] = useState('');
  const [savingAddress, setSavingAddress] = useState(false);
  const [addressError, setAddressError] = useState<string | null>(null);
  const [addressSuccess, setAddressSuccess] = useState<string | null>(null);
  const [isEditingAddress, setIsEditingAddress] = useState(false);

  // Password Settings State
  const [currentPass, setCurrentPass] = useState('');
  const [newPass, setNewPass] = useState('');
  const [confirmPass, setConfirmPass] = useState('');
  const [passMsg, setPassMsg] = useState<string | null>(null);
  const [passErr, setPassErr] = useState<string | null>(null);

  useEffect(() => {
    if (user?.savedWalletNetwork) {
      setAddressNetwork(user.savedWalletNetwork);
    }
    if (user?.savedWalletAddress) {
      setWalletAddress(user.savedWalletAddress);
      setIsEditingAddress(false);
    } else {
      setIsEditingAddress(true);
    }
  }, [user]);

  if (!user) return null;

  const handleSaveWalletAddress = async (e: React.FormEvent) => {
    e.preventDefault();
    setAddressError(null);
    setAddressSuccess(null);

    const trimmed = walletAddress.trim();
    if (!trimmed) {
      setAddressError('Please enter a valid wallet address.');
      return;
    }

    // Rule: Must not have "sol" or "trc" inside the address string
    if (/(sol|trc)/i.test(trimmed)) {
      setAddressError('Wallet address must NOT contain network keywords like "sol" or "trc". Please enter the pure blockchain address only.');
      return;
    }

    if (addressNetwork === 'TRC') {
      if (!trimmed.startsWith('T') || trimmed.length < 30 || trimmed.length > 36) {
        setAddressError('Invalid TRC20 address. Tron TRC20 USDT addresses start with "T" (approx. 34 alphanumeric characters).');
        return;
      }
    } else if (addressNetwork === 'SOL') {
      if (trimmed.length < 32 || trimmed.length > 44 || !/^[1-9A-HJ-NP-za-km-z]+$/.test(trimmed)) {
        setAddressError('Invalid Solana (SOL) address. Must be a valid Base58 public key string.');
        return;
      }
    }

    setSavingAddress(true);
    try {
      const res = await api.saveWalletAddress({
        address: trimmed,
        network: addressNetwork,
      });
      setAddressSuccess(res.message || 'USDT payout address saved permanently to your account!');
      setIsEditingAddress(false);
      await refreshUser();
    } catch (err: any) {
      setAddressError(err.message || 'Failed to save payout address.');
    } finally {
      setSavingAddress(false);
    }
  };

  const handleChangePassword = (e: React.FormEvent) => {
    e.preventDefault();
    setPassErr(null);
    setPassMsg(null);

    if (newPass !== confirmPass) {
      setPassErr('New passwords do not match');
      return;
    }

    if (newPass.length < 6) {
      setPassErr('Password must be at least 6 characters long');
      return;
    }

    setPassMsg('Password successfully updated!');
    setCurrentPass('');
    setNewPass('');
    setConfirmPass('');
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-300">
      
      {/* Header */}
      <div>
        <h1 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">
          Account Settings & Payout Preferences
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          Manage your USDT withdrawal address, profile details, and account security.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Profile Card */}
        <div className="lg:col-span-1 p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm text-center">
          <img
            src={user.avatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${user.username}`}
            alt={user.username}
            className="w-24 h-24 rounded-3xl object-cover ring-4 ring-blue-500/20 mx-auto mb-4"
          />

          <h2 className="font-extrabold text-lg text-slate-900 dark:text-white">
            {user.username}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            {user.email}
          </p>

          <div className="mt-4 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 text-xs font-bold">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Active Account ({user.role})</span>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-800 text-left space-y-3 text-xs">
            <div className="flex items-center justify-between">
              <span className="text-slate-500">Country:</span>
              <span className="font-bold text-slate-800 dark:text-slate-200">{user.country}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-500">Referral Code:</span>
              <span className="font-mono font-bold text-blue-600 dark:text-blue-400">{user.referralCode}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-500">Member Since:</span>
              <span className="font-bold text-slate-800 dark:text-slate-200">
                {new Date(user.createdAt).toLocaleDateString()}
              </span>
            </div>
          </div>
        </div>

        {/* Right Section: Withdrawal Address & Password */}
        <div className="lg:col-span-2 space-y-6">

          {/* USDT Withdrawal Address Settings Card */}
          <div id="section-withdrawal-address" className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm relative overflow-hidden">
            
            {/* Header */}
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="p-2.5 rounded-2xl bg-blue-600 text-white shadow-md shadow-blue-600/25">
                  <Wallet className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="font-extrabold text-base text-slate-900 dark:text-white">
                    USDT Payout & Withdrawal Address
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400">
                    Saved permanently to your account and only editable by you.
                  </p>
                </div>
              </div>

              {user.savedWalletAddress && !isEditingAddress && (
                <button
                  id="btn-settings-edit-address"
                  type="button"
                  onClick={() => {
                    setIsEditingAddress(true);
                    setAddressError(null);
                    setAddressSuccess(null);
                  }}
                  className="px-3 py-1.5 rounded-xl bg-blue-50 dark:bg-blue-950/60 text-blue-600 dark:text-blue-400 hover:bg-blue-100 font-bold text-xs transition-colors"
                >
                  Edit Address
                </button>
              )}
            </div>

            {addressError && (
              <div className="mb-4 p-3.5 rounded-2xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800/80 text-rose-600 dark:text-rose-300 text-xs font-semibold">
                {addressError}
              </div>
            )}

            {addressSuccess && (
              <div className="mb-4 p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800/80 text-emerald-600 dark:text-emerald-300 text-xs font-semibold flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{addressSuccess}</span>
              </div>
            )}

            {/* If Saved and Not in Edit Mode */}
            {user.savedWalletAddress && !isEditingAddress ? (
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/70 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-1 rounded-lg bg-blue-600 text-white text-[11px] font-extrabold uppercase tracking-wide">
                      USDT ({user.savedWalletNetwork === 'SOL' ? 'SOL - Solana' : 'TRC20 - Tron'})
                    </span>
                    <span className="text-xs text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" /> Permanent Payout Address
                    </span>
                  </div>
                </div>

                <div className="bg-white dark:bg-slate-900 p-3 rounded-xl border border-slate-200 dark:border-slate-700 font-mono text-xs font-bold text-slate-900 dark:text-white break-all">
                  {user.savedWalletAddress}
                </div>

                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-1 text-[11px] text-slate-500 dark:text-slate-400">
                  <span>Weekly payouts requested on Tuesdays are automatically sent to this address on Wednesday.</span>
                  {onNavigate && (
                    <button
                      type="button"
                      onClick={() => onNavigate('wallet')}
                      className="text-blue-600 dark:text-blue-400 font-bold hover:underline flex items-center gap-1 self-start sm:self-auto shrink-0"
                    >
                      <span>Go to Wallet</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            ) : (
              /* Edit / Add Form */
              <form onSubmit={handleSaveWalletAddress} className="space-y-4">
                {/* Network Selection */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1.5">
                    Select USDT Network
                  </label>
                  <div className="grid grid-cols-2 gap-2 p-1 rounded-2xl bg-slate-100 dark:bg-slate-800 text-xs">
                    <button
                      type="button"
                      onClick={() => setAddressNetwork('TRC')}
                      className={`py-2.5 rounded-xl font-extrabold transition-all flex items-center justify-center gap-1.5 ${
                        addressNetwork === 'TRC'
                          ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-white shadow-sm'
                          : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                      }`}
                    >
                      <span>USDT (TRC20 - Tron)</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setAddressNetwork('SOL')}
                      className={`py-2.5 rounded-xl font-extrabold transition-all flex items-center justify-center gap-1.5 ${
                        addressNetwork === 'SOL'
                          ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-white shadow-sm'
                          : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                      }`}
                    >
                      <span>USDT (SOL - Solana)</span>
                    </button>
                  </div>
                </div>

                {/* Address Input */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    {addressNetwork === 'TRC' ? 'Tron (TRC20) USDT Address' : 'Solana (SOL) USDT Address'}
                  </label>
                  <input
                    type="text"
                    required
                    value={walletAddress}
                    onChange={(e) => setWalletAddress(e.target.value)}
                    placeholder={
                      addressNetwork === 'TRC' 
                        ? 'T... (e.g. TX123... starts with T)' 
                        : 'e.g. 7Xv... (Solana Base58 Address)'
                    }
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 text-slate-900 dark:text-white text-xs font-mono outline-none focus:ring-2 focus:ring-blue-500"
                  />
                  <div className="mt-1.5 text-[11px] text-slate-400 space-y-1">
                    <p className="flex items-center gap-1">
                      <span className="text-rose-500 font-bold">•</span>
                      <span>Do <strong>NOT</strong> include "sol" or "trc" text labels inside the address string.</span>
                    </p>
                    <p>
                      {addressNetwork === 'TRC' 
                        ? '• Standard Tron TRC20 address starts with "T" (approx. 34 characters).' 
                        : '• Standard Solana Base58 public key.'}
                    </p>
                  </div>
                </div>

                {/* Submit & Cancel Buttons */}
                <div className="flex items-center gap-3 pt-1">
                  {user.savedWalletAddress && (
                    <button
                      type="button"
                      onClick={() => {
                        setIsEditingAddress(false);
                        setWalletAddress(user.savedWalletAddress || '');
                        setAddressNetwork(user.savedWalletNetwork || 'TRC');
                        setAddressError(null);
                      }}
                      className="px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 font-bold text-xs hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
                    >
                      Cancel
                    </button>
                  )}
                  <button
                    id="btn-settings-save-wallet"
                    type="submit"
                    disabled={savingAddress}
                    className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-md shadow-blue-600/30 transition-all disabled:opacity-50 flex items-center gap-2"
                  >
                    {savingAddress ? 'Saving Address...' : 'Save Payout Address Permanently'}
                  </button>
                </div>
              </form>
            )}

            <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-400 flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5 text-blue-500 shrink-0" />
              <span>For security, only you can edit your linked withdrawal address.</span>
            </div>
          </div>

          {/* Change Password Form (Optional Security) */}
          <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
            <h2 className="font-extrabold text-base text-slate-900 dark:text-white mb-4 flex items-center gap-2">
              <Key className="w-5 h-5 text-blue-600 dark:text-blue-400" />
              <span>Account Security & Access</span>
            </h2>

            <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
              Your account is authenticated via Google OAuth. You can set an optional fallback password below.
            </p>

            {passErr && (
              <div className="mb-4 p-3 rounded-xl bg-rose-50 text-rose-600 text-xs font-semibold">
                {passErr}
              </div>
            )}

            {passMsg && (
              <div className="mb-4 p-3 rounded-xl bg-emerald-50 text-emerald-600 text-xs font-semibold flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4" />
                <span>{passMsg}</span>
              </div>
            )}

            <form onSubmit={handleChangePassword} className="space-y-4 max-w-md">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  New Security Password
                </label>
                <input
                  type="password"
                  required
                  value={newPass}
                  onChange={(e) => setNewPass(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Confirm Password
                </label>
                <input
                  type="password"
                  required
                  value={confirmPass}
                  onChange={(e) => setConfirmPass(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <button
                type="submit"
                className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-md shadow-blue-600/30 transition-all"
              >
                Update Password
              </button>
            </form>
          </div>

        </div>

      </div>

    </div>
  );
};
