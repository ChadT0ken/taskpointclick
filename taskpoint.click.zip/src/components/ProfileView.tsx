import React, { useState } from 'react';
import { 
  User as UserIcon, 
  Mail, 
  Globe, 
  ShieldCheck, 
  Lock, 
  Key, 
  CheckCircle2, 
  Clock,
  Sparkles
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export const ProfileView: React.FC = () => {
  const { user } = useAuth();
  const [currentPass, setCurrentPass] = useState('');
  const [newPass, setNewPass] = useState('');
  const [confirmPass, setConfirmPass] = useState('');

  const [passMsg, setPassMsg] = useState<string | null>(null);
  const [passErr, setPassErr] = useState<string | null>(null);

  if (!user) return null;

  const handleChangePassword = (e: React.FormEvent) => {
    e.preventDefault();
    setPassErr(null);
    setPassMsg(null);

    if (newPass !== confirmPass) {
      setPassErr('New passwords do not match');
      return;
    }

    if (newPass.length < 6) {
      setPassErr('Password must be at least 6 characters long');
      return;
    }

    setPassMsg('Password successfully updated!');
    setCurrentPass('');
    setNewPass('');
    setConfirmPass('');
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-300">
      
      {/* Header */}
      <div>
        <h1 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">
          Profile & Security Settings
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          Manage your account information, country preferences, and security passwords.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Profile Card */}
        <div className="lg:col-span-1 p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm text-center">
          <img
            src={user.avatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${user.username}`}
            alt={user.username}
            className="w-24 h-24 rounded-3xl object-cover ring-4 ring-indigo-500/20 mx-auto mb-4"
          />

          <h2 className="font-extrabold text-lg text-slate-900 dark:text-white">
            {user.username}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            {user.email}
          </p>

          <div className="mt-4 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 text-xs font-bold">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span>Verified Account ({user.role})</span>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-800 text-left space-y-3 text-xs">
            <div className="flex items-center justify-between">
              <span className="text-slate-500">Country:</span>
              <span className="font-bold text-slate-800 dark:text-slate-200">{user.country}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-500">Referral Code:</span>
              <span className="font-mono font-bold text-indigo-600">{user.referralCode}</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-slate-500">Member Since:</span>
              <span className="font-bold text-slate-800 dark:text-slate-200">
                {new Date(user.createdAt).toLocaleDateString()}
              </span>
            </div>
          </div>
        </div>

        {/* Change Password Form */}
        <div className="lg:col-span-2 p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
          <h2 className="font-extrabold text-base text-slate-900 dark:text-white mb-4 flex items-center gap-2">
            <Key className="w-5 h-5 text-indigo-600" />
            <span>Change Security Password</span>
          </h2>

          {passErr && (
            <div className="mb-4 p-3 rounded-xl bg-rose-50 text-rose-600 text-xs font-semibold">
              {passErr}
            </div>
          )}

          {passMsg && (
            <div className="mb-4 p-3 rounded-xl bg-emerald-50 text-emerald-600 text-xs font-semibold flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4" />
              <span>{passMsg}</span>
            </div>
          )}

          <form onSubmit={handleChangePassword} className="space-y-4 max-w-md">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Current Password
              </label>
              <input
                type="password"
                required
                value={currentPass}
                onChange={(e) => setCurrentPass(e.target.value)}
                placeholder="••••••••"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                New Password
              </label>
              <input
                type="password"
                required
                value={newPass}
                onChange={(e) => setNewPass(e.target.value)}
                placeholder="••••••••"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                Confirm New Password
              </label>
              <input
                type="password"
                required
                value={confirmPass}
                onChange={(e) => setConfirmPass(e.target.value)}
                placeholder="••••••••"
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>

            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-md shadow-indigo-600/30 transition-all"
            >
              Update Password
            </button>
          </form>
        </div>

      </div>

    </div>
  );
};
