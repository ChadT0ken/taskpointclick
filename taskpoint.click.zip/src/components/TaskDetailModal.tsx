import React, { useState } from 'react';
import { 
  X, 
  Coins, 
  Sparkles, 
  Clock, 
  CheckCircle2, 
  Upload, 
  ExternalLink, 
  AlertCircle, 
  FileText,
  User,
  ShieldCheck,
  Image as ImageIcon
} from 'lucide-react';
import { Task } from '../types';
import { api } from '../lib/api';

interface TaskDetailModalProps {
  task: Task;
  onClose: () => void;
  onSubmitted: () => void;
}

export const TaskDetailModal: React.FC<TaskDetailModalProps> = ({ task, onClose, onSubmitted }) => {
  const [proofText, setProofText] = useState('');
  const [proofUsername, setProofUsername] = useState('');
  const [proofUrl, setProofUrl] = useState('');
  const [proofScreenshot, setProofScreenshot] = useState<string | null>(null);
  const [proofScreenshot2, setProofScreenshot2] = useState<string | null>(null);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const requiresTwoScreenshots = task.category === 'APP_DOWNLOAD' || task.category === 'CRYPTO' || task.category === 'SURVEY';

  // Handle image upload 1
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        setError('Image file size must be less than 5MB');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setProofScreenshot(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Handle image upload 2
  const handleImageUpload2 = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        setError('Image file size must be less than 5MB');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setProofScreenshot2(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmitProof = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    // Check screenshot requirements based on category and requirement type
    if (requiresTwoScreenshots) {
      if (!proofScreenshot || !proofScreenshot2) {
        setError(`Tasks in ${task.category.replace('_', ' ')} category require 2 screenshot proofs. Please upload both screenshots.`);
        return;
      }
    } else if (task.requirementType === 'SCREENSHOT' || task.requirementType === 'BOTH' || !task.requirementType) {
      if (!proofScreenshot) {
        setError('Please upload a screenshot proof.');
        return;
      }
    }

    if (task.requirementType === 'TEXT' && !proofText) {
      setError('Please provide text proof in the notes field.');
      return;
    }

    setLoading(true);
    try {
      await api.submitTaskProof({
        taskId: task.id,
        proofScreenshot: proofScreenshot || undefined,
        proofScreenshot2: proofScreenshot2 || undefined,
        proofText: proofText || undefined,
        proofUrl: proofUrl || undefined,
        proofUsername: proofUsername || undefined,
      });
      setSuccess(true);
      setTimeout(() => {
        onSubmitted();
        onClose();
      }, 1500);
    } catch (err: any) {
      setError(err.message || 'Failed to submit proof');
    } finally {
      setLoading(false);
    }
  };

  const isNoLimitSlots = !task.totalSlots || task.totalSlots >= 999999;
  const slotsPercent = isNoLimitSlots ? 100 : Math.min(100, Math.round((task.filledSlots / task.totalSlots) * 100));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-6 sm:p-8">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors z-10"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Task Banner Image */}
        {task.bannerImage && (
          <div className="relative w-full h-44 rounded-2xl overflow-hidden mb-6">
            <img src={task.bannerImage} alt={task.title} className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent"></div>
            <div className="absolute bottom-3 left-4 right-4 flex items-center justify-between text-white">
              <span className="px-3 py-1 rounded-full text-xs font-bold uppercase bg-indigo-600/90 backdrop-blur-md">
                {task.category}
              </span>
              <span className="text-xs font-semibold text-slate-200">
                Est. Time: {task.estimatedTime}
              </span>
            </div>
          </div>
        )}

        {/* Title & Rewards Header */}
        <div className="mb-6">
          <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white leading-tight">
            {task.title}
          </h2>

          {/* Task Action Button (Go to Task URL) */}
          {task.taskUrl && (
            <div className="mt-4">
              <a
                href={task.taskUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full inline-flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-2xl bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-black text-sm shadow-xl shadow-indigo-600/30 transition-all hover:scale-[1.01] active:scale-[0.99]"
              >
                <ExternalLink className="w-4 h-4" />
                <span>Go to Task URL</span>
              </a>
            </div>
          )}

          {/* Reward Badges */}
          <div className="mt-4 flex flex-wrap items-center gap-2">
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 font-extrabold text-xs">
              <Coins className="w-4 h-4 text-emerald-600" />
              <span>${task.rewardCash.toFixed(2)} Cash Reward</span>
            </div>
            <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-indigo-100 dark:bg-indigo-950/80 text-indigo-700 dark:text-indigo-300 font-extrabold text-xs">
              <Sparkles className="w-4 h-4 text-indigo-600" />
              <span>+{task.rewardPoints || 10} Airdrop XP</span>
            </div>
            <div className="px-3 py-1.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 font-semibold text-xs">
              Difficulty: {task.difficulty}
            </div>
          </div>
        </div>

        {/* Slots Progress Bar */}
        <div className="mb-6 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800">
          <div className="flex items-center justify-between text-xs font-bold mb-1.5">
            <span className="text-slate-700 dark:text-slate-300">Slots Completion</span>
            <span className="text-indigo-600 dark:text-indigo-400">
              {isNoLimitSlots ? 'Unlimited Slots' : `${task.filledSlots} / ${task.totalSlots} Slots`}
            </span>
          </div>
          <div className="w-full h-2 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-indigo-500 to-purple-600 rounded-full transition-all duration-500"
              style={{ width: `${slotsPercent}%` }}
            ></div>
          </div>
        </div>

        {/* Task Instructions */}
        <div className="mb-6 space-y-3">
          <h3 className="font-extrabold text-sm text-slate-900 dark:text-white flex items-center gap-2">
            <FileText className="w-4 h-4 text-indigo-500" />
            <span>Task Instructions & Steps</span>
          </h3>
          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/30 border border-slate-200 dark:border-slate-800/80 text-xs text-slate-700 dark:text-slate-300 whitespace-pre-line leading-relaxed">
            {task.instructions}
          </div>
        </div>

        {/* Requirements List */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <h3 className="font-extrabold text-sm text-slate-900 dark:text-white">
              Proof Requirements Needed
            </h3>
            <span className="px-2.5 py-0.5 rounded-lg bg-amber-100 dark:bg-amber-950/50 text-amber-800 dark:text-amber-300 text-[10px] font-extrabold">
              {requiresTwoScreenshots 
                ? 'Requires 2 Screenshots' 
                : task.requirementType === 'TEXT' 
                ? 'Requires Text / Handle' 
                : task.requirementType === 'BOTH' 
                ? 'Requires Screenshot & Text' 
                : 'Requires 1 Screenshot'}
            </span>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {task.requirements.map((req, idx) => (
              <div key={idx} className="p-2.5 rounded-xl bg-indigo-50/50 dark:bg-indigo-950/20 border border-indigo-100 dark:border-indigo-900/30 text-xs text-indigo-900 dark:text-indigo-200 font-semibold flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-indigo-600 shrink-0" />
                <span>{req}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Submission Form Section */}
        <div className="pt-6 border-t border-slate-200 dark:border-slate-800">
          <h3 className="font-extrabold text-base text-slate-900 dark:text-white mb-3">
            Submit Proof of Work
          </h3>

          {error && (
            <div className="mb-4 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 text-rose-600 text-xs font-semibold">
              {error}
            </div>
          )}

          {success ? (
            <div className="p-6 rounded-2xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 text-center animate-in zoom-in-95">
              <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto mb-2" />
              <h4 className="font-bold text-base text-emerald-800 dark:text-emerald-200">
                Proof Submitted Successfully!
              </h4>
              <p className="text-xs text-emerald-600 dark:text-emerald-400 mt-1">
                Your submission is under admin review. Earnings move to available balance upon approval.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmitProof} className="space-y-4">
              
              {/* Proof Screenshot Upload Section */}
              <div className="space-y-3">
                {/* Screenshot 1 */}
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    {requiresTwoScreenshots ? 'Upload Screenshot #1 (Required)' : 'Upload Screenshot Proof (Max 5MB)'}
                  </label>
                  <div className="relative border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-indigo-500 rounded-2xl p-4 text-center cursor-pointer transition-colors bg-slate-50 dark:bg-slate-800/40">
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                    />
                    {proofScreenshot ? (
                      <div className="flex items-center justify-center gap-3">
                        <img src={proofScreenshot} alt="Proof 1" className="w-16 h-16 object-cover rounded-xl border border-indigo-500" />
                        <div className="text-left">
                          <p className="text-xs font-bold text-emerald-600">Screenshot #1 Attached ✓</p>
                          <p className="text-[10px] text-slate-400">Click to replace image</p>
                        </div>
                      </div>
                    ) : (
                      <div className="space-y-1">
                        <Upload className="w-6 h-6 text-slate-400 mx-auto" />
                        <p className="text-xs font-semibold text-slate-600 dark:text-slate-300">
                          {requiresTwoScreenshots ? 'Upload 1st Screenshot' : 'Drag and drop screenshot or'} <span className="text-indigo-600">click to browse</span>
                        </p>
                      </div>
                    )}
                  </div>
                </div>

                {/* Screenshot 2 for App Download, Crypto, Survey */}
                {requiresTwoScreenshots && (
                  <div>
                    <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                      Upload Screenshot #2 (Required for {task.category.replace('_', ' ')})
                    </label>
                    <div className="relative border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-indigo-500 rounded-2xl p-4 text-center cursor-pointer transition-colors bg-slate-50 dark:bg-slate-800/40">
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleImageUpload2}
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                      />
                      {proofScreenshot2 ? (
                        <div className="flex items-center justify-center gap-3">
                          <img src={proofScreenshot2} alt="Proof 2" className="w-16 h-16 object-cover rounded-xl border border-indigo-500" />
                          <div className="text-left">
                            <p className="text-xs font-bold text-emerald-600">Screenshot #2 Attached ✓</p>
                            <p className="text-[10px] text-slate-400">Click to replace image</p>
                          </div>
                        </div>
                      ) : (
                        <div className="space-y-1">
                          <Upload className="w-6 h-6 text-slate-400 mx-auto" />
                          <p className="text-xs font-semibold text-slate-600 dark:text-slate-300">
                            Upload 2nd Screenshot <span className="text-indigo-600">(click to browse)</span>
                          </p>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>

              {/* Text Proof Notes */}
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Additional Notes / Text Proof
                </label>
                <textarea
                  rows={2}
                  value={proofText}
                  onChange={(e) => setProofText(e.target.value)}
                  placeholder="Provide any extra details or text responses requested..."
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs outline-none focus:ring-2 focus:ring-indigo-500 resize-none"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-5 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-bold text-xs transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg shadow-indigo-600/30 transition-all disabled:opacity-50"
                >
                  {loading ? 'Submitting...' : 'Complete & Submit Task'}
                </button>
              </div>

            </form>
          )}
        </div>

      </div>
    </div>
  );
};
