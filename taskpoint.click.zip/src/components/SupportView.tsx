import React, { useEffect, useState } from 'react';
import { 
  HelpCircle, 
  MessageSquare, 
  Plus, 
  Send, 
  Clock, 
  CheckCircle2, 
  XCircle, 
  User, 
  ShieldCheck,
  X,
  Search,
  ChevronDown,
  ChevronUp,
  BookOpen,
  Sparkles,
  Coins,
  AlertTriangle,
  Trash2,
  Lock
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { api } from '../lib/api';
import { SupportTicket } from '../types';

interface FAQItem {
  id: string;
  category: 'ALL' | 'PAYOUTS' | 'TASKS' | 'AIRDROP' | 'ACCOUNT';
  categoryLabel: string;
  question: string;
  answer: string;
}

const FAQ_DATA: FAQItem[] = [
  {
    id: '1',
    category: 'TASKS',
    categoryLabel: 'Microtasks',
    question: 'How do I complete microtasks and earn USD rewards?',
    answer: 'Navigate to the "Tasks" section, select any active microtask (such as app downloads, social follows, or surveys), and follow the step-by-step instructions. Submit the required screenshot or profile link proof. Once verified by an admin, your USD balance and $TASK Airdrop XP are credited instantly.'
  },
  {
    id: '3',
    category: 'PAYOUTS',
    categoryLabel: 'USDT Payouts',
    question: 'What is the minimum withdrawal amount and supported networks?',
    answer: 'The minimum withdrawal threshold is $5.00 USD. We support USDT payouts via Tron (TRC20, addresses beginning with "T") and Solana (SOL). Always verify your receiving address in your Wallet profile before requesting a payout.'
  },
  {
    id: '4',
    category: 'AIRDROP',
    categoryLabel: 'Airdrop XP',
    question: 'How is Total Airdrop XP calculated and how does it affect my leaderboard rank?',
    answer: 'Your Total Airdrop XP is the sum of both your Earned Task XP and Referral XP, plus Daily Check-in Streak rewards (+10 XP/day). Your combined Total Airdrop XP determines your standing on the public Leaderboard for the upcoming $TASK token generation distribution.'
  },
  {
    id: '5',
    category: 'ACCOUNT',
    categoryLabel: 'Referral Code',
    question: 'How does the Referral Code Program work?',
    answer: 'Share your unique referral code found in the "Referrals" section. When friends enter your code during registration, you receive +20 Airdrop XP per verified friend. Note: Referral rewards are rewarded as Airdrop XP to boost your leaderboard ranking and token allocation.'
  },
  {
    id: '6',
    category: 'ACCOUNT',
    categoryLabel: 'Support Policy',
    question: 'How long are support tickets kept before being deleted?',
    answer: 'Active support tickets remain available while under review. Once a ticket is marked as Closed (by you or support staff), it will be automatically and permanently deleted from the database after 72 hours.'
  },
  {
    id: '7',
    category: 'TASKS',
    categoryLabel: 'Disputes',
    question: 'What happens if my task proof submission is rejected?',
    answer: 'If your submission is rejected, you can review the admin feedback in your Task history. If you believe there was an error, navigate to the "Disputes" tab in the sidebar, choose the submission, and upload supplementary proof for re-evaluation.'
  },
  {
    id: '8',
    category: 'ACCOUNT',
    categoryLabel: 'Daily Streaks',
    question: 'How does the Daily Login Streak work?',
    answer: 'Log in daily and claim your +10 Airdrop XP check-in reward from the dashboard or Airdrop Hub. Maintaining consecutive daily streaks multiplies your overall airdrop standing.'
  }
];

export const SupportView: React.FC = () => {
  const { user } = useAuth();
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTicket, setActiveTicket] = useState<SupportTicket | null>(null);

  // Tab & FAQ states
  const [activeTab, setActiveTab] = useState<'FAQ' | 'TICKETS'>('FAQ');
  const [faqCategory, setFaqCategory] = useState<'ALL' | 'PAYOUTS' | 'TASKS' | 'AIRDROP' | 'ACCOUNT'>('ALL');
  const [faqSearch, setFaqSearch] = useState('');
  const [expandedFaqId, setExpandedFaqId] = useState<string | null>('1');

  // New ticket modal
  const [showNewModal, setShowNewModal] = useState(false);
  const [subject, setSubject] = useState('');
  const [category, setCategory] = useState('General');
  const [priority, setPriority] = useState('MEDIUM');
  const [message, setMessage] = useState('');

  // Reply message
  const [replyText, setReplyText] = useState('');
  const [submittingReply, setSubmittingReply] = useState(false);
  const [updatingStatus, setUpdatingStatus] = useState(false);

  const fetchTickets = async () => {
    try {
      const data = await api.getTickets();
      setTickets(data);
      if (data.length > 0) {
        if (!activeTicket) {
          setActiveTicket(data[0]);
        } else {
          const updated = data.find(t => t.id === activeTicket.id);
          if (updated) setActiveTicket(updated);
          else setActiveTicket(data[0]);
        }
      } else {
        setActiveTicket(null);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTickets();
  }, []);

  if (!user) return null;

  const handleCreateTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const newTkt = await api.createTicket({ subject, category, priority, message });
      setShowNewModal(false);
      setSubject('');
      setMessage('');
      await fetchTickets();
      setActiveTicket(newTkt);
      setActiveTab('TICKETS');
    } catch (err: any) {
      alert(err.message || 'Failed to open ticket');
    }
  };

  const handleSendReply = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeTicket || !replyText.trim()) return;
    setSubmittingReply(true);
    try {
      const updated = await api.replyTicket(activeTicket.id, replyText);
      setReplyText('');
      setActiveTicket(updated);
      await fetchTickets();
    } catch (err: any) {
      alert(err.message || 'Failed to send reply');
    } finally {
      setSubmittingReply(false);
    }
  };

  const handleToggleCloseTicket = async () => {
    if (!activeTicket) return;
    const isCurrentlyClosed = activeTicket.status === 'CLOSED';
    const newStatus = isCurrentlyClosed ? 'OPEN' : 'CLOSED';
    
    if (!isCurrentlyClosed) {
      const confirmed = window.confirm(
        'Are you sure you want to close this ticket? Once closed, it will be automatically deleted after 72 hours.'
      );
      if (!confirmed) return;
    }

    setUpdatingStatus(true);
    try {
      const updated = await api.updateTicketStatus(activeTicket.id, newStatus);
      setActiveTicket(updated);
      await fetchTickets();
    } catch (err: any) {
      alert(err.message || 'Failed to update ticket status');
    } finally {
      setUpdatingStatus(false);
    }
  };

  const handleDeleteTicketNow = async () => {
    if (!activeTicket) return;
    const confirmed = window.confirm('Permanently delete this closed ticket now?');
    if (!confirmed) return;

    try {
      await api.deleteTicket(activeTicket.id);
      setActiveTicket(null);
      await fetchTickets();
    } catch (err: any) {
      alert(err.message || 'Failed to delete ticket');
    }
  };

  const getHoursUntilAutoDelete = (ticket: SupportTicket) => {
    if (ticket.status !== 'CLOSED') return null;
    const closedTime = ticket.closedAt 
      ? new Date(ticket.closedAt).getTime() 
      : new Date(ticket.updatedAt).getTime();
    const expiryTime = closedTime + (72 * 60 * 60 * 1000);
    const msRemaining = Math.max(0, expiryTime - Date.now());
    const hoursRemaining = Math.ceil(msRemaining / (1000 * 60 * 60));
    return hoursRemaining;
  };

  const filteredFaqs = FAQ_DATA.filter((item) => {
    const matchesCat = faqCategory === 'ALL' || item.category === faqCategory;
    const matchesQuery = 
      item.question.toLowerCase().includes(faqSearch.toLowerCase()) ||
      item.answer.toLowerCase().includes(faqSearch.toLowerCase());
    return matchesCat && matchesQuery;
  });

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-300">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">
            Support Center & FAQ
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Find instant answers to common questions or submit a 24/7 support ticket. Closed tickets are auto-deleted after 72 hours.
          </p>
        </div>

        <button
          onClick={() => setShowNewModal(true)}
          className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-md shadow-indigo-600/30 flex items-center gap-2 transition-all self-start sm:self-auto cursor-pointer active:scale-95"
        >
          <Plus className="w-4 h-4" />
          <span>Open Support Ticket</span>
        </button>
      </div>

      {/* Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-3">
        <button
          onClick={() => setActiveTab('FAQ')}
          className={`px-4 py-2 rounded-xl font-extrabold text-xs flex items-center gap-2 transition-all cursor-pointer ${
            activeTab === 'FAQ'
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
              : 'bg-slate-100 dark:bg-slate-800/80 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800'
          }`}
        >
          <BookOpen className="w-4 h-4" />
          <span>Frequently Asked Questions (FAQ)</span>
        </button>

        <button
          onClick={() => setActiveTab('TICKETS')}
          className={`px-4 py-2 rounded-xl font-extrabold text-xs flex items-center gap-2 transition-all cursor-pointer ${
            activeTab === 'TICKETS'
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-600/30'
              : 'bg-slate-100 dark:bg-slate-800/80 text-slate-600 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800'
          }`}
        >
          <MessageSquare className="w-4 h-4" />
          <span>My Support Tickets</span>
          <span className="px-1.5 py-0.5 rounded-full bg-slate-200 dark:bg-slate-700 text-[10px] font-bold">
            {tickets.length}
          </span>
        </button>
      </div>

      {/* TAB 1: FAQ SECTION */}
      {activeTab === 'FAQ' && (
        <div className="space-y-6">
          
          {/* Search & Category Filter Controls */}
          <div className="p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
              <input
                type="text"
                value={faqSearch}
                onChange={(e) => setFaqSearch(e.target.value)}
                placeholder="Search FAQ by keyword (e.g., USDT, withdrawal, task proof, airdrop, 72hr)..."
                className="w-full pl-10 pr-4 py-2.5 rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs outline-none focus:ring-2 focus:ring-indigo-500 transition-all"
              />
            </div>

            {/* Category Filter Chips */}
            <div className="flex flex-wrap items-center gap-2">
              {[
                { key: 'ALL', label: 'All Topics' },
                { key: 'PAYOUTS', label: 'USDT Payouts' },
                { key: 'TASKS', label: 'Microtasks' },
                { key: 'AIRDROP', label: 'Airdrop XP' },
                { key: 'ACCOUNT', label: 'Account & Support' },
              ].map((cat) => (
                <button
                  key={cat.key}
                  onClick={() => setFaqCategory(cat.key as any)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    faqCategory === cat.key
                      ? 'bg-indigo-100 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 border border-indigo-300 dark:border-indigo-800'
                      : 'bg-slate-100 dark:bg-slate-800/50 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-800'
                  }`}
                >
                  {cat.label}
                </button>
              ))}
            </div>
          </div>

          {/* Accordion FAQ List */}
          <div className="space-y-3">
            {filteredFaqs.length === 0 ? (
              <div className="p-8 text-center rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                <HelpCircle className="w-10 h-10 text-slate-300 dark:text-slate-700 mx-auto mb-2" />
                <h3 className="font-bold text-slate-700 dark:text-slate-300 text-sm">No matching questions found</h3>
                <p className="text-xs text-slate-400 mt-1">Try searching with a different keyword or open a direct ticket.</p>
              </div>
            ) : (
              filteredFaqs.map((faq) => {
                const isExpanded = expandedFaqId === faq.id;
                return (
                  <div
                    key={faq.id}
                    className={`rounded-2xl border transition-all overflow-hidden ${
                      isExpanded
                        ? 'bg-white dark:bg-slate-900 border-indigo-500/50 shadow-md ring-1 ring-indigo-500/20'
                        : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                    }`}
                  >
                    <button
                      onClick={() => setExpandedFaqId(isExpanded ? null : faq.id)}
                      className="w-full p-4 sm:p-5 text-left flex items-center justify-between gap-4 cursor-pointer"
                    >
                      <div className="flex items-center gap-3">
                        <span className="px-2.5 py-1 rounded-lg bg-indigo-50 dark:bg-indigo-950/80 text-indigo-600 dark:text-indigo-400 text-[10px] font-extrabold shrink-0">
                          {faq.categoryLabel}
                        </span>
                        <h3 className="font-extrabold text-xs sm:text-sm text-slate-900 dark:text-white">
                          {faq.question}
                        </h3>
                      </div>
                      <div className="p-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-500 shrink-0">
                        {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                      </div>
                    </button>

                    {isExpanded && (
                      <div className="px-4 sm:px-5 pb-5 pt-1 text-xs text-slate-600 dark:text-slate-300 border-t border-slate-100 dark:border-slate-800/80 leading-relaxed font-medium bg-slate-50/50 dark:bg-slate-900/50">
                        {faq.answer}
                      </div>
                    )}
                  </div>
                );
              })
            )}
          </div>

          {/* Need More Help Banner */}
          <div className="p-6 rounded-3xl bg-gradient-to-r from-indigo-900/40 via-purple-900/30 to-slate-900 border border-indigo-800/50 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="space-y-1 text-center sm:text-left">
              <h3 className="font-black text-sm text-white flex items-center justify-center sm:justify-start gap-2">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <span>Still have questions or need custom assistance?</span>
              </h3>
              <p className="text-xs text-slate-300">
                Our support desk responds promptly 24/7 to help resolve any task, payment, or account issue.
              </p>
            </div>
            <button
              onClick={() => setShowNewModal(true)}
              className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-md shadow-indigo-600/30 shrink-0 transition-all cursor-pointer"
            >
              Submit Ticket Now
            </button>
          </div>

        </div>
      )}

      {/* TAB 2: SUPPORT TICKETS SECTION */}
      {activeTab === 'TICKETS' && (
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

        {/* Ticket List Queue */}
        <div className="lg:col-span-1 p-5 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100 dark:border-slate-800">
            <h2 className="font-extrabold text-sm text-slate-900 dark:text-white">
              Your Support Queue ({tickets.length})
            </h2>
            <span className="text-[10px] text-slate-400 font-bold">
              Auto-purges 72h after closed
            </span>
          </div>

          {loading ? (
            <div className="py-8 text-center text-xs text-slate-400 animate-pulse">Loading tickets...</div>
          ) : tickets.length === 0 ? (
            <div className="py-8 text-center space-y-2">
              <HelpCircle className="w-8 h-8 text-slate-300 dark:text-slate-700 mx-auto" />
              <p className="text-xs font-bold text-slate-500">No support tickets</p>
              <p className="text-[11px] text-slate-400">Click "Open Support Ticket" above to reach our team.</p>
            </div>
          ) : (
            <div className="space-y-2">
              {tickets.map((tkt) => {
                const isActive = activeTicket?.id === tkt.id;
                const hoursLeft = getHoursUntilAutoDelete(tkt);
                return (
                  <div
                    key={tkt.id}
                    onClick={() => setActiveTicket(tkt)}
                    className={`p-3.5 rounded-2xl cursor-pointer border transition-all ${
                      isActive
                        ? 'bg-indigo-50 dark:bg-indigo-950/60 border-indigo-500'
                        : 'bg-slate-50 dark:bg-slate-800/40 border-slate-100 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="px-2 py-0.5 rounded-md bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 text-[10px] font-bold">
                        {tkt.category}
                      </span>
                      <span className={`px-2 py-0.5 rounded-full text-[9px] font-black uppercase ${
                        tkt.status === 'CLOSED'
                          ? 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                          : tkt.status === 'RESOLVED'
                          ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400'
                          : tkt.status === 'IN_PROGRESS'
                          ? 'bg-indigo-100 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400'
                          : 'bg-amber-100 dark:bg-amber-950 text-amber-600 dark:text-amber-400'
                      }`}>
                        {tkt.status}
                      </span>
                    </div>

                    <h4 className="font-bold text-xs text-slate-900 dark:text-white truncate">
                      {tkt.subject}
                    </h4>

                    <div className="flex items-center justify-between text-[10px] text-slate-400 mt-1">
                      <span>{new Date(tkt.updatedAt).toLocaleDateString()}</span>
                      {tkt.status === 'CLOSED' && hoursLeft !== null && (
                        <span className="text-amber-500 dark:text-amber-400 font-bold">
                          Deletes in ~{hoursLeft}h
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Chat Thread Panel */}
        <div className="lg:col-span-2 p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between min-h-[480px]">
          {activeTicket ? (
            <>
              <div>
                {/* Ticket Header */}
                <div className="pb-4 border-b border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="font-mono text-[10px] font-bold text-slate-400">{activeTicket.id}</span>
                      <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase ${
                        activeTicket.status === 'CLOSED'
                          ? 'bg-slate-200 dark:bg-slate-700 text-slate-600 dark:text-slate-300'
                          : activeTicket.status === 'RESOLVED'
                          ? 'bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400'
                          : activeTicket.status === 'IN_PROGRESS'
                          ? 'bg-indigo-100 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400'
                          : 'bg-amber-100 dark:bg-amber-950 text-amber-600 dark:text-amber-400'
                      }`}>
                        {activeTicket.status}
                      </span>
                    </div>
                    <h3 className="font-extrabold text-base text-slate-900 dark:text-white">
                      {activeTicket.subject}
                    </h3>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Category: {activeTicket.category} • Priority: {activeTicket.priority} • Opened {new Date(activeTicket.createdAt).toLocaleDateString()}
                    </p>
                  </div>

                  {/* Actions (Close/Reopen/Delete) */}
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      disabled={updatingStatus}
                      onClick={handleToggleCloseTicket}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                        activeTicket.status === 'CLOSED'
                          ? 'bg-indigo-100 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-200'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
                      }`}
                    >
                      {activeTicket.status === 'CLOSED' ? 'Re-open Ticket' : 'Close Ticket'}
                    </button>

                    {activeTicket.status === 'CLOSED' && (
                      <button
                        onClick={handleDeleteTicketNow}
                        className="p-1.5 rounded-xl text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors"
                        title="Delete Ticket Now"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>

                {/* 72-Hour Notice Banner if Closed */}
                {activeTicket.status === 'CLOSED' && (
                  <div className="my-3 p-3.5 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/40 flex items-center justify-between gap-3 text-amber-800 dark:text-amber-200 text-xs">
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-amber-500 shrink-0" />
                      <span>
                        <strong>Ticket is Closed.</strong> It will be automatically deleted from the system 72 hours after closing ({getHoursUntilAutoDelete(activeTicket)}h remaining).
                      </span>
                    </div>
                  </div>
                )}

                {/* Replies Thread */}
                <div className="py-4 space-y-4 max-h-[320px] overflow-y-auto pr-2">
                  {activeTicket.replies?.map((rep) => (
                    <div
                      key={rep.id}
                      className={`p-4 rounded-2xl max-w-lg ${
                        rep.isAdminReply
                          ? 'bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/50 mr-auto'
                          : 'bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 dark:border-indigo-900/50 ml-auto'
                      }`}
                    >
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-extrabold text-xs text-slate-900 dark:text-white">
                          {rep.username}
                        </span>
                        {rep.isAdminReply && (
                          <span className="px-1.5 py-0.2 rounded bg-rose-600 text-white text-[9px] font-bold">
                            SUPPORT AGENT
                          </span>
                        )}
                        <span className="text-[10px] text-slate-400 ml-auto">
                          {new Date(rep.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                      <p className="text-xs text-slate-700 dark:text-slate-200 whitespace-pre-line leading-relaxed">
                        {rep.message}
                      </p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Reply Form Input */}
              {activeTicket.status !== 'CLOSED' ? (
                <form onSubmit={handleSendReply} className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center gap-2">
                  <input
                    type="text"
                    value={replyText}
                    onChange={(e) => setReplyText(e.target.value)}
                    placeholder="Type your message reply..."
                    className="flex-1 px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs outline-none focus:ring-2 focus:ring-indigo-500"
                  />
                  <button
                    type="submit"
                    disabled={submittingReply || !replyText.trim()}
                    className="px-5 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-md shadow-indigo-600/30 flex items-center gap-2 transition-all disabled:opacity-50 cursor-pointer"
                  >
                    <Send className="w-4 h-4" />
                    <span>Send</span>
                  </button>
                </form>
              ) : (
                <div className="pt-4 border-t border-slate-100 dark:border-slate-800 text-center py-3 text-xs text-slate-500 flex items-center justify-center gap-2">
                  <Lock className="w-3.5 h-3.5 text-slate-400" />
                  <span>This ticket is closed. Re-open the ticket above to send more messages.</span>
                </div>
              )}
            </>
          ) : (
            <div className="my-auto text-center py-12">
              <MessageSquare className="w-12 h-12 text-slate-300 dark:text-slate-700 mx-auto mb-2" />
              <p className="text-xs font-bold text-slate-500">Select a ticket to view thread</p>
            </div>
          )}
        </div>

      </div>
      )}

      {/* New Ticket Modal */}
      {showNewModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="relative w-full max-w-lg rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-6 sm:p-8">
            <button
              onClick={() => setShowNewModal(false)}
              className="absolute top-5 right-5 p-2 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>

            <h2 className="text-xl font-black text-slate-900 dark:text-white mb-1">
              Create Support Ticket
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
              Our support team will respond promptly. Note: Tickets are kept until closed and auto-deleted after 72 hours.
            </p>

            <form onSubmit={handleCreateTicket} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Subject
                </label>
                <input
                  type="text"
                  required
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="e.g. Issue with USDT withdrawal status"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs outline-none focus:ring-2 focus:ring-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Category
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="General">General Inquiry</option>
                    <option value="Withdrawal">Withdrawals & Payouts</option>
                    <option value="Tasks">Task Verification</option>
                    <option value="Referrals">Referral XP & Codes</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                    Priority
                  </label>
                  <select
                    value={priority}
                    onChange={(e) => setPriority(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs outline-none focus:ring-2 focus:ring-indigo-500"
                  >
                    <option value="LOW">Low</option>
                    <option value="MEDIUM">Medium</option>
                    <option value="HIGH">High</option>
                    <option value="URGENT">Urgent</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Message Details
                </label>
                <textarea
                  rows={4}
                  required
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Describe your issue or inquiry in detail..."
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs outline-none focus:ring-2 focus:ring-indigo-500 resize-none"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowNewModal(false)}
                  className="px-5 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold text-xs"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-md shadow-indigo-600/30"
                >
                  Submit Ticket
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
