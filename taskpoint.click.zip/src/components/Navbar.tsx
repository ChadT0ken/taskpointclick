import React, { useState, useEffect } from 'react';
import { 
  Bell, 
  Coins, 
  Sparkles, 
  User as UserIcon, 
  LogOut, 
  ShieldAlert, 
  Menu, 
  ChevronDown,
  Gift
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { api } from '../lib/api';
import { NotificationCenter } from './NotificationCenter';

interface NavbarProps {
  onToggleSidebar?: () => void;
  onNavigate: (view: string) => void;
  activeView?: string;
  onOpenAuth?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ 
  onToggleSidebar = () => {}, 
  onNavigate, 
  activeView, 
  onOpenAuth = () => {} 
}) => {
  const { user, logout, switchDemoRole } = useAuth();
  const [showNotifications, setShowNotifications] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  const [showUserDropdown, setShowUserDropdown] = useState(false);

  const fetchUnreadNotifications = async () => {
    if (!user) return;
    try {
      const notifs = await api.getNotifications();
      const unread = notifs.filter((n) => !n.isRead).length;
      setUnreadCount(unread);
    } catch (e) {
      // silent
    }
  };

  useEffect(() => {
    fetchUnreadNotifications();
    const interval = setInterval(fetchUnreadNotifications, 15000);
    return () => clearInterval(interval);
  }, [user]);

  return (
    <header className="sticky top-0 z-40 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 transition-colors">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-2 sm:gap-4">
        
        {/* Left Side: Mobile Toggle & Header Title / Brand */}
        <div className="flex items-center gap-2 sm:gap-3 min-w-0">
          <button
            id="btn-toggle-sidebar"
            onClick={onToggleSidebar}
            className="p-1.5 sm:p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors lg:hidden shrink-0"
            title="Toggle Menu"
          >
            <Menu className="w-5 h-5" />
          </button>

          <div 
            onClick={() => onNavigate('dashboard')}
            className="flex items-center gap-2 sm:gap-3 cursor-pointer group select-none min-w-0"
          >
            <div className="w-7 h-7 sm:w-8 sm:h-8 bg-blue-600 rounded-lg flex items-center justify-center font-bold text-white shadow-md shadow-blue-600/20 group-hover:scale-105 transition-transform text-sm sm:text-base shrink-0">
              T
            </div>
            <div className="flex items-center gap-2 min-w-0">
              <span className="text-base sm:text-lg font-bold text-slate-900 dark:text-white tracking-tight truncate">
                TaskPoint
              </span>
              <span className="hidden md:inline-flex px-2.5 py-0.5 bg-green-100 dark:bg-green-950/80 text-green-700 dark:text-green-300 rounded-full text-[10px] font-medium border border-green-200 dark:border-green-800/60">
                Online
              </span>
            </div>
          </div>
        </div>

        {/* Right Side: Balances, Notifications, Theme & User Account */}
        <div className="flex items-center gap-1.5 sm:gap-3 shrink-0">
          
          {user ? (
            <>
              {/* Cash Balance */}
              <div 
                onClick={() => onNavigate('wallet')}
                className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-slate-100 font-mono font-bold text-xs cursor-pointer hover:border-blue-500 transition-all shrink-0"
                title="Available Balance"
              >
                <Coins className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <span>${user.availableBalance.toLocaleString('en-US', { minimumFractionDigits: 2 })}</span>
              </div>

              {/* Airdrop XP Badge */}
              <div 
                onClick={() => onNavigate('airdrop')}
                className="flex items-center gap-1 sm:gap-2 px-2 sm:px-3 py-1 sm:py-1.5 rounded-lg bg-blue-50 dark:bg-blue-950/50 border border-blue-200 dark:border-blue-800 text-blue-700 dark:text-blue-300 font-bold text-[11px] sm:text-xs cursor-pointer hover:bg-blue-100 dark:hover:bg-blue-900/60 transition-all shrink-0"
                title="Airdrop XP"
              >
                <Sparkles className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-blue-600 dark:text-blue-400" />
                <span className="font-mono">{((user.airdropPoints || 0) + (user.referralPoints || 0)).toLocaleString()} <span className="font-sans font-semibold text-[9px] sm:text-[10px]">XP</span></span>
              </div>

              {/* Notifications Button */}
              <button
                id="btn-notifications"
                onClick={() => setShowNotifications(!showNotifications)}
                className="relative p-1.5 sm:p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors shrink-0"
                title="Notifications"
              >
                <Bell className="w-4 h-4 sm:w-5 sm:h-5" />
                {unreadCount > 0 && (
                  <span className="absolute top-1 right-1 w-3.5 h-3.5 sm:w-4 sm:h-4 rounded-full bg-blue-600 text-white text-[9px] sm:text-[10px] font-bold flex items-center justify-center">
                    {unreadCount}
                  </span>
                )}
              </button>
            </>
          ) : (
            <button
              onClick={onOpenAuth}
              className="px-3 sm:px-4 py-1.5 sm:py-2 text-xs sm:text-sm font-semibold rounded-lg bg-blue-600 hover:bg-blue-500 text-white shadow-sm transition-all"
            >
              Sign In
            </button>
          )}

          {/* User Account Dropdown */}
          {user && (
            <div className="relative shrink-0">
              <button
                id="btn-user-menu"
                onClick={() => setShowUserDropdown(!showUserDropdown)}
                className="flex items-center gap-1.5 sm:gap-2.5 p-1 sm:p-1.5 sm:pl-3 sm:pr-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-750 transition-colors shrink-0"
              >
                <div className="text-right hidden sm:block">
                  <p className="text-[10px] text-slate-500 font-medium leading-none">Welcome back,</p>
                  <p className="text-xs font-bold text-slate-900 dark:text-white leading-tight mt-0.5 max-w-[110px] truncate">
                    {user.username}
                  </p>
                </div>
                <img
                  src={user.avatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${user.username}`}
                  alt={user.username}
                  className="w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-slate-200 dark:bg-slate-700 border border-slate-300 dark:border-slate-600 object-cover shrink-0"
                />
                <ChevronDown className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-slate-400 shrink-0" />
              </button>

              {/* Dropdown Menu */}
              {showUserDropdown && (
                <div 
                  className="absolute right-0 mt-2 w-56 max-w-[calc(100vw-1.5rem)] rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xl py-2 z-50 divide-y divide-slate-100 dark:divide-slate-800 animate-in fade-in duration-150"
                  onMouseLeave={() => setShowUserDropdown(false)}
                >
                  <div className="px-4 py-2">
                    <p className="text-xs font-bold text-slate-900 dark:text-white truncate">
                      {user.username}
                    </p>
                    <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                      {user.email}
                    </p>
                    <div className="mt-2 flex items-center justify-between text-[11px]">
                      <span className="px-2 py-0.5 rounded font-bold bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800">
                        {user.role}
                      </span>
                      <span className="text-slate-400">
                        Streak: 🔥 {user.dailyStreak} Days
                      </span>
                    </div>
                  </div>

                  <div className="py-1 text-xs">
                    <button
                      onClick={() => { onNavigate('profile'); setShowUserDropdown(false); }}
                      className="w-full text-left px-4 py-2 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center gap-2.5"
                    >
                      <UserIcon className="w-4 h-4 text-slate-400" />
                      Profile & Settings
                    </button>
                    <button
                      onClick={() => { onNavigate('referrals'); setShowUserDropdown(false); }}
                      className="w-full text-left px-4 py-2 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 flex items-center gap-2.5"
                    >
                      <Gift className="w-4 h-4 text-blue-500" />
                      Referrals & Rewards
                    </button>
                    {(user.role === 'ADMIN' || user.role === 'MODERATOR' || user.role === 'SUPPORT') && (
                      <button
                        onClick={() => { onNavigate('admin-dashboard'); setShowUserDropdown(false); }}
                        className="w-full text-left px-4 py-2 text-rose-600 dark:text-rose-400 font-semibold hover:bg-rose-50 dark:hover:bg-rose-950/30 flex items-center gap-2.5"
                      >
                        <ShieldAlert className="w-4 h-4" />
                        Admin Portal
                      </button>
                    )}
                  </div>

                  <div className="py-1 text-xs">
                    <button
                      onClick={() => { logout(); setShowUserDropdown(false); }}
                      className="w-full text-left px-4 py-2 text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/30 flex items-center gap-2.5 font-medium"
                    >
                      <LogOut className="w-4 h-4" />
                      Sign Out
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

        </div>
      </div>

      {/* Notification Popover */}
      {showNotifications && (
        <NotificationCenter 
          onClose={() => setShowNotifications(false)}
          onNavigate={(view) => {
            onNavigate(view);
            setShowNotifications(false);
          }}
        />
      )}
    </header>
  );
};

