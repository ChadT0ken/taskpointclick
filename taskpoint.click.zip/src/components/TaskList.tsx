import React, { useEffect, useState } from 'react';
import { 
  Search, 
  Filter, 
  Coins, 
  Sparkles, 
  Clock, 
  CheckCircle2, 
  ArrowRight,
  Flame,
  Globe,
  Smartphone,
  Twitter,
  Send,
  HelpCircle,
  ShieldAlert,
  ExternalLink
} from 'lucide-react';
import { Task, TaskCategory } from '../types';
import { api } from '../lib/api';
import { TaskDetailModal } from './TaskDetailModal';

export const TaskList: React.FC = () => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Filters
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [difficulty, setDifficulty] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState('');

  // Modal active task
  const [activeTask, setActiveTask] = useState<Task | null>(null);

  const categories = [
    { id: 'ALL', label: 'All Tasks', icon: Globe },
    { id: 'TWITTER', label: 'Twitter / X', icon: Twitter },
    { id: 'TELEGRAM', label: 'Telegram', icon: Send },
    { id: 'APP_DOWNLOAD', label: 'App Install', icon: Smartphone },
    { id: 'SURVEY', label: 'Surveys', icon: HelpCircle },
    { id: 'CRYPTO', label: 'Web3 & Crypto', icon: Sparkles },
  ];

  const fetchTasks = async () => {
    setLoading(true);
    try {
      const data = await api.getTasks({
        category: selectedCategory,
        difficulty: difficulty,
        search: searchQuery,
      });
      setTasks(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTasks();
  }, [selectedCategory, difficulty]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchTasks();
  };

  const filteredTasks = tasks;

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-300">
      
      {/* Header Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">
            Explore Microtasks & Earn
          </h1>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Complete quick online tasks to earn instant cash and accumulated Airdrop Points.
          </p>
        </div>
      </div>

      {/* Category Pills Slider */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        {categories.map((cat) => {
          const Icon = cat.icon;
          const isSelected = selectedCategory === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-4 py-2 rounded-xl font-bold text-xs flex items-center gap-2 shrink-0 transition-all ${
                isSelected
                  ? 'bg-blue-600 text-white shadow-sm shadow-blue-600/30'
                  : 'bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{cat.label}</span>
            </button>
          );
        })}
      </div>

      {/* Search & Difficulty Filter Bar */}
      <form onSubmit={handleSearchSubmit} className="grid grid-cols-1 md:grid-cols-4 gap-3">
        <div className="md:col-span-3 relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search tasks by title, hashtag, or keyword..."
            className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-white text-xs outline-none focus:ring-2 focus:ring-blue-500 transition-all shadow-xs"
          />
        </div>

        <div>
          <select
            value={difficulty}
            onChange={(e) => setDifficulty(e.target.value)}
            className="w-full px-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 text-xs font-semibold outline-none focus:ring-2 focus:ring-blue-500 transition-all shadow-xs"
          >
            <option value="ALL">All Difficulties</option>
            <option value="Easy">Easy (1-3 mins)</option>
            <option value="Medium">Medium (3-5 mins)</option>
            <option value="Hard">Hard (5+ mins)</option>
          </select>
        </div>
      </form>

      {/* Task Grid */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <div key={i} className="h-64 rounded-3xl bg-slate-100 dark:bg-slate-800/50 animate-pulse"></div>
          ))}
        </div>
      ) : filteredTasks.length === 0 ? (
        <div className="py-16 text-center bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800">
          <Filter className="w-10 h-10 text-slate-300 dark:text-slate-700 mx-auto mb-2" />
          <h3 className="font-extrabold text-sm text-slate-700 dark:text-slate-300">No matching tasks found</h3>
          <p className="text-xs text-slate-400 mt-1">Try resetting your filters or search keywords.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTasks.map((task) => {
            const isNoLimit = !task.totalSlots || task.totalSlots >= 999999;
            const slotsPercent = isNoLimit ? 100 : Math.min(100, Math.round((task.filledSlots / task.totalSlots) * 100));
            const isCompleted = task.userSubmissionStatus === 'APPROVED' || task.userSubmissionStatus === 'PENDING';

            return (
              <div
                key={task.id}
                onClick={() => setActiveTask(task)}
                className="group p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-blue-500 dark:hover:border-blue-500 shadow-xs hover:shadow-md transition-all cursor-pointer flex flex-col justify-between relative overflow-hidden"
              >
                <div>
                  {/* Top Header */}
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <span className="px-2.5 py-1 rounded-lg bg-blue-50 dark:bg-blue-950/80 text-blue-700 dark:text-blue-300 text-[10px] font-bold uppercase tracking-wider">
                      {task.category}
                    </span>
                  </div>

                  {/* Banner image preview if exists */}
                  {task.bannerImage && (
                    <div className="w-full h-28 rounded-xl overflow-hidden mb-3">
                      <img src={task.bannerImage} alt={task.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                    </div>
                  )}

                  {/* Task Title */}
                  <h3 className="font-bold text-sm text-slate-900 dark:text-white line-clamp-2 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                    {task.title}
                  </h3>

                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 line-clamp-2 leading-relaxed">
                    {task.description}
                  </p>

                  {/* Dual Rewards Pills */}
                  <div className="mt-4 flex items-center gap-2">
                    <div className="flex items-center gap-1 text-slate-900 dark:text-white font-mono font-bold text-xs px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800">
                      <Coins className="w-3.5 h-3.5 text-amber-500" />
                      <span>${task.rewardCash.toFixed(2)}</span>
                    </div>
                    <div className="flex items-center gap-1 text-blue-600 dark:text-blue-400 font-bold text-xs px-2.5 py-1 rounded-lg bg-blue-50 dark:bg-blue-950/50">
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>+{task.rewardPoints} XP</span>
                    </div>
                  </div>
                </div>

                {/* Bottom Slots Progress & Action */}
                <div className="mt-5 pt-4 border-t border-slate-100 dark:border-slate-800 space-y-2">
                  <div className="flex items-start justify-between text-[11px] text-slate-500 font-semibold">
                    <span>{isNoLimit ? 'Unlimited slots' : `${Math.max(0, task.totalSlots - task.filledSlots)} slots left`}</span>
                    <span>{task.estimatedTime}</span>
                  </div>

                  <div className="w-full h-1.5 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                    <div 
                      className="h-full bg-blue-600 rounded-full"
                      style={{ width: `${slotsPercent}%` }}
                    ></div>
                  </div>

                  <div className="pt-1 flex items-center justify-between gap-2">
                    {task.userSubmissionStatus ? (
                      <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase ${
                        task.userSubmissionStatus === 'APPROVED'
                          ? 'bg-emerald-100 text-emerald-700'
                          : task.userSubmissionStatus === 'PENDING'
                          ? 'bg-amber-100 text-amber-700'
                          : 'bg-rose-100 text-rose-700'
                      }`}>
                        Status: {task.userSubmissionStatus}
                      </span>
                    ) : (
                      <span className="text-[11px] font-bold text-blue-600 dark:text-blue-400 group-hover:translate-x-1 transition-transform flex items-center gap-1">
                        Start Task <ArrowRight className="w-3.5 h-3.5" />
                      </span>
                    )}

                    {task.taskUrl && (
                      <a
                        href={task.taskUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        onClick={(e) => e.stopPropagation()}
                        className="p-1.5 rounded-lg bg-indigo-50 dark:bg-indigo-950/60 hover:bg-indigo-100 text-indigo-600 dark:text-indigo-400 font-extrabold text-[10px] flex items-center gap-1 transition-colors shrink-0"
                        title="Open Task URL"
                      >
                        <ExternalLink className="w-3 h-3" />
                        <span>Link</span>
                      </a>
                    )}
                  </div>
                </div>

              </div>
            );
          })}
        </div>
      )}

      {/* Task Submission & Details Modal */}
      {activeTask && (
        <TaskDetailModal
          task={activeTask}
          onClose={() => setActiveTask(null)}
          onSubmitted={() => {
            fetchTasks();
          }}
        />
      )}

    </div>
  );
};
