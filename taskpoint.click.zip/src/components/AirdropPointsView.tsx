import React, { useEffect, useState } from 'react';
import { 
  Sparkles, 
  Trophy, 
  Gift, 
  Flame, 
  ArrowUpRight, 
  Users, 
  Coins, 
  Layers, 
  Info,
  Calendar,
  Zap,
  CheckCircle2
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { api } from '../lib/api';
import { LeaderboardEntry, AirdropStats } from '../types';

export const AirdropPointsView: React.FC = () => {
  const { user, refreshUser } = useAuth();
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [airdropStats, setAirdropStats] = useState<AirdropStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [claimingStreak, setClaimingStreak] = useState(false);
  const [streakMsg, setStreakMsg] = useState<string | null>(null);

  const fetchAirdropData = async () => {
    setLoading(true);
    try {
      const [boardData, statsData] = await Promise.all([
        api.getLeaderboard('POINTS'),
        api.getAirdropStats()
      ]);
      setLeaderboard(boardData);
      setAirdropStats(statsData);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAirdropData();
  }, []);

  if (!user) return null;

  // Estimated token ratio e.g. 10 XP = 1 $TASK Token
  const estimatedTokens = Math.floor((user.airdropPoints || 0) / 10);

  const handleClaimStreak = async () => {
    setClaimingStreak(true);
    setStreakMsg(null);
    try {
      const res = await api.claimStreak();
      setStreakMsg(`🔥 Streak claimed successfully! (+${res.bonusPoints} Airdrop XP)`);
      await refreshUser();
      await fetchAirdropData();
    } catch (err: any) {
      setStreakMsg(err.message || 'Streak already claimed for today.');
    } finally {
      setClaimingStreak(false);
    }
  };

  const totalPool = airdropStats?.totalPoolXP || 400000;
  const totalClaimed = airdropStats?.totalClaimedXP || 127250;
  const availableToClaim = airdropStats?.availableToClaimXP || Math.max(0, totalPool - totalClaimed);
  const claimedPercent = Math.min(100, Math.round((totalClaimed / totalPool) * 100));

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-300 max-w-5xl mx-auto">
      
      {/* Header Banner */}
      <div className="p-8 rounded-3xl bg-gradient-to-br from-indigo-950 via-purple-950 to-slate-950 text-white shadow-2xl relative overflow-hidden border border-indigo-500/30">
        <div className="absolute -top-12 -right-12 w-64 h-64 bg-indigo-500/20 rounded-full blur-3xl pointer-events-none"></div>

        <div className="relative z-10 space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 text-xs font-bold">
            <Sparkles className="w-4 h-4 text-amber-400" />
            <span>TaskPoint ($TASK) Airdrop Hub • Season 1</span>
          </div>

          <h1 className="text-3xl sm:text-4xl font-black tracking-tight">
            Accumulate $TASK Airdrop XP for TGE Token Snapshot
          </h1>

          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-3xl">
            Airdrop XP is non-withdrawable experience awarded for microtasks, daily check-ins, and inviting friends from a global pool of <strong>{totalPool.toLocaleString()} XP</strong>. All accumulated XP will convert to $TASK Tokens during the upcoming TGE Snapshot.
          </p>

          {/* Metric Cards Grid */}
          <div className="mt-6 grid grid-cols-2 sm:grid-cols-4 gap-4 pt-2">
            <div className="p-4 rounded-2xl bg-white/10 backdrop-blur-md border border-white/10">
              <p className="text-xs text-indigo-200 font-bold uppercase">Your Total Earned XP</p>
              <h3 className="text-2xl font-black mt-1 text-white">
                {((user.airdropPoints || 0) + (user.referralPoints || 0)).toLocaleString()} XP
              </h3>
              <p className="text-[10px] text-indigo-300 mt-1">
                {(user.airdropPoints || 0).toLocaleString()} Task XP + {(user.referralPoints || 0).toLocaleString()} Referral XP
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-white/10 backdrop-blur-md border border-white/10">
              <p className="text-xs text-emerald-300 font-bold uppercase">Available to Claim</p>
              <h3 className="text-2xl font-black mt-1 text-emerald-300">
                {availableToClaim.toLocaleString()} XP
              </h3>
              <p className="text-[10px] text-emerald-200/80 mt-1">Remaining in global pool</p>
            </div>

            <div className="p-4 rounded-2xl bg-white/10 backdrop-blur-md border border-white/10">
              <p className="text-xs text-blue-300 font-bold uppercase">Total Claimed (All Users)</p>
              <h3 className="text-2xl font-black mt-1 text-blue-300">
                {totalClaimed.toLocaleString()} XP
              </h3>
              <p className="text-[10px] text-blue-200/80 mt-1">Claimed across platform</p>
            </div>

            <div className="p-4 rounded-2xl bg-white/10 backdrop-blur-md border border-white/10">
              <p className="text-xs text-amber-300 font-bold uppercase">Total Airdrop Pool</p>
              <h3 className="text-2xl font-black mt-1 text-amber-300">
                {totalPool.toLocaleString()} XP
              </h3>
              <p className="text-[10px] text-amber-200/80 mt-1">Season 1 Total Allocation</p>
            </div>
          </div>

          {/* Pool Distribution Progress Bar */}
          <div className="mt-4 p-4 rounded-2xl bg-white/5 border border-white/10 space-y-2">
            <div className="flex items-center justify-between text-xs font-bold">
              <span className="text-slate-300 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-blue-400" />
                <span>Global Airdrop Pool Claimed Progress</span>
              </span>
              <span className="text-emerald-400 font-mono">
                {claimedPercent}% Claimed ({availableToClaim.toLocaleString()} XP Available)
              </span>
            </div>
            <div className="h-2.5 w-full bg-slate-800/80 rounded-full overflow-hidden p-0.5 border border-white/10">
              <div
                className="h-full bg-gradient-to-r from-blue-500 to-emerald-400 rounded-full transition-all duration-500"
                style={{ width: `${claimedPercent}%` }}
              ></div>
            </div>
          </div>

        </div>
      </div>

      {/* Daily Streak & Daily XP Bonus Section */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center shrink-0">
            <Flame className="w-6 h-6 text-amber-500" />
          </div>
          <div>
            <h3 className="font-extrabold text-base text-slate-900 dark:text-white flex items-center gap-2">
              <span>Daily Check-in Streak ({user.dailyStreak || 1} Days)</span>
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Claim daily check-in rewards to earn <span className="font-bold text-amber-500">+10 Airdrop XP</span> every 24 hours.
            </p>
            {streakMsg && (
              <p className="text-xs font-bold text-emerald-600 dark:text-emerald-400 mt-1">
                {streakMsg}
              </p>
            )}
          </div>
        </div>

        <button
          onClick={handleClaimStreak}
          disabled={claimingStreak}
          className="w-full sm:w-auto px-6 py-3 rounded-2xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs shadow-md transition-all active:scale-95 disabled:opacity-50 shrink-0 flex items-center justify-center gap-2"
        >
          <Zap className="w-4 h-4 fill-slate-950" />
          <span>{claimingStreak ? 'Claiming...' : 'Claim Daily +10 Airdrop XP'}</span>
        </button>
      </div>

      {/* Airdrop XP Earning Breakdown Rules */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-2">
          <div className="w-9 h-9 rounded-xl bg-blue-500/10 text-blue-500 flex items-center justify-center font-black">
            <Coins className="w-5 h-5" />
          </div>
          <h4 className="font-extrabold text-sm text-slate-900 dark:text-white">Microtasks Earning</h4>
          <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
            Earn <strong className="text-blue-500">+10 XP</strong> alongside USD cash payouts for every completed and verified microtask.
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-2">
          <div className="w-9 h-9 rounded-xl bg-amber-500/10 text-amber-500 flex items-center justify-center font-black">
            <Flame className="w-5 h-5" />
          </div>
          <h4 className="font-extrabold text-sm text-slate-900 dark:text-white">Daily Streak Check-in</h4>
          <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
            Log in daily to claim <strong className="text-amber-500">+10 XP</strong> every 24 hours to boost your ranking on the snapshot leaderboard.
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-2">
          <div className="w-9 h-9 rounded-xl bg-purple-500/10 text-purple-500 flex items-center justify-center font-black">
            <Users className="w-5 h-5" />
          </div>
          <h4 className="font-extrabold text-sm text-slate-900 dark:text-white">Referral Invites</h4>
          <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
            Receive <strong className="text-purple-500">+10 XP</strong> per referee who creates an account using your unique referral link.
          </p>
        </div>
      </div>

      {/* Leaderboard Section for Top XP Earners */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
        <div>
          <h2 className="font-extrabold text-lg text-slate-900 dark:text-white flex items-center gap-2">
            <Trophy className="w-5 h-5 text-indigo-500" />
            <span>Top Airdrop XP Holders Leaderboard</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Top participants with the highest Airdrop XP allocations for the $TASK Token TGE Snapshot.
          </p>
        </div>

        {/* Top 3 Podium Highlights */}
        {!loading && leaderboard.length >= 3 && (
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2 pb-2">
            {/* Rank 2 - Silver */}
            <div className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 text-center relative flex flex-col justify-between order-2 sm:order-1">
              <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-2.5 py-0.5 rounded-full bg-slate-300 dark:bg-slate-600 text-slate-900 dark:text-slate-100 font-extrabold text-[10px] shadow-sm">
                🥈 #2 SILVER
              </div>
              <div className="mt-2 space-y-2">
                <img
                  src={leaderboard[1].avatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${leaderboard[1].username}`}
                  alt={leaderboard[1].username}
                  className="w-14 h-14 rounded-2xl mx-auto object-cover border-2 border-slate-300 dark:border-slate-600 shadow-md"
                />
                <div>
                  <h3 className="font-extrabold text-sm text-slate-900 dark:text-white truncate">
                    {leaderboard[1].username}
                  </h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">{leaderboard[1].country}</p>
                </div>
              </div>
              <div className="mt-3 pt-3 border-t border-slate-200 dark:border-slate-700 space-y-1">
                <p className="text-sm font-black text-indigo-600 dark:text-indigo-400">
                  {(leaderboard[1].airdropPoints || 0).toLocaleString()} Airdrop XP
                </p>
                <p className="text-[10px] text-slate-400 font-bold">
                  {(leaderboard[1].referralCount || 0)} Referrals ({(leaderboard[1].referralPoints || 0).toLocaleString()} Ref XP)
                </p>
              </div>
            </div>

            {/* Rank 1 - Gold */}
            <div className="p-6 rounded-2xl bg-gradient-to-b from-indigo-500/10 via-purple-500/5 to-slate-50 dark:to-slate-800/80 border-2 border-indigo-500/80 text-center relative flex flex-col justify-between order-1 sm:order-2 shadow-lg scale-105 z-10">
              <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full bg-indigo-600 text-white font-black text-xs shadow-md flex items-center gap-1">
                <Trophy className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                <span>🥇 #1 XP CHAMPION</span>
              </div>
              <div className="mt-2 space-y-2">
                <img
                  src={leaderboard[0].avatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${leaderboard[0].username}`}
                  alt={leaderboard[0].username}
                  className="w-16 h-16 rounded-2xl mx-auto object-cover border-2 border-indigo-500 shadow-xl"
                />
                <div>
                  <h3 className="font-black text-base text-slate-900 dark:text-white truncate">
                    {leaderboard[0].username}
                  </h3>
                  <p className="text-xs text-indigo-600 dark:text-indigo-400 font-bold">{leaderboard[0].country}</p>
                </div>
              </div>
              <div className="mt-3 pt-3 border-t border-indigo-200 dark:border-indigo-900/60 space-y-1">
                <p className="text-base font-black text-indigo-600 dark:text-indigo-400">
                  {(leaderboard[0].airdropPoints || 0).toLocaleString()} Airdrop XP
                </p>
                <p className="text-[11px] text-slate-400 font-bold">
                  {(leaderboard[0].referralCount || 0)} Referrals ({(leaderboard[0].referralPoints || 0).toLocaleString()} Ref XP)
                </p>
              </div>
            </div>

            {/* Rank 3 - Bronze */}
            <div className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 text-center relative flex flex-col justify-between order-3">
              <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-2.5 py-0.5 rounded-full bg-amber-800 text-white font-extrabold text-[10px] shadow-sm">
                🥉 #3 BRONZE
              </div>
              <div className="mt-2 space-y-2">
                <img
                  src={leaderboard[2].avatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${leaderboard[2].username}`}
                  alt={leaderboard[2].username}
                  className="w-14 h-14 rounded-2xl mx-auto object-cover border-2 border-amber-700/60 shadow-md"
                />
                <div>
                  <h3 className="font-extrabold text-sm text-slate-900 dark:text-white truncate">
                    {leaderboard[2].username}
                  </h3>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400">{leaderboard[2].country}</p>
                </div>
              </div>
              <div className="mt-3 pt-3 border-t border-slate-200 dark:border-slate-700 space-y-1">
                <p className="text-sm font-black text-indigo-600 dark:text-indigo-400">
                  {(leaderboard[2].airdropPoints || 0).toLocaleString()} Airdrop XP
                </p>
                <p className="text-[10px] text-slate-400 font-bold">
                  {(leaderboard[2].referralCount || 0)} Referrals ({(leaderboard[2].referralPoints || 0).toLocaleString()} Ref XP)
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Leaderboard Table */}
        {loading ? (
          <div className="p-8 text-center text-xs text-slate-400 animate-pulse">
            Fetching top XP holders...
          </div>
        ) : leaderboard.length === 0 ? (
          <div className="p-8 text-center text-xs text-slate-500 dark:text-slate-400">
            No rankings logged yet. Complete tasks to earn Airdrop XP!
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-400 font-bold uppercase text-[10px]">
                  <th className="pb-3 pl-2">Rank</th>
                  <th className="pb-3">Participant</th>
                  <th className="pb-3">Country</th>
                  <th className="pb-3 text-right">Airdrop XP</th>
                  <th className="pb-3 text-right pr-2">Referrals (XP & Count)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60">
                {leaderboard.map((entry) => {
                  const isCurrentUser = entry.userId === user.id;
                  return (
                    <tr 
                      key={entry.userId}
                      className={`transition-colors ${
                        isCurrentUser ? 'bg-indigo-50/70 dark:bg-indigo-950/40 font-bold' : 'hover:bg-slate-50 dark:hover:bg-slate-800/50'
                      }`}
                    >
                      <td className="py-3 pl-2 font-black">
                        <span className={`inline-flex items-center justify-center w-7 h-7 rounded-xl text-xs ${
                          entry.rank === 1
                            ? 'bg-indigo-600 text-white font-black shadow-md shadow-indigo-600/30'
                            : entry.rank === 2
                            ? 'bg-slate-300 text-slate-950 font-black'
                            : entry.rank === 3
                            ? 'bg-amber-700 text-white font-black'
                            : 'text-slate-500'
                        }`}>
                          #{entry.rank}
                        </span>
                      </td>

                      <td className="py-3">
                        <div className="flex items-center gap-2.5">
                          <img
                            src={entry.avatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${entry.username}`}
                            alt={entry.username}
                            className="w-8 h-8 rounded-xl object-cover ring-2 ring-indigo-500/20"
                          />
                          <div>
                            <p className="font-extrabold text-slate-900 dark:text-white flex items-center gap-1.5">
                              <span>{entry.username}</span>
                              {isCurrentUser && (
                                <span className="px-1.5 py-0.2 rounded bg-indigo-600 text-white text-[9px] font-bold">
                                  YOU
                                </span>
                              )}
                            </p>
                          </div>
                        </div>
                      </td>

                      <td className="py-3 text-slate-500 dark:text-slate-400 font-medium">
                        {entry.country || 'Global'}
                      </td>

                      <td className="py-3 text-right font-black text-indigo-600 dark:text-indigo-400 text-sm">
                        {(entry.airdropPoints || 0).toLocaleString()} XP
                      </td>

                      <td className="py-3 text-right pr-2">
                        <span className="font-extrabold text-slate-900 dark:text-white">
                          {(entry.referralPoints || 0).toLocaleString()} XP
                        </span>
                        <span className="block text-[10px] text-slate-400 font-medium">
                          {entry.referralCount || 0} referrals
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

      </div>

    </div>
  );
};
