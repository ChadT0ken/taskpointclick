import React, { useEffect, useState } from 'react';
import { 
  Coins, 
  Clock, 
  TrendingUp, 
  CheckCircle2, 
  XCircle, 
  Flame, 
  Gift, 
  ArrowUpRight, 
  ChevronRight, 
  Trophy,
  AlertCircle,
  ShieldCheck,
  Megaphone,
  Copy,
  Check
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { api } from '../lib/api';
import { Announcement, TaskSubmission, Task } from '../types';

interface UserDashboardProps {
  onNavigate: (view: string) => void;
}

export const UserDashboard: React.FC<UserDashboardProps> = ({ onNavigate }) => {
  const { user, refreshUser } = useAuth();
  const [submissions, setSubmissions] = useState<TaskSubmission[]>([]);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [featuredTasks, setFeaturedTasks] = useState<Task[]>([]);
  const [claimingStreak, setClaimingStreak] = useState(false);
  const [streakClaimed, setStreakClaimed] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  const loadDashboardData = async () => {
    try {
      const [subs, ancs, tasksData] = await Promise.all([
        api.getMySubmissions(),
        api.getAnnouncements(),
        api.getTasks(),
      ]);
      setSubmissions(subs);
      setAnnouncements(ancs);
      setFeaturedTasks(tasksData.slice(0, 3));
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    loadDashboardData();
  }, []);

  const handleClaimStreak = async () => {
    setClaimingStreak(true);
    try {
      await api.claimStreak();
      await refreshUser();
      setStreakClaimed(true);
    } catch (e) {
      console.error(e);
    } finally {
      setClaimingStreak(false);
    }
  };

  const copyReferralCode = () => {
    const code = user?.referralCode || 'REF123';
    navigator.clipboard.writeText(code);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  if (!user) return null;

  const todayStr = new Date().toISOString().split('T')[0];
  const isClaimedToday = user.lastStreakClaimDate === todayStr || streakClaimed;

  const completedCount = submissions.filter((s) => s.status === 'APPROVED').length;
  const pendingCount = submissions.filter((s) => s.status === 'PENDING').length;

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-300">
      
      {/* Banner Announcements if any */}
      {announcements.length > 0 && (
        <div className="p-4 rounded-xl bg-blue-600 text-white shadow-sm flex items-start gap-3">
          <Megaphone className="w-5 h-5 text-amber-300 shrink-0 mt-0.5" />
          <div className="flex-1">
            <h4 className="font-bold text-sm">{announcements[0].title}</h4>
            <p className="text-xs text-blue-100 mt-0.5">{announcements[0].content}</p>
          </div>
        </div>
      )}

      {/* Streak Claim Widget Bar - Hidden per user request */}
      {/* <div className="hidden bg-white dark:bg-slate-900 p-4 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 ..."> */}

      {/* Stats Row */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        
        {/* Available Balance Card */}
        <div 
          onClick={() => onNavigate('wallet')}
          className="bg-white dark:bg-slate-900 p-5 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 cursor-pointer hover:border-blue-500 transition-all"
        >
          <p className="text-slate-500 dark:text-slate-400 text-xs font-semibold uppercase mb-1">
            Available Balance
          </p>
          <h3 className="text-2xl font-bold font-mono text-slate-900 dark:text-white">
            ${(user.availableBalance || 0).toLocaleString('en-US', { minimumFractionDigits: 2 })}
          </h3>
          <p className="text-xs text-slate-400 mt-2 flex items-center font-medium">
            <ArrowUpRight className="w-3.5 h-3.5 mr-1 text-blue-500" />
            Instant Withdrawal Ready
          </p>
        </div>

        {/* Pending Tasks Card */}
        <div className="bg-white dark:bg-slate-900 p-5 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800">
          <p className="text-slate-500 dark:text-slate-400 text-xs font-semibold uppercase mb-1">
            Pending Submissions
          </p>
          <h3 className="text-2xl font-bold text-slate-900 dark:text-white">
            {pendingCount}
          </h3>
          <p className="text-xs text-slate-400 mt-2 font-medium font-mono">
            ${(user.pendingBalance || 0).toLocaleString('en-US', { minimumFractionDigits: 2 })} Estimated
          </p>
        </div>

      </div>

      {/* Main Grid: Recommended Tasks & Leaderboard/Referral Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Recommended Tasks Section (col-span-8) */}
        <div className="lg:col-span-8 bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 overflow-hidden flex flex-col justify-between">
          <div>
            <div className="px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between">
              <h3 className="font-bold text-slate-800 dark:text-white uppercase text-sm tracking-wide">
                Available Microtasks
              </h3>
              <button 
                onClick={() => onNavigate('tasks')}
                className="text-blue-600 dark:text-blue-400 text-sm font-semibold hover:underline"
              >
                View All
              </button>
            </div>

            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {featuredTasks.length === 0 ? (
                <div className="p-8 text-center">
                  <p className="text-sm font-semibold text-slate-600 dark:text-slate-400">
                    No active tasks currently available.
                  </p>
                  <p className="text-xs text-slate-400 mt-1">
                    Check back soon or create tasks via the Admin Panel.
                  </p>
                </div>
              ) : (
                featuredTasks.map((t) => (
                  <div key={t.id} className="px-6 py-4 flex items-center hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                    <div className="w-10 h-10 bg-blue-100 text-blue-600 dark:bg-blue-950 dark:text-blue-400 rounded-full flex items-center justify-center mr-4 font-bold text-sm uppercase shrink-0">
                      {t.category.slice(0, 1)}
                    </div>
                    <div className="flex-1 min-w-0 pr-2">
                      <h4 className="text-sm font-bold text-slate-900 dark:text-white truncate">
                        {t.title}
                      </h4>
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        Category: {t.category} • {!t.totalSlots || t.totalSlots >= 999999 ? 'Unlimited slots' : `${t.totalSlots - t.filledSlots} slots remaining`}
                      </p>
                    </div>
                    <div className="text-right flex items-center gap-4 sm:gap-6 shrink-0">
                      <div className="text-sm">
                        <p className="font-bold text-slate-900 dark:text-white font-mono">${t.rewardCash.toFixed(2)}</p>
                        <p className="text-[10px] text-blue-500 font-bold uppercase tracking-tighter">+{t.rewardPoints} XP</p>
                      </div>
                      <button 
                        onClick={() => onNavigate('tasks')}
                        className="px-4 py-2 bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs font-bold rounded-lg hover:bg-blue-600 hover:text-white transition-all"
                      >
                        START
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          <div className="p-4 bg-slate-50 dark:bg-slate-800/30 border-t border-slate-100 dark:border-slate-800 text-center">
            <button
              onClick={() => onNavigate('tasks')}
              className="text-xs font-bold text-blue-600 dark:text-blue-400 hover:underline"
            >
              Explore Live Tasks Marketplace →
            </button>
          </div>
        </div>

        {/* Side Section: Leaderboard & Referral Card (col-span-4) */}
        <div className="lg:col-span-4 flex flex-col gap-6">
          
          {/* User Account Summary Card */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl shadow-sm border border-slate-200 dark:border-slate-800 p-5">
            <h3 className="font-bold text-slate-800 dark:text-white uppercase text-xs tracking-widest mb-4">
              Your Account Summary
            </h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between bg-blue-50/50 dark:bg-blue-950/20 p-3 rounded-xl border border-blue-100 dark:border-blue-900/40">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-blue-600 text-white font-bold text-xs flex items-center justify-center">
                    {user.username.slice(0, 2).toUpperCase()}
                  </div>
                  <div>
                    <span className="text-sm font-bold text-slate-900 dark:text-white block">{user.username}</span>
                    <span className="text-[10px] text-slate-500 dark:text-slate-400">Role: {user.role}</span>
                  </div>
                </div>
                <span className="text-xs font-bold font-mono text-slate-900 dark:text-white">
                  {((user.airdropPoints || 0) + (user.referralPoints || 0)).toLocaleString()} <span className="text-blue-500 font-sans">XP</span>
                </span>
              </div>
            </div>

            <button 
              onClick={() => onNavigate('airdrop')}
              className="w-full mt-4 py-2 border border-slate-200 dark:border-slate-700 rounded-lg text-xs font-bold text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors uppercase tracking-wider"
            >
              View Leaderboards & Rewards
            </button>
          </div>

          {/* Referral Card */}
          <div className="bg-blue-600 rounded-2xl p-5 text-white shadow-md shadow-blue-600/20">
            <h4 className="text-sm font-bold mb-1">Invite & Earn XP</h4>
            <p className="text-xs text-blue-100 mb-4">
              Get +20 Airdrop XP for every verified friend using your code.
            </p>
            <div className="bg-blue-700/60 rounded-xl p-3 flex items-center justify-between mb-4 border border-blue-500/30">
              <div>
                <span className="text-[10px] uppercase font-bold text-blue-200 block">Your Referral Code</span>
                <span className="text-sm font-mono font-black tracking-widest text-amber-300 select-all">
                  {user.referralCode || 'NO CODE'}
                </span>
              </div>
              <button 
                onClick={copyReferralCode}
                className="px-3 py-1.5 bg-amber-400 hover:bg-amber-300 rounded-lg text-slate-950 font-extrabold text-xs transition-colors shrink-0 ml-2 flex items-center gap-1.5"
                title="Copy Referral Code"
              >
                {copiedLink ? (
                  <>
                    <Check className="w-3.5 h-3.5" />
                    <span>Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy Code</span>
                  </>
                )}
              </button>
            </div>
            <div className="flex items-center justify-between text-[10px] font-bold uppercase tracking-wider text-blue-100">
              <span>Active Referrals: {user.referralCount || 0}</span>
              <span>Total Referral XP: {(user.referralPoints !== undefined && user.referralPoints !== null ? user.referralPoints : (user.referralCount || 0) * 10).toLocaleString()} XP</span>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};

