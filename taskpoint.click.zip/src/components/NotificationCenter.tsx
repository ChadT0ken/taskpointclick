import React, { useEffect, useState } from 'react';
import { Bell, CheckCheck, X, Sparkles, AlertCircle, Coins, ShieldCheck, HelpCircle } from 'lucide-react';
import { Notification } from '../types';
import { api } from '../lib/api';

interface NotificationCenterProps {
  onClose: () => void;
  onNavigate: (view: string) => void;
}

export const NotificationCenter: React.FC<NotificationCenterProps> = ({ onClose, onNavigate }) => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchNotifs = async () => {
    try {
      const data = await api.getNotifications();
      setNotifications(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchNotifs();
  }, []);

  const handleMarkAllRead = async () => {
    try {
      await api.markNotificationsRead();
      setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
    } catch (e) {
      console.error(e);
    }
  };

  const getIcon = (type: string) => {
    switch (type) {
      case 'TASK':
        return <CheckCheck className="w-4 h-4 text-emerald-500" />;
      case 'WITHDRAWAL':
        return <Coins className="w-4 h-4 text-amber-500" />;
      case 'DISPUTE':
        return <AlertCircle className="w-4 h-4 text-rose-500" />;
      case 'SUPPORT':
        return <HelpCircle className="w-4 h-4 text-sky-500" />;
      case 'REFERRAL':
        return <Sparkles className="w-4 h-4 text-purple-500" />;
      default:
        return <Bell className="w-4 h-4 text-indigo-500" />;
    }
  };

  return (
    <div className="absolute right-4 top-16 w-80 sm:w-96 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl z-50 overflow-hidden animate-in fade-in slide-in-from-top-2 duration-200">
      <div className="p-4 bg-slate-50 dark:bg-slate-800/80 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Bell className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
          <h3 className="font-bold text-sm text-slate-900 dark:text-white">Notifications</h3>
          <span className="px-2 py-0.5 text-[10px] font-bold rounded-full bg-indigo-100 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300">
            {notifications.filter((n) => !n.isRead).length} New
          </span>
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={handleMarkAllRead}
            className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline font-semibold pr-2"
          >
            Mark all read
          </button>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-200 dark:hover:bg-slate-700"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="max-h-96 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800/50">
        {loading ? (
          <div className="p-8 text-center text-xs text-slate-400 animate-pulse">
            Loading notifications...
          </div>
        ) : notifications.length === 0 ? (
          <div className="p-8 text-center">
            <Bell className="w-8 h-8 text-slate-300 dark:text-slate-700 mx-auto mb-2" />
            <p className="text-xs font-semibold text-slate-500">No notifications yet</p>
          </div>
        ) : (
          notifications.map((n) => (
            <div
              key={n.id}
              onClick={() => {
                if (n.linkUrl) {
                  const viewMap: Record<string, string> = {
                    '/dashboard': 'dashboard',
                    '/wallet': 'wallet',
                    '/disputes': 'disputes',
                    '/support': 'support',
                    '/airdrop': 'airdrop',
                  };
                  onNavigate(viewMap[n.linkUrl] || 'dashboard');
                }
              }}
              className={`p-3.5 flex items-start gap-3 cursor-pointer transition-colors ${
                n.isRead ? 'bg-white dark:bg-slate-900 opacity-75' : 'bg-indigo-50/40 dark:bg-indigo-950/20'
              } hover:bg-slate-50 dark:hover:bg-slate-800/60`}
            >
              <div className="mt-0.5 p-2 rounded-xl bg-slate-100 dark:bg-slate-800 shrink-0">
                {getIcon(n.type)}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-bold text-slate-900 dark:text-white flex items-center justify-between">
                  <span>{n.title}</span>
                  {!n.isRead && <span className="w-2 h-2 rounded-full bg-indigo-600"></span>}
                </p>
                <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 line-clamp-2">
                  {n.message}
                </p>
                <span className="text-[10px] text-slate-400 mt-1 block">
                  {new Date(n.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </span>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
