import React, { useState, useEffect } from 'react';
import { X, MessageSquare, Send, CheckCircle2, AlertTriangle, ShieldAlert, Sparkles, HelpCircle, Loader2 } from 'lucide-react';
import { api } from '../lib/api';

interface LandingSupportModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialUsername?: string;
  initialCategory?: string;
  initialSubject?: string;
}

export const LandingSupportModal: React.FC<LandingSupportModalProps> = ({
  isOpen,
  onClose,
  initialUsername = '',
  initialCategory = 'Account Ban / Suspension Appeal',
  initialSubject = '',
}) => {
  const [username, setUsername] = useState(initialUsername);
  const [email, setEmail] = useState('');
  const [category, setCategory] = useState(initialCategory);
  const [priority, setPriority] = useState('HIGH');
  const [subject, setSubject] = useState(initialSubject);
  const [message, setMessage] = useState('');
  
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [submittedTicket, setSubmittedTicket] = useState<{ id: string; username: string } | null>(null);

  useEffect(() => {
    if (isOpen) {
      if (initialUsername) setUsername(initialUsername);
      if (initialCategory) setCategory(initialCategory);
      if (initialSubject) setSubject(initialSubject);
      setError(null);
      setSubmittedTicket(null);
    }
  }, [isOpen, initialUsername, initialCategory, initialSubject]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanUser = username.trim().replace(/^@/, '');
    const cleanSub = subject.trim();
    const cleanMsg = message.trim();

    if (!cleanUser) {
      setError('Please enter your TaskPoint username.');
      return;
    }
    if (!cleanSub) {
      setError('Please enter a ticket subject.');
      return;
    }
    if (!cleanMsg) {
      setError('Please enter your support message details.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const res = await api.createPublicTicket({
        username: cleanUser,
        email: email.trim() || undefined,
        category,
        priority,
        subject: cleanSub,
        message: cleanMsg,
      });

      setSubmittedTicket({
        id: res.ticket.id,
        username: res.ticket.username || cleanUser,
      });
    } catch (err: any) {
      setError(err.message || 'Failed to submit support ticket. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleResetAndClose = () => {
    setUsername('');
    setEmail('');
    setSubject('');
    setMessage('');
    setError(null);
    setSubmittedTicket(null);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg rounded-3xl bg-slate-900 border border-slate-800 shadow-2xl p-6 sm:p-8 overflow-hidden text-slate-100">
        
        {/* Decorative Ambient Accents */}
        <div className="absolute -top-16 -right-16 w-36 h-36 bg-blue-500/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-16 -left-16 w-36 h-36 bg-indigo-500/15 rounded-full blur-3xl pointer-events-none" />

        {/* Close button */}
        <button
          id="btn-close-landing-support"
          onClick={handleResetAndClose}
          disabled={loading}
          className="absolute top-5 right-5 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors disabled:opacity-50 cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {submittedTicket ? (
          /* Success Screen */
          <div className="text-center py-6 space-y-4 animate-in zoom-in-95 duration-200">
            <div className="w-16 h-16 rounded-3xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 flex items-center justify-center mx-auto shadow-lg shadow-emerald-500/20">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <div className="space-y-2">
              <span className="px-3 py-1 rounded-full bg-slate-800 text-slate-300 font-mono text-xs font-bold border border-slate-700">
                Ticket ID: {submittedTicket.id}
              </span>
              <h2 className="text-2xl font-black tracking-tight text-white">
                Ticket Submitted Successfully!
              </h2>
              <p className="text-xs text-slate-400 max-w-sm mx-auto leading-relaxed">
                Our support and administration staff have received your request for account <strong className="text-blue-400">@{submittedTicket.username}</strong> and will review it promptly.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-800/60 border border-slate-700/60 text-left text-xs text-slate-300 space-y-1.5">
              <div className="flex items-center gap-2 font-bold text-slate-200">
                <Sparkles className="w-4 h-4 text-amber-400" />
                <span>What happens next?</span>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">
                Tickets are reviewed in the order received. If your account was banned or restricted, an administrator will evaluate your appeal.
              </p>
            </div>

            <button
              onClick={handleResetAndClose}
              className="w-full py-3 px-4 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-lg shadow-blue-600/30 transition-all cursor-pointer"
            >
              Return to Landing Page
            </button>
          </div>
        ) : (
          /* Submission Form */
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-2xl bg-blue-600/20 border border-blue-500/30 text-blue-400 flex items-center justify-center shadow-md">
                <MessageSquare className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-xl font-black text-white tracking-tight">
                  Public Support Ticket Desk
                </h2>
                <p className="text-xs text-slate-400">
                  Submit an account inquiry or appeal from the landing page.
                </p>
              </div>
            </div>

            {error && (
              <div className="mb-4 p-3.5 rounded-2xl bg-rose-950/60 border border-rose-800/80 text-rose-300 text-xs font-semibold flex items-start gap-2.5">
                <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <span>{error}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-3.5">
              {/* TaskPoint Username (Required) */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                    <span>TaskPoint Username</span>
                    <span className="text-rose-400">*</span>
                  </label>
                  <span className="text-[10px] text-blue-400 font-medium">Required for guest tickets</span>
                </div>
                <div className="relative">
                  <span className="absolute left-3.5 top-2.5 text-slate-500 font-bold text-xs">@</span>
                  <input
                    type="text"
                    required
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="yourusername"
                    className="w-full pl-8 pr-3.5 py-2.5 rounded-xl border border-slate-700 bg-slate-800/80 text-white text-xs placeholder:text-slate-500 outline-none focus:ring-2 focus:ring-blue-500 font-medium"
                  />
                </div>
              </div>

              {/* Optional Email */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Contact Email <span className="text-slate-500 font-normal">(Optional for updates)</span>
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@example.com"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-700 bg-slate-800/80 text-white text-xs placeholder:text-slate-500 outline-none focus:ring-2 focus:ring-blue-500 font-medium"
                />
              </div>

              {/* Category & Priority Row */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    Inquiry Category
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl border border-slate-700 bg-slate-800 text-white text-xs outline-none focus:ring-2 focus:ring-blue-500 font-medium"
                  >
                    <option value="Account Ban / Suspension Appeal">Account Ban / Suspension Appeal</option>
                    <option value="Login & Access Issues">Login & Access Issues</option>
                    <option value="Task Verification & Disputes">Task Verification & Disputes</option>
                    <option value="USDT Payout Inquiry">USDT Payout Inquiry</option>
                    <option value="General Support">General Support</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-300 mb-1">
                    Priority
                  </label>
                  <select
                    value={priority}
                    onChange={(e) => setPriority(e.target.value)}
                    className="w-full px-3 py-2.5 rounded-xl border border-slate-700 bg-slate-800 text-white text-xs outline-none focus:ring-2 focus:ring-blue-500 font-medium"
                  >
                    <option value="HIGH">High (Ban / Access Appeal)</option>
                    <option value="URGENT">Urgent</option>
                    <option value="MEDIUM">Medium</option>
                    <option value="LOW">Low</option>
                  </select>
                </div>
              </div>

              {/* Subject */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Subject <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="e.g. Account Ban Appeal for @username"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-700 bg-slate-800/80 text-white text-xs placeholder:text-slate-500 outline-none focus:ring-2 focus:ring-blue-500 font-medium"
                />
              </div>

              {/* Message Details */}
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1">
                  Message Details <span className="text-rose-400">*</span>
                </label>
                <textarea
                  rows={3}
                  required
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Please describe why you are appealing or explain what happened with your account..."
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-700 bg-slate-800/80 text-white text-xs placeholder:text-slate-500 outline-none focus:ring-2 focus:ring-blue-500 resize-none font-medium"
                />
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={handleResetAndClose}
                  disabled={loading}
                  className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading}
                  className="px-6 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs shadow-lg shadow-blue-600/30 flex items-center gap-2 transition-all disabled:opacity-50 cursor-pointer"
                >
                  {loading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Submitting...</span>
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4" />
                      <span>Submit Ticket</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        )}

      </div>
    </div>
  );
};
