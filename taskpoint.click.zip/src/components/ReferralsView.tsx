import React, { useEffect, useState } from 'react';
import { 
  Gift, 
  Copy, 
  Check, 
  Users, 
  Sparkles, 
  ShieldAlert, 
  ArrowRight,
  Info,
  Clock
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { api } from '../lib/api';

export const ReferralsView: React.FC = () => {
  const { user } = useAuth();
  const [refInfo, setRefInfo] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);

  const fetchReferralInfo = async () => {
    try {
      const data = await api.getReferralInfo();
      setRefInfo(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReferralInfo();
  }, []);

  if (!user) return null;

  const referralCode = user.referralCode || 'MYCODE123';

  const handleCopy = () => {
    navigator.clipboard.writeText(referralCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-300">
      
      {/* Header */}
      <div>
        <h1 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">
          Referral Program & Rewards
        </h1>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
          Invite friends to TaskPoint and earn XP for every verified registration.
        </p>
      </div>

      {/* Critical Policy Alert Callout */}
      <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/60 text-amber-800 dark:text-amber-200 flex items-start gap-3">
        <Info className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
        <div className="text-xs leading-relaxed">
          <p className="font-bold">Important Referral Earnings Policy:</p>
          <p className="mt-0.5">
            Referral rewards are awarded as <span className="font-extrabold underline">XP ONLY</span>. Referrers never earn cash for inviting new users. XP accumulates towards your level and $TASK token allocation!
          </p>
        </div>
      </div>

      {/* Referral Code & Stats Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Referral Code Widget */}
        <div className="lg:col-span-2 p-6 rounded-3xl bg-gradient-to-br from-indigo-600 via-purple-600 to-slate-900 text-white shadow-xl relative overflow-hidden">
          <div className="flex items-center gap-2 text-indigo-200 font-extrabold text-xs uppercase tracking-wider mb-2">
            <Gift className="w-4 h-4 text-amber-400" />
            <span>Your Unique Referral Code</span>
          </div>

          <h2 className="text-2xl font-black mb-1">
            Earn +{refInfo?.bonusPerReferral || 20} XP Per Friend
          </h2>
          <p className="text-xs text-indigo-100 max-w-xl leading-relaxed mb-6">
            Share your unique referral code with friends. When they enter your code during registration, you will both earn XP towards your level and the $TASK token airdrop.
          </p>

          {/* Copy Bar */}
          <div className="p-2 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 flex flex-col sm:flex-row items-center gap-2">
            <div className="w-full bg-slate-900/60 px-4 py-3 rounded-xl border border-white/10 flex items-center justify-between">
              <span className="text-[11px] uppercase tracking-wider font-bold text-indigo-200">CODE:</span>
              <span className="font-mono text-base sm:text-lg font-black tracking-widest text-amber-300 select-all">
                {referralCode}
              </span>
            </div>
            <button
              onClick={handleCopy}
              className="w-full sm:w-auto px-6 py-3 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 font-extrabold text-xs shadow-md transition-all shrink-0 flex items-center justify-center gap-2 cursor-pointer active:scale-95"
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4 text-slate-950" />
                  <span>Copied Code!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4 text-slate-950" />
                  <span>Copy Code</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Stats Summary Card */}
        <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between">
          <div className="space-y-4">
            <h3 className="font-extrabold text-sm text-slate-900 dark:text-white">
              Referral Performance
            </h3>

            <div className="p-4 rounded-2xl bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-100 dark:border-indigo-900/40">
              <span className="text-[11px] font-bold text-slate-500 uppercase">Total Referral XP</span>
              <h3 className="text-2xl font-black text-indigo-600 dark:text-indigo-400 mt-1">
                {refInfo?.referralPoints?.toLocaleString() || 0} XP
              </h3>
            </div>

            <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-100 dark:border-emerald-900/40">
              <span className="text-[11px] font-bold text-slate-500 uppercase">Successful Referrals</span>
              <h3 className="text-2xl font-black text-emerald-600 dark:text-emerald-400 mt-1">
                {refInfo?.totalReferrals || 0} Friends
              </h3>
            </div>
          </div>
        </div>

      </div>

      {/* Referred Friends History Table */}
      <div className="p-6 rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
        <h3 className="font-extrabold text-base text-slate-900 dark:text-white mb-4">
          Referred Members Network
        </h3>

        {loading ? (
          <div className="p-8 text-center text-xs text-slate-400 animate-pulse">
            Loading referral records...
          </div>
        ) : !refInfo?.referredUsers || refInfo.referredUsers.length === 0 ? (
          <div className="py-12 text-center">
            <Users className="w-10 h-10 text-slate-300 dark:text-slate-700 mx-auto mb-2" />
            <p className="text-xs font-bold text-slate-500">No referrals yet</p>
            <p className="text-[11px] text-slate-400 mt-1">
              Share your referral code above with your friends and network!
            </p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-100 dark:border-slate-800 text-slate-400 font-bold uppercase text-[10px]">
                  <th className="pb-3">User</th>
                  <th className="pb-3">Joined Date</th>
                  <th className="pb-3">Their Balance</th>
                  <th className="pb-3 text-right">XP Awarded To You</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60">
                {refInfo.referredUsers.map((ref: any, idx: number) => (
                  <tr key={idx} className="hover:bg-slate-50 dark:hover:bg-slate-800/50 transition-colors">
                    <td className="py-3 font-extrabold text-slate-900 dark:text-white flex items-center gap-2">
                      <img
                        src={ref.avatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${ref.username}`}
                        alt={ref.username}
                        className="w-7 h-7 rounded-lg object-cover"
                      />
                      <span>@{ref.username}</span>
                    </td>
                    <td className="py-3 text-slate-500">
                      {new Date(ref.createdAt).toLocaleDateString()}
                    </td>
                    <td className="py-3 text-indigo-600 dark:text-indigo-400 font-bold">
                      {ref.airdropPoints} XP
                    </td>
                    <td className="py-3 text-right font-black text-emerald-600">
                      +{refInfo.bonusPerReferral} XP
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

    </div>
  );
};
