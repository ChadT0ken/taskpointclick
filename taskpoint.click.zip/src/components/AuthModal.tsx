import React, { useState, useEffect } from 'react';
import { X, Mail, Lock, User as UserIcon, Sparkles, Gift, ArrowRight, CheckCircle2, RefreshCw, ArrowLeft } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { api } from '../lib/api';

interface AuthModalProps {
  onClose: () => void;
  initialMode?: 'login' | 'register' | 'LOGIN' | 'REGISTER';
}

export const AuthModal: React.FC<AuthModalProps> = ({ onClose, initialMode = 'LOGIN' }) => {
  const { login, register } = useAuth();
  const [mode, setMode] = useState<'LOGIN' | 'REGISTER' | 'FORGOT' | 'OTP'>(
    initialMode.toUpperCase() === 'REGISTER' ? 'REGISTER' : 'LOGIN'
  );

  // Form states
  const [emailOrUsername, setEmailOrUsername] = useState('');
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [referralCode, setReferralCode] = useState('');

  // One-time verification link states
  const [otpPurpose, setOtpPurpose] = useState<'LOGIN' | 'REGISTER' | 'FORGOT'>('LOGIN');
  const [otpEmail, setOtpEmail] = useState('');
  const [cooldown, setCooldown] = useState<number>(0);
  const [devOtpLink, setDevOtpLink] = useState<string | null>(null);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  // Resend Cooldown Timer
  useEffect(() => {
    if (cooldown <= 0) return;
    const interval = setInterval(() => {
      setCooldown((prev) => prev - 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [cooldown]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSuccessMsg(null);
    setLoading(true);

    try {
      if (mode === 'LOGIN') {
        const res = await login(emailOrUsername.trim(), password.trim());
        if (res.requireOtp) {
          setOtpPurpose('LOGIN');
          setOtpEmail(res.email);
          if (res.previewOtpLink) setDevOtpLink(res.previewOtpLink);
          setMode('OTP');
          setSuccessMsg(res.message || `One-time login link sent to ${res.email}`);
          setCooldown(30);
        } else if (res.token && res.user) {
          onClose();
        }
      } else if (mode === 'REGISTER') {
        const res = await register(username.trim(), email.trim(), password.trim(), referralCode.trim() || undefined);
        if (res.requireOtp) {
          setOtpPurpose('REGISTER');
          setOtpEmail(res.email);
          if (res.previewOtpLink) setDevOtpLink(res.previewOtpLink);
          setMode('OTP');
          setSuccessMsg(res.message || `One-time verification link sent to ${res.email}`);
          setCooldown(30);
        } else if (res.token && res.user) {
          onClose();
        }
      } else if (mode === 'FORGOT') {
        const targetEmail = email.trim() || emailOrUsername.trim();
        const res = await api.forgotPassword({
          email: targetEmail,
          newPassword: newPassword.trim() || undefined,
        });
        if (res.requireOtp) {
          setOtpPurpose('FORGOT');
          setOtpEmail(res.email);
          if ((res as any).previewOtpLink) setDevOtpLink((res as any).previewOtpLink);
          setMode('OTP');
          setSuccessMsg(res.message || `Password reset link sent to ${res.email}`);
          setCooldown(30);
        } else {
          setSuccessMsg(res.message);
        }
      }
    } catch (err: any) {
      setError(err.message || 'Authentication failed');
    } finally {
      setLoading(false);
    }
  };

  // Resend OTP link
  const handleResendOtp = async () => {
    if (cooldown > 0) return;
    setError(null);
    setSuccessMsg(null);
    setLoading(true);

    try {
      const res = await api.sendOtp({
        email: otpEmail,
        purpose: otpPurpose,
      });
      if ((res as any).previewOtpLink) {
        setDevOtpLink((res as any).previewOtpLink);
      }
      setSuccessMsg(`New verification link sent to ${otpEmail}`);
      setCooldown(30);
    } catch (err: any) {
      setError(err.message || 'Failed to resend verification link.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-md rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-6 sm:p-8 overflow-hidden">
        
        {/* Background Gradient Spot */}
        <div className="absolute -top-12 -right-12 w-32 h-32 bg-indigo-500/20 rounded-full blur-2xl pointer-events-none"></div>

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-1.5 rounded-xl text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="text-center mb-6">
          <div className="w-12 h-12 rounded-2xl bg-indigo-600 text-white flex items-center justify-center mx-auto mb-3 shadow-lg shadow-indigo-600/30">
            {mode === 'OTP' ? (
              <Mail className="w-6 h-6 text-white animate-pulse" />
            ) : (
              <Sparkles className="w-6 h-6 animate-pulse" />
            )}
          </div>
          <h2 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">
            {mode === 'OTP'
              ? 'Check Your Email'
              : mode === 'LOGIN'
              ? 'Welcome Back'
              : mode === 'REGISTER'
              ? 'Create Account'
              : 'Reset Password'}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            {mode === 'OTP' ? (
              <span>We sent a one-time verification link to <strong className="font-semibold text-slate-900 dark:text-slate-200">{otpEmail}</strong></span>
            ) : mode === 'LOGIN' ? (
              'Sign in to access your wallet & tasks'
            ) : mode === 'REGISTER' ? (
              'Join TaskPoint & earn 50 Bonus Points'
            ) : (
              'Enter your email to receive recovery instructions'
            )}
          </p>
        </div>

        {/* Error / Success Alerts */}
        {error && (
          <div className="mb-4 p-3 rounded-xl bg-rose-50 dark:bg-rose-950/50 border border-rose-200 dark:border-rose-800 text-rose-600 dark:text-rose-300 text-xs font-semibold">
            {error}
          </div>
        )}
        {successMsg && (
          <div className="mb-4 p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 text-emerald-600 dark:text-emerald-300 text-xs font-semibold flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* Mode = OTP Link Verification Screen */}
        {mode === 'OTP' ? (
          <div className="space-y-4">
            <div className="p-4 rounded-2xl bg-indigo-50/70 dark:bg-indigo-950/40 border border-indigo-100 dark:border-indigo-900/50 text-slate-800 dark:text-slate-200 text-center space-y-2.5">
              <div className="w-10 h-10 rounded-full bg-indigo-100 dark:bg-indigo-900/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center mx-auto shadow-sm">
                <Mail className="w-5 h-5" />
              </div>
              <div className="font-bold text-sm text-slate-900 dark:text-white">
                One-Time Sign-In Link Sent
              </div>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed max-w-xs mx-auto">
                Click the verification link in your email to authenticate and sign in to TaskPoint automatically.
              </p>
              <div className="text-[11px] text-slate-400 dark:text-slate-500 pt-1">
                Link is valid for 10 minutes. No password or code needed.
              </div>
            </div>

            {devOtpLink && (
              <a
                href={devOtpLink}
                className="w-full py-3.5 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 transition-all text-center"
              >
                <Sparkles className="w-4 h-4" />
                <span>Open 1-Click Verification Link</span>
                <ArrowRight className="w-4 h-4" />
              </a>
            )}

            <div className="flex items-center justify-between pt-2">
              <button
                type="button"
                onClick={handleResendOtp}
                disabled={loading || cooldown > 0}
                className="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:underline disabled:opacity-50 flex items-center gap-1"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
                <span>{cooldown > 0 ? `Resend link in ${cooldown}s` : 'Resend Link'}</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setMode(otpPurpose === 'REGISTER' ? 'REGISTER' : 'LOGIN');
                  setError(null);
                  setSuccessMsg(null);
                }}
                className="text-xs font-bold text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 flex items-center gap-1"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Change Email</span>
              </button>
            </div>
          </div>
        ) : (
          /* standard Login / Register / Forgot Form */
          <form onSubmit={handleSubmit} className="space-y-4">
            
            {mode === 'REGISTER' && (
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Username
                </label>
                <div className="relative">
                  <UserIcon className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <input
                    type="text"
                    required
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="e.g. AlexCrypto"
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                  />
                </div>
              </div>
            )}

            {mode === 'LOGIN' ? (
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Email or Username
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <input
                    type="text"
                    required
                    value={emailOrUsername}
                    onChange={(e) => setEmailOrUsername(e.target.value)}
                    placeholder="alex.dev@gmail.com or AlexCrypto"
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                  />
                </div>
              </div>
            ) : (
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="your.email@example.com"
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                  />
                </div>
              </div>
            )}

            {mode !== 'FORGOT' ? (
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-bold text-slate-700 dark:text-slate-300">
                    Password
                  </label>
                  {mode === 'LOGIN' && (
                    <button
                      type="button"
                      onClick={() => {
                        setMode('FORGOT');
                        setError(null);
                        setSuccessMsg(null);
                      }}
                      className="text-[11px] text-indigo-600 dark:text-indigo-400 hover:underline font-semibold"
                    >
                      Forgot Password?
                    </button>
                  )}
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                  />
                </div>
              </div>
            ) : (
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  New Password
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <input
                    type="password"
                    required
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    placeholder="Enter your new password (min. 6 chars)"
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                  />
                </div>
              </div>
            )}

            {mode === 'REGISTER' && (
              <div>
                <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                  Referral Code (Optional)
                </label>
                <div className="relative">
                  <Gift className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                  <input
                    type="text"
                    value={referralCode}
                    onChange={(e) => setReferralCode(e.target.value)}
                    placeholder="e.g. ADMINREF or CODE123"
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/50 text-slate-900 dark:text-white text-xs focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
                  />
                </div>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 transition-all disabled:opacity-50 mt-2"
            >
              {loading ? (
                <span>Sending OTP...</span>
              ) : (
                <>
                  <span>
                    {mode === 'LOGIN' ? 'Sign In with OTP' : mode === 'REGISTER' ? 'Create Account & Get OTP' : 'Send Reset OTP'}
                  </span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>
        )}

        {/* Footer Toggle */}
        {mode !== 'OTP' && (
          <div className="mt-4 text-center text-xs text-slate-500 dark:text-slate-400">
            {mode === 'LOGIN' ? (
              <p>
                Don't have an account?{' '}
                <button
                  onClick={() => {
                    setMode('REGISTER');
                    setError(null);
                    setSuccessMsg(null);
                  }}
                  className="text-indigo-600 dark:text-indigo-400 font-bold hover:underline"
                >
                  Sign Up
                </button>
              </p>
            ) : (
              <p>
                Already registered?{' '}
                <button
                  onClick={() => {
                    setMode('LOGIN');
                    setError(null);
                    setSuccessMsg(null);
                  }}
                  className="text-indigo-600 dark:text-indigo-400 font-bold hover:underline"
                >
                  Sign In
                </button>
              </p>
            )}
          </div>
        )}

      </div>
    </div>
  );
};
