import React, { useState } from 'react';
import { X, Sparkles, Gift, CheckCircle2, ShieldCheck, ArrowRight, Loader2, LifeBuoy, AlertTriangle, ShieldAlert, WifiOff } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface AuthModalProps {
  onClose: () => void;
  initialMode?: 'login' | 'register' | 'LOGIN' | 'REGISTER';
  onOpenSupport?: (username?: string) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ onClose, initialMode = 'LOGIN', onOpenSupport }) => {
  const { loginWithGoogle } = useAuth();
  const [mode, setMode] = useState<'LOGIN' | 'REGISTER'>(
    initialMode.toUpperCase() === 'REGISTER' ? 'REGISTER' : 'LOGIN'
  );

  const [referralCode, setReferralCode] = useState('');
  const [showReferralInput, setShowReferralInput] = useState(false);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isBannedError, setIsBannedError] = useState(false);
  const [isVpnError, setIsVpnError] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const handleGoogleAuth = async () => {
    setError(null);
    setIsBannedError(false);
    setIsVpnError(false);
    setSuccessMsg(null);
    setLoading(true);

    try {
      const res = await loginWithGoogle(referralCode.trim() || undefined);
      setSuccessMsg(res.message || 'Authenticated successfully with Google!');
      setTimeout(() => {
        onClose();
      }, 500);
    } catch (err: any) {
      console.error('Google Auth Error:', err);
      const msg = err.message || 'Failed to authenticate with Google. Please try again.';
      setError(msg);
      if (msg.toLowerCase().includes('vpn') || msg.toLowerCase().includes('proxy') || msg.toLowerCase().includes('datacenter')) {
        setIsVpnError(true);
      } else if (msg.toLowerCase().includes('banned') || msg.toLowerCase().includes('deleted')) {
        setIsBannedError(true);
      } else if (err.code === 'auth/popup-closed-by-user' || msg.includes('popup-closed-by-user')) {
        setError('Sign-in cancelled. Please click "Continue with Google" again when ready.');
      } else if (err.code === 'auth/cancelled-popup-request') {
        setError('Previous sign-in window was closed. Please try again.');
      } else if (err.code === 'auth/unauthorized-domain' || msg.includes('unauthorized-domain')) {
        setError('Authentication domain authorization pending in Firebase console. Please ensure this domain is added to Authorized Domains in Firebase Auth.');
      } else if (err.code === 'auth/network-request-failed') {
        setError('Network connection error. Please check your internet connection and try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleAppealClick = () => {
    onClose();
    if (onOpenSupport) {
      onOpenSupport();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-md rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-2xl p-6 sm:p-8 overflow-hidden text-slate-900 dark:text-white">
        
        {/* Decorative Top Gradient */}
        <div className="absolute -top-16 -right-16 w-36 h-36 bg-blue-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-16 -left-16 w-36 h-36 bg-indigo-500/20 rounded-full blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          id="btn-close-auth-modal"
          onClick={onClose}
          disabled={loading}
          className="absolute top-5 right-5 p-2 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors disabled:opacity-50"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Mode Switcher Tabs */}
        <div className="flex bg-slate-100 dark:bg-slate-800/70 p-1 rounded-2xl mb-6 max-w-xs mx-auto">
          <button
            type="button"
            onClick={() => {
              setMode('LOGIN');
              setError(null);
              setIsBannedError(false);
            }}
            className={`flex-1 py-1.5 text-xs font-bold rounded-xl transition-all ${
              mode === 'LOGIN'
                ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-white shadow-sm'
                : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-white'
            }`}
          >
            Sign In
          </button>
          <button
            type="button"
            onClick={() => {
              setMode('REGISTER');
              setError(null);
              setIsBannedError(false);
            }}
            className={`flex-1 py-1.5 text-xs font-bold rounded-xl transition-all ${
              mode === 'REGISTER'
                ? 'bg-white dark:bg-slate-700 text-blue-600 dark:text-white shadow-sm'
                : 'text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-white'
            }`}
          >
            Create Account
          </button>
        </div>

        {/* Header Icon & Title */}
        <div className="text-center mb-6">
          <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 text-white flex items-center justify-center mx-auto mb-3 shadow-lg shadow-blue-500/25">
            <Sparkles className="w-7 h-7" />
          </div>
          <h2 className="text-2xl font-black tracking-tight text-slate-900 dark:text-white">
            {mode === 'LOGIN' ? 'Welcome to TaskPoint' : 'Join TaskPoint with Google'}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1.5 leading-relaxed">
            {mode === 'LOGIN'
              ? 'Fast, 1-click Google authentication to access your tasks and crypto payouts.'
              : 'Create your account instantly with Google & receive +20 XP welcome bonus!'}
          </p>
        </div>

        {/* VPN / PROXY BLOCKED BANNER */}
        {isVpnError && (
          <div className="mb-5 p-4 rounded-2xl bg-amber-500/15 border-2 border-amber-500/40 text-amber-900 dark:text-amber-200 text-xs space-y-2.5 animate-in fade-in slide-in-from-top-2">
            <div className="flex items-start gap-2.5">
              <ShieldAlert className="w-5 h-5 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
              <div>
                <h4 className="font-extrabold text-sm text-amber-700 dark:text-amber-300 flex items-center gap-1.5">
                  <span>VPN or Proxy Blocked</span>
                  <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-700 dark:text-amber-300 font-mono font-bold uppercase">Strict Anti-Fraud</span>
                </h4>
                <p className="mt-1 leading-relaxed font-medium text-slate-700 dark:text-slate-300">
                  TaskPoint strictly prohibits the use of VPNs, Proxies, Cloudflare WARP, Tor nodes, or Datacenter networks to maintain fair microtask verification.
                </p>
              </div>
            </div>
            <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-[11px] text-amber-800 dark:text-amber-200 font-semibold flex items-center gap-2">
              <WifiOff className="w-4 h-4 shrink-0 text-amber-600 dark:text-amber-400" />
              <span>Please turn off your VPN/Proxy connection and click &quot;Continue with Google&quot; again.</span>
            </div>
          </div>
        )}

        {/* BANNED ACCOUNT PROMINENT BANNER */}
        {isBannedError && (
          <div className="mb-5 p-4 rounded-2xl bg-rose-500/15 border-2 border-rose-500/40 text-rose-600 dark:text-rose-300 text-xs font-semibold space-y-3 animate-in fade-in slide-in-from-top-2">
            <div className="flex items-start gap-2.5">
              <AlertTriangle className="w-5 h-5 text-rose-500 shrink-0 mt-0.5" />
              <div>
                <h4 className="font-extrabold text-sm text-rose-600 dark:text-rose-400">Account Banned</h4>
                <p className="mt-0.5 leading-relaxed font-medium">Account banned. Please contact support if you think it was a mistake</p>
              </div>
            </div>
            {onOpenSupport && (
              <button
                type="button"
                onClick={handleAppealClick}
                className="w-full py-2.5 px-3.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-md shadow-rose-600/30 flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <LifeBuoy className="w-4 h-4" />
                <span>Contact Support / Submit Appeal</span>
              </button>
            )}
          </div>
        )}

        {/* General Error Alert */}
        {error && !isBannedError && !isVpnError && (
          <div className="mb-4 p-3.5 rounded-2xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-800/80 text-rose-600 dark:text-rose-300 text-xs font-semibold space-y-2">
            <div className="flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 text-rose-500 shrink-0 mt-0.5" />
              <div className="flex-1 leading-relaxed">{error}</div>
            </div>
          </div>
        )}

        {/* Success Alert */}
        {successMsg && (
          <div className="mb-4 p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800/80 text-emerald-600 dark:text-emerald-300 text-xs font-semibold flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{successMsg}</span>
          </div>
        )}

        {/* Primary Google Auth Action */}
        <div className="space-y-4">
          <button
            id="btn-google-auth"
            type="button"
            onClick={handleGoogleAuth}
            disabled={loading}
            className="w-full py-3.5 px-4 rounded-2xl bg-white hover:bg-slate-50 dark:bg-slate-800 dark:hover:bg-slate-750 text-slate-800 dark:text-white font-bold text-sm border-2 border-slate-200 dark:border-slate-700 hover:border-blue-500 dark:hover:border-blue-500 shadow-lg hover:shadow-xl shadow-slate-200/50 dark:shadow-none flex items-center justify-center gap-3 transition-all disabled:opacity-60 group active:scale-[0.99] cursor-pointer"
          >
            {loading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin text-blue-600 dark:text-blue-400" />
                <span>Connecting to Google...</span>
              </>
            ) : (
              <>
                {/* Official Google 'G' Logo */}
                <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24">
                  <path
                    fill="#4285F4"
                    d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z"
                  />
                  <path
                    fill="#34A853"
                    d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.33 24 12 24z"
                  />
                  <path
                    fill="#FBBC05"
                    d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 9.99 0 12s.45 3.82 1.25 5.42l4.03-3.15z"
                  />
                  <path
                    fill="#EA4335"
                    d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.33 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
                  />
                </svg>
                <span>
                  {mode === 'LOGIN' ? 'Continue with Google' : 'Sign Up with Google'}
                </span>
                <ArrowRight className="w-4 h-4 text-slate-400 group-hover:translate-x-1 transition-transform" />
              </>
            )}
          </button>

          {/* Optional Referral Code Toggle for Sign Ups */}
          {mode === 'REGISTER' && (
            <div className="pt-2">
              {!showReferralInput ? (
                <button
                  type="button"
                  onClick={() => setShowReferralInput(true)}
                  className="w-full text-center text-xs text-blue-600 dark:text-blue-400 font-semibold hover:underline flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Gift className="w-3.5 h-3.5" />
                  <span>Have a referral or invite code?</span>
                </button>
              ) : (
                <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/60 space-y-2 animate-in fade-in">
                  <div className="flex items-center justify-between">
                    <label className="text-[11px] font-bold text-slate-600 dark:text-slate-300 flex items-center gap-1.5">
                      <Gift className="w-3.5 h-3.5 text-blue-500" />
                      Referral Code (Optional)
                    </label>
                    <button
                      type="button"
                      onClick={() => {
                        setShowReferralInput(false);
                        setReferralCode('');
                      }}
                      className="text-[10px] text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
                    >
                      Hide
                    </button>
                  </div>
                  <input
                    type="text"
                    value={referralCode}
                    onChange={(e) => setReferralCode(e.target.value)}
                    placeholder="e.g. ADMINREF or FRIEND123"
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white text-xs uppercase font-mono tracking-wider focus:ring-2 focus:ring-blue-500 outline-none"
                  />
                  <p className="text-[10px] text-slate-400">
                    Applied automatically when you sign in with Google.
                  </p>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Security & Benefits Footer */}
        <div className="mt-6 pt-5 border-t border-slate-100 dark:border-slate-800/80">
          <div className="flex items-center justify-center gap-4 text-[11px] text-slate-500 dark:text-slate-400">
            <span className="flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
              Secure Google OAuth
            </span>
            <span>•</span>
            <span>No passwords required</span>
          </div>
        </div>

      </div>
    </div>
  );
};


