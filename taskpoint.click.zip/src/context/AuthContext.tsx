import React, { createContext, useContext, useEffect, useState } from 'react';
import { User } from '../types';
import { api } from '../lib/api';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: (emailOrUsername: string, pass: string) => Promise<any>;
  register: (username: string, email: string, pass: string, refCode?: string) => Promise<any>;
  setAuthSession: (token: string, user: User) => void;
  logout: () => void;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  const refreshUser = async () => {
    const token = localStorage.getItem('taskpoint_token');
    if (!token) {
      setUser(null);
      setLoading(false);
      return;
    }
    try {
      const res = await api.getMe();
      setUser(res.user);
    } catch (err) {
      console.error('Failed to restore session:', err);
      localStorage.removeItem('taskpoint_token');
      setUser(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refreshUser();
  }, []);

  const setAuthSession = (token: string, user: User) => {
    localStorage.setItem('taskpoint_token', token);
    setUser(user);
  };

  const login = async (emailOrUsername: string, pass: string) => {
    const res = await api.login({ emailOrUsername, password: pass });
    if (res.token && res.user) {
      setAuthSession(res.token, res.user);
    }
    return res;
  };

  const register = async (username: string, email: string, pass: string, refCode?: string) => {
    const res = await api.register({ username, email, password: pass, referralCode: refCode });
    if (res.token && res.user) {
      setAuthSession(res.token, res.user);
    }
    return res;
  };

  const logout = () => {
    localStorage.removeItem('taskpoint_token');
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, register, logout, refreshUser }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within an AuthProvider');
  return context;
};
