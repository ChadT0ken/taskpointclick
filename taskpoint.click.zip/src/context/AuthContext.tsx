import React, { createContext, useContext, useEffect, useState } from 'react';
import { User } from '../types';
import { api } from '../lib/api';
import { signInWithGoogle as fbSignInWithGoogle } from '../lib/firebase';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  loginWithGoogle: (referralCode?: string) => Promise<any>;
  login: (emailOrUsername: string, pass: string) => Promise<any>;
  register: (username: string, email: string, pass: string, refCode?: string) => Promise<any>;
  setAuthSession: (token: string, user: User) => void;
  logout: () => void;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  const refreshUser = async () => {
    const token = localStorage.getItem('taskpoint_token');
    if (!token) {
      setUser(null);
      setLoading(false);
      return;
    }
    try {
      const res = await api.getMe();
      setUser(res.user);
    } catch (err: any) {
      console.error('Failed to restore session:', err);
      localStorage.removeItem('taskpoint_token');
      setUser(null);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refreshUser();
  }, []);

  const setAuthSession = (token: string, user: User) => {
    localStorage.setItem('taskpoint_token', token);
    setUser(user);
  };

  const loginWithGoogle = async (referralCode?: string) => {
    const result = await fbSignInWithGoogle();
    const fbUser = result.user;
    if (!fbUser.email) {
      throw new Error('Could not retrieve email address from your Google account.');
    }

    const idToken = await fbUser.getIdToken();
    const res = await api.googleAuth({
      email: fbUser.email,
      displayName: fbUser.displayName || undefined,
      photoURL: fbUser.photoURL || undefined,
      uid: fbUser.uid,
      idToken,
      referralCode: referralCode?.trim() || undefined,
    });

    if (res.token && res.user) {
      setAuthSession(res.token, res.user);
    }
    return res;
  };

  const login = async (emailOrUsername: string, pass: string) => {
    const res = await api.login({ emailOrUsername, password: pass });
    if (res.token && res.user) {
      setAuthSession(res.token, res.user);
    }
    return res;
  };

  const register = async (username: string, email: string, pass: string, refCode?: string) => {
    const res = await api.register({ username, email, password: pass, referralCode: refCode });
    if (res.token && res.user) {
      setAuthSession(res.token, res.user);
    }
    return res;
  };

  const logout = () => {
    localStorage.removeItem('taskpoint_token');
    setUser(null);
  };

  return (
    <AuthContext.Provider value={{ user, loading, loginWithGoogle, login, register, logout, refreshUser }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within an AuthProvider');
  return context;
};
