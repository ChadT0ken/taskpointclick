export type Role = 'ADMIN' | 'MODERATOR' | 'SUPPORT' | 'USER';

export type TaskCategory = 
  | 'TIKTOK' 
  | 'INSTAGRAM' 
  | 'FACEBOOK' 
  | 'TWITTER' 
  | 'TELEGRAM' 
  | 'DISCORD' 
  | 'YOUTUBE' 
  | 'WEBSITE_VISIT' 
  | 'APP_DOWNLOAD' 
  | 'SURVEY' 
  | 'QUIZ' 
  | 'CRYPTO' 
  | 'AFFILIATE' 
  | 'CUSTOM';

export type SubmissionStatus = 'PENDING' | 'APPROVED' | 'REJECTED' | 'NEED_MORE_INFO';

export type WithdrawalStatus = 'PENDING' | 'APPROVED' | 'REJECTED' | 'CANCELLED' | 'COMPLETED';

export type TicketStatus = 'OPEN' | 'IN_PROGRESS' | 'RESOLVED' | 'CLOSED';

export type TicketPriority = 'LOW' | 'MEDIUM' | 'HIGH' | 'URGENT';

export type DisputeStatus = 'PENDING' | 'APPROVED' | 'REJECTED';

export interface User {
  id: string;
  email: string;
  username: string;
  role: Role;
  avatar?: string;
  country: string;
  isEmailVerified: boolean;
  isBanned: boolean;
  isRestricted?: boolean;
  isDeleted?: boolean;
  deletedAt?: string;
  deletedReason?: string;
  availableBalance: number;
  pendingBalance: number;
  totalWithdrawn: number;
  airdropPoints: number;
  referralPoints: number;
  dailyStreak: number;
  lastStreakClaimDate?: string;
  referralCode: string;
  referredById?: string;
  referralCount?: number;
  savedWalletAddress?: string;
  savedWalletNetwork?: 'TRC' | 'SOL';
  createdAt: string;
  lastLoginAt?: string;
}

export interface Task {
  id: string;
  title: string;
  description: string;
  instructions: string;
  category: TaskCategory;
  rewardCash: number;
  rewardPoints: number;
  totalSlots: number;
  filledSlots: number;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  estimatedTime: string;
  bannerImage?: string;
  taskUrl?: string;
  requirementType?: 'SCREENSHOT' | 'TEXT' | 'BOTH';
  status: 'ACTIVE' | 'PAUSED' | 'COMPLETED' | 'EXPIRED';
  startDate: string;
  endDate?: string;
  requirements: string[];
  createdAt: string;
  userSubmissionStatus?: SubmissionStatus;
  isBookmarked?: boolean;
}

export interface TaskSubmission {
  id: string;
  taskId: string;
  taskTitle?: string;
  taskCategory?: TaskCategory;
  rewardCash?: number;
  rewardPoints?: number;
  userId: string;
  username?: string;
  userEmail?: string;
  userAvatar?: string;
  proofScreenshot?: string;
  proofScreenshot2?: string;
  proofText?: string;
  proofUrl?: string;
  proofUsername?: string;
  status: SubmissionStatus;
  adminComment?: string;
  createdAt: string;
  updatedAt: string;
  dispute?: Dispute;
}

export interface Dispute {
  id: string;
  submissionId: string;
  userId: string;
  username?: string;
  reason: string;
  additionalProof?: string;
  status: DisputeStatus;
  adminComment?: string;
  createdAt: string;
}

export interface Withdrawal {
  id: string;
  userId: string;
  username?: string;
  userEmail?: string;
  amount: number;
  currency: 'USD' | 'USDT';
  method: 'BANK_TRANSFER' | 'USDT' | 'PAYPAL';
  details: string; // JSON or formatted text (Bank details or wallet)
  status: WithdrawalStatus;
  paymentRef?: string;
  adminNotes?: string;
  createdAt: string;
}

export interface SupportTicket {
  id: string;
  userId: string;
  username?: string;
  userEmail?: string;
  subject: string;
  category: string;
  priority: TicketPriority;
  status: TicketStatus;
  isGuest?: boolean;
  replies: TicketReply[];
  createdAt: string;
  updatedAt: string;
  closedAt?: string;
}

export interface TicketReply {
  id: string;
  ticketId: string;
  userId: string;
  username: string;
  userAvatar?: string;
  message: string;
  attachmentUrl?: string;
  isAdminReply: boolean;
  createdAt: string;
}

export interface Notification {
  id: string;
  userId: string;
  title: string;
  message: string;
  type: 'TASK' | 'WITHDRAWAL' | 'DISPUTE' | 'SUPPORT' | 'SYSTEM' | 'REFERRAL';
  isRead: boolean;
  linkUrl?: string;
  createdAt: string;
}

export interface ReferralLog {
  id: string;
  referrerId: string;
  referredUsername: string;
  pointsAwarded: number;
  ruleTriggered: string;
  createdAt: string;
}

export interface PointTransaction {
  id: string;
  userId: string;
  amount: number;
  type: string;
  description: string;
  createdAt: string;
}

export interface LeaderboardEntry {
  rank: number;
  userId: string;
  username: string;
  avatar?: string;
  country: string;
  value: number; // Primary sorted value according to active tab
  cashEarned: number; // Total USD / USDT cash earned ($)
  airdropPoints: number; // Total Airdrop XP (sum of earned task XP + referral XP)
  earnedTaskXP?: number; // Microtasks & daily bonus XP
  referralPoints: number; // Referral XP (PTS)
  referralCount: number; // Total number of successful referrals
  change: number; // Rank change (+1, -2, 0)
}

export interface SystemSettings {
  websiteName: string;
  minWithdrawalUSD: number;
  referralPointsBonus: number;
  maintenanceMode: boolean;
  supportEmail: string;
  strictVpnBlocking?: boolean;
  blockDataCenters?: boolean;
  vpnWhitelistedIps?: string[];
}

export interface VpnBlockLog {
  id: string;
  ip: string;
  action: 'LOGIN' | 'REGISTER' | 'GOOGLE_AUTH' | 'SUBMISSION' | 'WITHDRAWAL' | 'BONUS_CLAIM';
  usernameOrEmail?: string;
  country?: string;
  countryCode?: string;
  city?: string;
  isp?: string;
  org?: string;
  reason: string;
  detectedHeaders?: string[];
  createdAt: string;
}

export interface IpInspectionResult {
  ip: string;
  isVpnOrProxy: boolean;
  isDatacenter: boolean;
  isTor: boolean;
  threatScore: number;
  country: string;
  countryCode: string;
  region: string;
  city: string;
  isp: string;
  org: string;
  as: string;
  asname: string;
  timezone: string;
  reasons: string[];
}

export interface Announcement {
  id: string;
  title: string;
  content: string;
  type: 'BANNER' | 'POPUP';
  targetRole: 'ALL' | 'USER' | 'ADMIN';
  isActive: boolean;
  createdAt: string;
}

export interface DashboardStats {
  availableBalance: number;
  pendingBalance: number;
  totalWithdrawn: number;
  airdropPoints: number;
  completedTasks: number;
  pendingTasks: number;
  rejectedTasks: number;
  referralPointsEarned: number;
  totalReferralsCount: number;
  leaderboardRank: number;
  dailyStreak: number;
}

export interface AdminStats {
  totalUsers: number;
  activeUsers: number;
  todaySignups: number;
  pendingSubmissions: number;
  approvedToday: number;
  rejectedToday: number;
  pendingWithdrawals: number;
  totalCashDistributed: number;
  totalPointsDistributed: number;
  totalXpEarned?: number;
  totalReferralPointsAwarded: number;
  dailyStats: { date: string; users: number; tasks: number; payouts: number }[];
}

export interface AirdropStats {
  totalPoolXP: number;
  totalClaimedXP: number;
  availableToClaimXP: number;
  totalTaskXP?: number;
  totalReferralXP?: number;
}

export interface EmailLogEntry {
  id: string;
  toEmail: string;
  username: string;
  action: 'BANNED' | 'RESTRICTED' | 'DELETED' | 'RESTORED';
  subject: string;
  reason?: string;
  status: 'SENT' | 'FAILED' | 'SIMULATED';
  error?: string;
  timestamp: string;
}

