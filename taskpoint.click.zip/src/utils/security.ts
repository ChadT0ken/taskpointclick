/**
 * TaskPoint Client Security & VPN/Proxy Telemetry
 */

export interface ClientSecuritySignals {
  timezone: string;
  screenResolution: string;
  language: string;
  languages: readonly string[];
  isWebdriver: boolean;
  webrtcIps?: string[];
  localTimeOffset: number;
}

/**
 * Gathers client-side environment signals to detect emulation, proxying, and multi-accounting anomalies.
 */
export function getClientSecuritySignals(): ClientSecuritySignals {
  const nav = typeof window !== 'undefined' ? window.navigator : ({} as any);
  return {
    timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC',
    screenResolution: typeof window !== 'undefined' ? `${window.screen.width}x${window.screen.height}` : 'unknown',
    language: nav.language || 'en',
    languages: nav.languages || ['en'],
    isWebdriver: !!nav.webdriver,
    localTimeOffset: new Date().getTimezoneOffset(),
  };
}

/**
 * Checks for obvious WebRTC Candidate IP leaks (asynchronous)
 */
export async function getWebRTCLocalIps(): Promise<string[]> {
  if (typeof window === 'undefined' || !(window as any).RTCPeerConnection) {
    return [];
  }

  return new Promise((resolve) => {
    const ips: Set<string> = new Set();
    try {
      const pc = new (window as any).RTCPeerConnection({
        iceServers: [{ urls: 'stun:stun.l.google.com:19302' }],
      });

      pc.createDataChannel('');
      pc.createOffer().then((offer: any) => pc.setLocalDescription(offer)).catch(() => {});

      pc.onicecandidate = (event: any) => {
        if (!event || !event.candidate) {
          pc.close();
          resolve(Array.from(ips));
          return;
        }

        const candidate = event.candidate.candidate;
        const ipRegex = /([0-9]{1,3}(\.[0-9]{1,3}){3}|[a-f0-9]{1,4}(:[a-f0-9]{1,4}){7})/g;
        const match = candidate.match(ipRegex);
        if (match) {
          match.forEach((ip: string) => ips.add(ip));
        }
      };

      setTimeout(() => {
        try {
          pc.close();
        } catch (_) {}
        resolve(Array.from(ips));
      }, 1000);
    } catch (_) {
      resolve([]);
    }
  });
}
